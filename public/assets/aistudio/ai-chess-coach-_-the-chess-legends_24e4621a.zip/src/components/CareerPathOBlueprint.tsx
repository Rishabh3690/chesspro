import React, { useEffect, useMemo, useState } from 'react';
import {
  BlueprintTheme,
  CareerChild,
  CareerPathOStorageShape,
  Language,
  LearningTabKey,
  QUIZ_QUESTIONS,
  calculateLoanEmi,
  evaluateDeterministicQuiz,
  loadCareerPathOData,
} from '../careerpatho/careerPathoLogic';

interface CareerPathOBlueprintProps {
  onSwitchToChessArena?: () => void;
  onOpenSingleFileModal?: () => void;
}

const LEARNING_TABS: {
  key: LearningTabKey | 'aiMentorLocked';
  label: { en: string; hi: string };
  locked?: boolean;
}[] = [
  { key: 'pyqs', label: { en: '01. PYQs', hi: '01. PYQs (पुराने पेपर)' } },
  {
    key: 'govtPortals',
    label: { en: '02. Govt Portals', hi: '02. सरकारी पोर्टल' },
  },
  {
    key: 'youtube',
    label: { en: '03. YouTube Lectures', hi: '03. YouTube लेक्चर' },
  },
  {
    key: 'nptel',
    label: { en: '04. NPTEL / SWAYAM', hi: '04. NPTEL / SWAYAM' },
  },
  {
    key: 'books',
    label: { en: '05. Free Books', hi: '05. निःशुल्क पुस्तकें' },
  },
  {
    key: 'scholarships',
    label: { en: '06. Scholarships', hi: '06. छात्रवृत्ति' },
  },
  {
    key: 'internships',
    label: { en: '07. Internships', hi: '07. इंटर्नशिप' },
  },
  {
    key: 'mockTests',
    label: { en: '08. Mock Tests', hi: '08. मॉक टेस्ट' },
  },
  {
    key: 'aiMentorLocked',
    label: {
      en: 'AI Mentor (Locked until ₹10k Funding)',
      hi: 'AI Mentor (₹10k फंडिंग तक लॉक)',
    },
    locked: true,
  },
];

export const CareerPathOBlueprint: React.FC<CareerPathOBlueprintProps> = ({
  onSwitchToChessArena,
  onOpenSingleFileModal,
}) => {
  const [data] = useState<CareerPathOStorageShape>(() => loadCareerPathOData());
  const [lang, setLang] = useState<Language>('en');
  const [theme, setTheme] = useState<BlueprintTheme>('dark');
  const [hashRoute, setHashRoute] = useState<string>(
    () => window.location.hash || '#/'
  );
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Compare Tool state
  const [compareLeftId, setCompareLeftId] = useState<string>(
    () => data.children[0]?.id || 'btech-cse'
  );
  const [compareRightId, setCompareRightId] = useState<string>(
    () => data.children[1]?.id || 'bca-mca'
  );

  // Child Career Page state
  const [expandedStepMap, setExpandedStepMap] = useState<
    Record<string, boolean>
  >({ '01': true, '02': true, '03': true });
  const [learningModalOpen, setLearningModalOpen] = useState<boolean>(false);
  const [activeLearningTab, setActiveLearningTab] =
    useState<LearningTabKey>('pyqs');
  const [printPreviewCareer, setPrintPreviewCareer] =
    useState<CareerChild | null>(null);

  // Quiz state (10 questions)
  const [quizAnswers, setQuizAnswers] = useState<number[]>([]);
  const [currentQuizStep, setCurrentQuizStep] = useState<number>(0);

  // Sync with browser hash routing (#/, #/career/:id, #/quiz) & back button
  useEffect(() => {
    if (!window.location.hash) {
      window.history.replaceState(null, '', '#/');
    }
    const onHashChange = () => {
      setHashRoute(window.location.hash || '#/');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const navigateHash = (targetHash: string) => {
    if (window.location.hash === targetHash) {
      setHashRoute(targetHash);
    } else {
      window.location.hash = targetHash;
    }
  };

  // Parse active route
  const parsedRoute = useMemo(() => {
    const clean = hashRoute.replace(/^#/, '') || '/';
    if (clean.startsWith('/career/')) {
      const id = clean.replace('/career/', '').trim();
      return { view: 'career' as const, careerId: id };
    }
    if (clean.startsWith('/quiz')) {
      return { view: 'quiz' as const, careerId: null };
    }
    return { view: 'home' as const, careerId: null };
  }, [hashRoute]);

  const activeCareer = useMemo(() => {
    if (parsedRoute.view !== 'career' || !parsedRoute.careerId) return null;
    return (
      data.children.find((c) => c.id === parsedRoute.careerId) ||
      data.children[0]
    );
  }, [parsedRoute, data.children]);

  const compareLeft = useMemo(
    () =>
      data.children.find((c) => c.id === compareLeftId) || data.children[0],
    [data.children, compareLeftId]
  );
  const compareRight = useMemo(
    () =>
      data.children.find((c) => c.id === compareRightId) || data.children[1],
    [data.children, compareRightId]
  );

  const filteredChildren = useMemo(() => {
    if (selectedCategory === 'all') return data.children;
    return data.children.filter((c) => c.categoryId === selectedCategory);
  }, [data.children, selectedCategory]);

  const emiStats = useMemo(() => calculateLoanEmi(500000, 9, 5), []);

  const quizResult = useMemo(() => {
    if (quizAnswers.length < QUIZ_QUESTIONS.length) return null;
    return evaluateDeterministicQuiz(quizAnswers, data.children);
  }, [quizAnswers, data.children]);

  const isDark = theme === 'dark';

  // Trigger 1-page Parent Print Summary
  const handleParentPrintSummary = (career: CareerChild) => {
    setPrintPreviewCareer(career);
    try {
      window.print();
    } catch {
      // ignore if headless browser blocks print dialog
    }
  };

  const getWhatsAppShareUrl = (career: CareerChild) => {
    const text =
      lang === 'en'
        ? `CareerPathO Blueprint: ${career.title.en} | Cost: ${career.totalCost.en} | Entry Salary: ${career.salaryRange.en} | Plan B: ${career.planBSummary.en} | Verified: ${career.lastVerified}`
        : `CareerPathO ब्लूप्रिंट: ${career.title.hi} | कुल लागत: ${career.totalCost.hi} | शुरुआती सैलरी: ${career.salaryRange.hi} | Plan B: ${career.planBSummary.hi}`;
    return `https://wa.me/?text=${encodeURIComponent(text)}`;
  };

  const handleSelectQuizOption = (optionIndex: number) => {
    const updated = [...quizAnswers];
    updated[currentQuizStep] = optionIndex;
    setQuizAnswers(updated);
    if (currentQuizStep + 1 < QUIZ_QUESTIONS.length) {
      setCurrentQuizStep(currentQuizStep + 1);
    }
  };

  const handleSimulateMixedVibesConflict = () => {
    // Spread answers across all 5 career tracks so top scores tie closely
    setQuizAnswers([0, 0, 2, 1, 1, 1, 2, 3, 2, 0]);
    setCurrentQuizStep(QUIZ_QUESTIONS.length - 1);
  };

  const handleResetQuiz = () => {
    setQuizAnswers([]);
    setCurrentQuizStep(0);
  };

  return (
    <div
      data-testid="careerpatho-blueprint-root"
      data-blueprint-theme={theme}
      data-blueprint-lang={lang}
      className={`min-h-screen font-sans transition-colors duration-150 ${
        isDark ? 'bg-[#09090B] text-[#FAFAFA]' : 'bg-[#FAFAFA] text-[#09090B]'
      }`}
      style={{
        backgroundImage: isDark
          ? 'linear-gradient(to right, rgba(255,255,255,0.04) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.04) 1px, transparent 1px)'
          : 'linear-gradient(to right, rgba(0,0,0,0.05) 1px, transparent 1px), linear-gradient(to bottom, rgba(0,0,0,0.05) 1px, transparent 1px)',
        backgroundSize: '28px 28px',
      }}
    >
      {/* =====================================================================
          ARCHITECTURAL BLUEPRINT TOP BAR
         ===================================================================== */}
      <header
        className={`sticky top-0 z-30 border-b px-4 sm:px-8 py-3 ${
          isDark
            ? 'bg-[#09090B]/95 border-zinc-800'
            : 'bg-[#FAFAFA]/95 border-zinc-300'
        }`}
      >
        <div className="max-w-[1380px] mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Brand Lockup */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => navigateHash('#/')}
              className={`text-left font-mono font-bold tracking-tight text-base sm:text-lg px-2.5 py-1 border cursor-pointer ${
                isDark
                  ? 'bg-white text-black border-white'
                  : 'bg-black text-white border-black'
              }`}
            >
              CAREERPATHO // IN
            </button>
            <span
              className={`hidden md:inline-block text-xs font-mono ${
                isDark ? 'text-zinc-400' : 'text-zinc-600'
              }`}
            >
              {lang === 'en'
                ? 'INDIA CAREER ARCHITECTURE · ZERO-SHAME PLAN B'
                : 'भारतीय करियर आर्किटेक्चर · मजबूत PLAN B गाइड'}
            </span>
          </div>

          {/* Hash Navigation Links (#/, #/quiz, #/career/btech-cse) */}
          <nav
            aria-label="CareerPathO Primary Navigation"
            className="flex flex-wrap items-center gap-1.5 text-xs font-mono"
          >
            <button
              type="button"
              data-testid="nav-home-link"
              onClick={() => navigateHash('#/')}
              className={`px-3 py-1.5 border transition-colors whitespace-nowrap cursor-pointer ${
                parsedRoute.view === 'home'
                  ? isDark
                    ? 'bg-white text-black border-white font-bold'
                    : 'bg-black text-white border-black font-bold'
                  : isDark
                    ? 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-500'
                    : 'bg-white text-zinc-700 border-zinc-300 hover:border-zinc-700'
              }`}
            >
              {lang === 'en' ? '01. Blueprints (#/)' : '01. होम (#/)'}
            </button>

            <button
              type="button"
              data-testid="nav-quiz-link"
              onClick={() => navigateHash('#/quiz')}
              className={`px-3 py-1.5 border transition-colors whitespace-nowrap cursor-pointer ${
                parsedRoute.view === 'quiz'
                  ? isDark
                    ? 'bg-white text-black border-white font-bold'
                    : 'bg-black text-white border-black font-bold'
                  : isDark
                    ? 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-500'
                    : 'bg-white text-zinc-700 border-zinc-300 hover:border-zinc-700'
              }`}
            >
              {lang === 'en'
                ? '02. 10-Q Quiz (#/quiz)'
                : '02. 10-प्रश्न क्विज़ (#/quiz)'}
            </button>

            <button
              type="button"
              data-testid="nav-sample-career-link"
              onClick={() => navigateHash('#/career/btech-cse')}
              className={`px-3 py-1.5 border transition-colors whitespace-nowrap cursor-pointer ${
                parsedRoute.view === 'career'
                  ? isDark
                    ? 'bg-white text-black border-white font-bold'
                    : 'bg-black text-white border-black font-bold'
                  : isDark
                    ? 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-500'
                    : 'bg-white text-zinc-700 border-zinc-300 hover:border-zinc-700'
              }`}
            >
              {lang === 'en'
                ? '03. B.Tech Blueprint'
                : '03. B.Tech ब्लूप्रिंट'}
            </button>
          </nav>

          {/* Bilingual Toggle (EN/HI) + Monochrome Dark/Light Toggle + Single-File Code & Chess Switch */}
          <div className="flex flex-wrap items-center gap-1.5 font-mono text-xs">
            <button
              type="button"
              data-testid="bilingual-toggle-btn"
              onClick={() => setLang((l) => (l === 'en' ? 'hi' : 'en'))}
              title={
                lang === 'en'
                  ? 'Switch to Hindi (हिंदी में बदलें)'
                  : 'Switch to English (अंग्रेजी में बदलें)'
              }
              className={`px-2.5 py-1.5 border font-bold whitespace-nowrap cursor-pointer ${
                isDark
                  ? 'bg-zinc-900 text-white border-zinc-600 hover:bg-zinc-800'
                  : 'bg-white text-black border-zinc-400 hover:bg-zinc-100'
              }`}
            >
              {lang === 'en' ? 'LANG: EN → हिंदी' : 'भाषा: हिंदी → EN'}
            </button>

            <button
              type="button"
              data-testid="monochrome-theme-toggle-btn"
              onClick={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
              title="Toggle Monochrome Dark / Light Blueprint Mode"
              className={`px-2.5 py-1.5 border font-bold whitespace-nowrap cursor-pointer ${
                isDark
                  ? 'bg-zinc-900 text-white border-zinc-600 hover:bg-zinc-800'
                  : 'bg-white text-black border-zinc-400 hover:bg-zinc-100'
              }`}
            >
              {isDark
                ? lang === 'en'
                  ? 'MODE: MONO DARK'
                  : 'मोड: डार्क'
                : lang === 'en'
                  ? 'MODE: MONO LIGHT'
                  : 'मोड: लाइट'}
            </button>

            {onOpenSingleFileModal && (
              <button
                type="button"
                data-testid="open-single-file-export-btn"
                onClick={onOpenSingleFileModal}
                className={`px-2.5 py-1.5 border font-bold whitespace-nowrap cursor-pointer ${
                  isDark
                    ? 'bg-white text-black border-white hover:bg-zinc-200'
                    : 'bg-black text-white border-black hover:bg-zinc-800'
                }`}
              >
                {lang === 'en'
                  ? '📄 Single-File index.html'
                  : '📄 Single-File कोड'}
              </button>
            )}

            {onSwitchToChessArena && (
              <button
                type="button"
                data-testid="switch-to-chess-arena-btn"
                onClick={onSwitchToChessArena}
                className={`px-2.5 py-1.5 border font-bold whitespace-nowrap cursor-pointer ${
                  isDark
                    ? 'bg-zinc-900 text-zinc-200 border-zinc-700 hover:border-white'
                    : 'bg-zinc-100 text-zinc-900 border-zinc-400 hover:border-black'
                }`}
              >
                {lang === 'en' ? '♟ AI Chess Arena' : '♟ शतरंज एरीना'}
              </button>
            )}
          </div>
        </div>
      </header>

      {/* =====================================================================
          MAIN VIEWPORT ROUTER (#/, #/quiz, #/career/:id)
         ===================================================================== */}
      <main className="max-w-[1380px] mx-auto px-4 sm:px-8 py-6 space-y-8">
        {/* -------------------------------------------------------------------
            VIEW 1: HOMEPAGE (#/)
           ------------------------------------------------------------------- */}
        {parsedRoute.view === 'home' && (
          <div className="space-y-8">
            {/* Architectural Hero + Pillar 7: Funding Progress Block */}
            <section
              className={`grid grid-cols-1 lg:grid-cols-12 border ${
                isDark
                  ? 'bg-[#09090B] border-zinc-800'
                  : 'bg-white border-zinc-300'
              }`}
            >
              <div
                className={`lg:col-span-8 p-6 sm:p-8 border-b lg:border-b-0 lg:border-r ${
                  isDark ? 'border-zinc-800' : 'border-zinc-300'
                } space-y-4`}
              >
                <div className="text-xs font-mono uppercase tracking-widest opacity-70">
                  {lang === 'en'
                    ? 'ARCHITECTURAL CAREER SPECIFICATION · INDIA EDITION'
                    : 'भारतीय छात्रों और अभिभावकों के लिए पारदर्शी करियर ब्लूप्रिंट'}
                </div>
                <h1 className="text-2xl sm:text-4xl font-bold tracking-tight leading-tight">
                  {lang === 'en'
                    ? 'Every Indian Career Audited by Total Cost, Real Starting Pay & Plan B.'
                    : 'हर करियर की कुल लागत, शुरुआती सैलरी, EMI और Plan B का सटीक हिसाब।'}
                </h1>
                <p
                  className={`text-sm sm:text-base leading-relaxed max-w-2xl ${
                    isDark ? 'text-zinc-400' : 'text-zinc-600'
                  }`}
                >
                  {lang === 'en'
                    ? 'No ed-tech hype. Inspect realistic tuition outlays, ₹5L education loan EMI math, cutoff ranks, and deterministic Plan B pivots for B.Tech, BCA, MBBS, ICAI CA, UPSC, and B.Des.'
                    : 'कोई कोचिंग विज्ञापन नहीं। B.Tech, BCA, MBBS, ICAI CA, UPSC और B.Des की वास्तविक फीस, ₹5L लोन EMI और सुरक्षित Plan B विकल्प देखें।'}
                </p>
                <div className="pt-2 flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    data-testid="hero-start-quiz-btn"
                    onClick={() => navigateHash('#/quiz')}
                    className={`px-5 py-2.5 text-xs sm:text-sm font-mono font-bold border cursor-pointer ${
                      isDark
                        ? 'bg-white text-black border-white hover:bg-zinc-200'
                        : 'bg-black text-white border-black hover:bg-zinc-800'
                    }`}
                  >
                    {lang === 'en'
                      ? 'LAUNCH 10-QUESTION DETERMINISTIC QUIZ →'
                      : '10-प्रश्न करियर क्विज़ शुरू करें →'}
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateHash('#/career/btech-cse')}
                    className={`px-4 py-2.5 text-xs sm:text-sm font-mono border cursor-pointer ${
                      isDark
                        ? 'bg-zinc-900 text-zinc-200 border-zinc-700 hover:border-white'
                        : 'bg-zinc-100 text-zinc-900 border-zinc-400 hover:border-black'
                    }`}
                  >
                    {lang === 'en'
                      ? 'INSPECT B.TECH CSE BLUEPRINT'
                      : 'B.Tech CSE ब्लूप्रिंट देखें'}
                  </button>
                </div>
              </div>

              {/* PILLAR 7: FUNDING PROGRESS BLOCK (₹6,450 / ₹10,000 INR) */}
              <div
                data-testid="funding-progress-block"
                className="lg:col-span-4 p-6 sm:p-8 flex flex-col justify-between space-y-4"
              >
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="uppercase tracking-wider opacity-75">
                      {lang === 'en'
                        ? 'COMMUNITY INFRASTRUCTURE GRANT'
                        : 'कम्युनिटी फंडिंग प्रगति'}
                    </span>
                    <span className="font-bold tabular-nums">64.5%</span>
                  </div>
                  <div
                    data-testid="funding-amount-readout"
                    className="text-xl sm:text-2xl font-mono font-bold tabular-nums"
                  >
                    ₹6,450 / ₹10,000 INR
                  </div>
                  <p
                    className={`text-xs leading-relaxed ${
                      isDark ? 'text-zinc-400' : 'text-zinc-600'
                    }`}
                  >
                    {lang === 'en'
                      ? '100% free & ad-free public utility. Unlocking the offline AI Mentor tab inside the Learning Modal once community funding hits ₹10,000 INR.'
                      : '100% निःशुल्क और विज्ञापन-मुक्त। ₹10,000 INR फंडिंग पूरी होने पर लर्निंग मोडल में AI Mentor अनलॉक होगा।'}
                  </p>
                </div>

                <div className="space-y-2">
                  <div
                    className={`w-full h-3 border overflow-hidden ${
                      isDark
                        ? 'bg-zinc-900 border-zinc-700'
                        : 'bg-zinc-200 border-zinc-400'
                    }`}
                  >
                    <div
                      className={`h-full transition-all duration-300 ${
                        isDark ? 'bg-white' : 'bg-black'
                      }`}
                      style={{ width: '64.5%' }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[11px] font-mono opacity-75 tabular-nums">
                    <span>
                      {lang === 'en'
                        ? 'Remaining: ₹3,550 INR'
                        : 'शेष लक्ष्य: ₹3,550 INR'}
                    </span>
                    <span>localStorage Verified</span>
                  </div>
                </div>
              </div>
            </section>

            {/* Category Filter & Career Blueprints Grid */}
            <section className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h2 className="text-lg sm:text-xl font-mono font-bold uppercase tracking-tight">
                  {lang === 'en'
                    ? '01. Audited Career Blueprints'
                    : '01. प्रमाणित करियर ब्लूप्रिंट'}
                </h2>
                <div className="flex flex-wrap items-center gap-1.5">
                  {data.categories.map((cat) => (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`px-3 py-1 text-xs font-mono border cursor-pointer ${
                        selectedCategory === cat.id
                          ? isDark
                            ? 'bg-white text-black border-white font-bold'
                            : 'bg-black text-white border-black font-bold'
                          : isDark
                            ? 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-600'
                            : 'bg-white text-zinc-700 border-zinc-300 hover:border-zinc-600'
                      }`}
                    >
                      {cat.name[lang]}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredChildren.map((career) => (
                  <article
                    key={career.id}
                    data-testid={`career-card-${career.id}`}
                    className={`border p-5 flex flex-col justify-between space-y-4 transition-colors ${
                      isDark
                        ? 'bg-[#09090B] border-zinc-800 hover:border-zinc-400'
                        : 'bg-white border-zinc-300 hover:border-black'
                    }`}
                  >
                    <div className="space-y-3">
                      <div className="flex items-center justify-between font-mono text-xs opacity-75">
                        <span>
                          {career.icon} {career.code}
                        </span>
                        <span>{career.difficulty[lang]}</span>
                      </div>
                      <h3 className="text-base sm:text-lg font-bold leading-snug">
                        {career.title[lang]}
                      </h3>
                      <p
                        className={`text-xs leading-relaxed ${
                          isDark ? 'text-zinc-400' : 'text-zinc-600'
                        }`}
                      >
                        {career.tagline[lang]}
                      </p>
                    </div>

                    <div className="space-y-3 pt-2 border-t border-zinc-800/60">
                      <div className="grid grid-cols-2 gap-2 text-xs font-mono tabular-nums">
                        <div>
                          <div className="opacity-60 text-[10px]">
                            {lang === 'en' ? 'ENTRY SALARY' : 'शुरुआती सैलरी'}
                          </div>
                          <div className="font-bold">
                            {career.salaryRange[lang]}
                          </div>
                        </div>
                        <div>
                          <div className="opacity-60 text-[10px]">
                            {lang === 'en' ? 'TOTAL COST' : 'कुल लागत'}
                          </div>
                          <div className="font-bold">
                            {career.totalCost[lang]}
                          </div>
                        </div>
                      </div>

                      <div
                        className={`p-2 text-[11px] font-mono border ${
                          isDark
                            ? 'bg-zinc-900/80 border-zinc-800 text-zinc-300'
                            : 'bg-zinc-100 border-zinc-300 text-zinc-800'
                        }`}
                      >
                        <strong>Plan B:</strong> {career.planBSummary[lang]}
                      </div>

                      <button
                        type="button"
                        data-testid={`open-career-${career.id}`}
                        onClick={() => navigateHash(`#/career/${career.id}`)}
                        className={`w-full py-2 text-xs font-mono font-bold border text-center cursor-pointer ${
                          isDark
                            ? 'bg-white text-black border-white hover:bg-zinc-200'
                            : 'bg-black text-white border-black hover:bg-zinc-800'
                        }`}
                      >
                        {lang === 'en'
                          ? 'OPEN FULL ARCHITECTURAL BLUEPRINT →'
                          : 'पूरा ब्लूप्रिंट और रोडमैप देखें →'}
                      </button>
                    </div>
                  </article>
                ))}
              </div>
            </section>

            {/* PILLAR 5: THE COMPARE TOOL (HOMEPAGE) */}
            <section
              data-testid="career-compare-section"
              className={`border p-6 space-y-4 ${
                isDark
                  ? 'bg-[#09090B] border-zinc-800'
                  : 'bg-white border-zinc-300'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 border-b pb-4 border-zinc-800/60">
                <div>
                  <h2 className="text-lg font-mono font-bold uppercase">
                    {lang === 'en'
                      ? '02. Side-by-Side Career Blueprint Matrix'
                      : '02. दो करियर की सीधी तुलना (Compare Tool)'}
                  </h2>
                  <p
                    className={`text-xs ${
                      isDark ? 'text-zinc-400' : 'text-zinc-600'
                    }`}
                  >
                    {lang === 'en'
                      ? 'Compare Total Cost, Entry Salary, Core Exams, and Plan B side-by-side.'
                      : 'कुल लागत, शुरुआती सैलरी, प्रवेश परीक्षा और Plan B की आमने-सामने तुलना करें।'}
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <label
                      htmlFor="compare-left-select"
                      className="sr-only"
                    >
                      Compare Career A
                    </label>
                    <select
                      id="compare-left-select"
                      data-testid="compare-left-select"
                      aria-label="Select First Career to Compare"
                      value={compareLeftId}
                      onChange={(e) => setCompareLeftId(e.target.value)}
                      className={`w-full px-3 py-2 text-xs font-mono border cursor-pointer ${
                        isDark
                          ? 'bg-zinc-900 text-white border-zinc-700'
                          : 'bg-zinc-100 text-black border-zinc-400'
                      }`}
                    >
                      {data.children.map((c) => (
                        <option key={c.id} value={c.id}>
                          A: {c.title[lang]}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label
                      htmlFor="compare-right-select"
                      className="sr-only"
                    >
                      Compare Career B
                    </label>
                    <select
                      id="compare-right-select"
                      data-testid="compare-right-select"
                      aria-label="Select Second Career to Compare"
                      value={compareRightId}
                      onChange={(e) => setCompareRightId(e.target.value)}
                      className={`w-full px-3 py-2 text-xs font-mono border cursor-pointer ${
                        isDark
                          ? 'bg-zinc-900 text-white border-zinc-700'
                          : 'bg-zinc-100 text-black border-zinc-400'
                      }`}
                    >
                      {data.children.map((c) => (
                        <option key={c.id} value={c.id}>
                          B: {c.title[lang]}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table
                  data-testid="compare-table"
                  className="w-full text-left border-collapse font-mono text-xs tabular-nums"
                >
                  <thead>
                    <tr
                      className={`border-b ${
                        isDark
                          ? 'border-zinc-800 bg-zinc-900/60'
                          : 'border-zinc-300 bg-zinc-100'
                      }`}
                    >
                      <th className="p-3 w-1/4">
                        {lang === 'en' ? 'PARAMETER' : 'मापदंड (Metric)'}
                      </th>
                      <th className="p-3 w-3/8">
                        {compareLeft.code} · {compareLeft.title[lang]}
                      </th>
                      <th className="p-3 w-3/8">
                        {compareRight.code} · {compareRight.title[lang]}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/50">
                    <tr>
                      <td className="p-3 font-bold">
                        {lang === 'en' ? 'Total Cost' : 'कुल लागत (Cost)'}
                      </td>
                      <td className="p-3">{compareLeft.totalCost[lang]}</td>
                      <td className="p-3">{compareRight.totalCost[lang]}</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-bold">
                        {lang === 'en' ? 'Entry Salary' : 'शुरुआती सैलरी'}
                      </td>
                      <td className="p-3">{compareLeft.salaryRange[lang]}</td>
                      <td className="p-3">{compareRight.salaryRange[lang]}</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-bold">
                        {lang === 'en' ? 'Primary Exams' : 'मुख्य परीक्षाएं'}
                      </td>
                      <td className="p-3">{compareLeft.primaryExams}</td>
                      <td className="p-3">{compareRight.primaryExams}</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-bold">
                        {lang === 'en' ? 'Difficulty' : 'कठिनाई स्तर'}
                      </td>
                      <td className="p-3">{compareLeft.difficulty[lang]}</td>
                      <td className="p-3">{compareRight.difficulty[lang]}</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-bold">
                        {lang === 'en'
                          ? 'Plan B Safety Net'
                          : 'Plan B सुरक्षा विकल्प'}
                      </td>
                      <td className="p-3">{compareLeft.planBSummary[lang]}</td>
                      <td className="p-3">{compareRight.planBSummary[lang]}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </section>

            {/* Parents Section & Coming Soon Blueprints */}
            <section className="grid grid-cols-1 lg:grid-cols-12 gap-4">
              <div
                className={`lg:col-span-8 border p-6 space-y-4 ${
                  isDark
                    ? 'bg-[#09090B] border-zinc-800'
                    : 'bg-white border-zinc-300'
                }`}
              >
                <h2 className="text-base sm:text-lg font-mono font-bold uppercase">
                  03. {data.parents.headline[lang]}
                </h2>
                <p
                  className={`text-xs sm:text-sm ${
                    isDark ? 'text-zinc-400' : 'text-zinc-600'
                  }`}
                >
                  {data.parents.subheadline[lang]}
                </p>
                <ul className="space-y-2 text-xs font-mono">
                  {data.parents.Checklist.map((item, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <span>[{i + 1}]</span>
                      <span>{item[lang]}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div
                className={`lg:col-span-4 border p-6 space-y-3 ${
                  isDark
                    ? 'bg-[#09090B] border-zinc-800'
                    : 'bg-white border-zinc-300'
                }`}
              >
                <h2 className="text-base font-mono font-bold uppercase">
                  {lang === 'en'
                    ? '04. Upcoming Audits'
                    : '04. आगामी करियर ब्लूप्रिंट'}
                </h2>
                <div className="space-y-2">
                  {data.comingSoon.map((cs) => (
                    <div
                      key={cs.id}
                      className={`p-3 border text-xs font-mono flex items-center justify-between gap-2 ${
                        isDark
                          ? 'bg-zinc-900/70 border-zinc-800'
                          : 'bg-zinc-100 border-zinc-300'
                      }`}
                    >
                      <span>{cs.title[lang]}</span>
                      <span className="opacity-65 shrink-0">
                        {cs.eta[lang]}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </section>
          </div>
        )}

        {/* -------------------------------------------------------------------
            VIEW 2: THE DETERMINISTIC QUIZ (#/quiz) — 10 Interactive Questions
           ------------------------------------------------------------------- */}
        {parsedRoute.view === 'quiz' && (
          <section
            data-testid="deterministic-quiz-view"
            className={`border p-6 sm:p-8 space-y-6 ${
              isDark
                ? 'bg-[#09090B] border-zinc-800'
                : 'bg-white border-zinc-300'
            }`}
          >
            <div className="flex flex-wrap items-center justify-between gap-2 border-b pb-4 border-zinc-800/60">
              <div>
                <div className="text-xs font-mono uppercase opacity-70">
                  {lang === 'en'
                    ? 'PILLAR 01 · DETERMINISTIC WEIGHTED SCORING ENGINE'
                    : 'पिलर 01 · 10-प्रश्न निर्धारित करियर स्कोरिंग इंजन'}
                </div>
                <h1 className="text-xl sm:text-2xl font-bold mt-1">
                  {lang === 'en'
                    ? '10-Question Career Architecture Diagnostic'
                    : '10-प्रश्न करियर आर्किटेक्चर मूल्यांकन'}
                </h1>
              </div>

              <div className="flex items-center gap-2 font-mono text-xs">
                <button
                  type="button"
                  data-testid="quiz-conflict-demo-btn"
                  onClick={handleSimulateMixedVibesConflict}
                  className={`px-3 py-1.5 border cursor-pointer ${
                    isDark
                      ? 'bg-zinc-900 text-zinc-200 border-zinc-700 hover:border-white'
                      : 'bg-zinc-100 text-zinc-900 border-zinc-400 hover:border-black'
                  }`}
                >
                  {lang === 'en'
                    ? 'Test Conflict Fallback ("Mixed Vibes")'
                    : 'मिश्रित उत्तर (Fallback) टेस्ट करें'}
                </button>
                <button
                  type="button"
                  onClick={handleResetQuiz}
                  className={`px-3 py-1.5 border cursor-pointer ${
                    isDark
                      ? 'bg-zinc-900 text-zinc-300 border-zinc-700'
                      : 'bg-zinc-100 text-zinc-800 border-zinc-400'
                  }`}
                >
                  {lang === 'en' ? 'Reset Quiz' : 'रीसेट करें'}
                </button>
              </div>
            </div>

            {/* Step Progress Strip */}
            <div className="grid grid-cols-10 gap-1">
              {QUIZ_QUESTIONS.map((q, idx) => {
                const answered = typeof quizAnswers[idx] === 'number';
                const isCurrent = idx === currentQuizStep && !quizResult;
                return (
                  <button
                    key={q.id}
                    type="button"
                    onClick={() => setCurrentQuizStep(idx)}
                    className={`h-8 text-xs font-mono font-bold border transition-colors cursor-pointer tabular-nums ${
                      isCurrent
                        ? isDark
                          ? 'bg-white text-black border-white'
                          : 'bg-black text-white border-black'
                        : answered
                          ? isDark
                            ? 'bg-zinc-800 text-white border-zinc-600'
                            : 'bg-zinc-300 text-black border-zinc-500'
                          : isDark
                            ? 'bg-zinc-950 text-zinc-500 border-zinc-800'
                            : 'bg-zinc-100 text-zinc-500 border-zinc-300'
                    }`}
                  >
                    Q{idx + 1}
                  </button>
                );
              })}
            </div>

            {/* Active Question Card */}
            {!quizResult && QUIZ_QUESTIONS[currentQuizStep] && (
              <div
                data-testid="quiz-question-card"
                className="space-y-4 py-2"
              >
                <div className="text-xs font-mono opacity-70 tabular-nums">
                  {lang === 'en'
                    ? `QUESTION ${currentQuizStep + 1} OF ${QUIZ_QUESTIONS.length}`
                    : `प्रश्न ${currentQuizStep + 1} / ${QUIZ_QUESTIONS.length}`}
                </div>
                <h2 className="text-lg sm:text-xl font-bold">
                  {QUIZ_QUESTIONS[currentQuizStep].prompt[lang]}
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {QUIZ_QUESTIONS[currentQuizStep].options.map((opt, oIdx) => {
                    const isSelected = quizAnswers[currentQuizStep] === oIdx;
                    return (
                      <button
                        key={oIdx}
                        type="button"
                        data-testid={`quiz-option-${oIdx}`}
                        onClick={() => handleSelectQuizOption(oIdx)}
                        className={`p-4 text-left border font-mono text-xs sm:text-sm transition-colors cursor-pointer ${
                          isSelected
                            ? isDark
                              ? 'bg-white text-black border-white font-bold'
                              : 'bg-black text-white border-black font-bold'
                            : isDark
                              ? 'bg-zinc-900/90 text-zinc-200 border-zinc-800 hover:border-zinc-400'
                              : 'bg-zinc-50 text-zinc-900 border-zinc-300 hover:border-black'
                        }`}
                      >
                        <span className="opacity-60 mr-2">
                          [{String.fromCharCode(65 + oIdx)}]
                        </span>
                        {opt.label[lang]}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Quiz Result: Top 3 Career Matches + Conflict Fallback */}
            {quizResult && (
              <div
                data-testid="quiz-results-panel"
                className="space-y-5 pt-2 border-t border-zinc-800"
              >
                <div
                  data-testid="quiz-status-banner"
                  className={`p-4 border font-mono text-xs sm:text-sm ${
                    isDark
                      ? 'bg-zinc-900 border-white text-white'
                      : 'bg-zinc-100 border-black text-black'
                  }`}
                >
                  <strong>
                    {quizResult.isMixedConflict
                      ? lang === 'en'
                        ? 'CONFLICT DETECTED: '
                        : 'मिश्रित संकेत: '
                      : lang === 'en'
                        ? 'TOP 3 MATCHES: '
                        : 'शीर्ष 3 करियर मैच: '}
                  </strong>
                  <span>
                    {lang === 'en'
                      ? quizResult.messageEn
                      : quizResult.messageHi}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {quizResult.topMatches.map((match, rankIdx) => (
                    <div
                      key={match.career.id}
                      data-testid={`quiz-match-rank-${rankIdx + 1}`}
                      className={`p-5 border flex flex-col justify-between space-y-4 ${
                        isDark
                          ? 'bg-zinc-950 border-zinc-700'
                          : 'bg-zinc-50 border-zinc-400'
                      }`}
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between font-mono text-xs">
                          <span className="font-bold">
                            RANK #{rankIdx + 1} · {match.career.code}
                          </span>
                          <span className="tabular-nums">
                            {match.matchPercentage}% FIT ({match.score} pts)
                          </span>
                        </div>
                        <h3 className="text-base font-bold">
                          {match.career.title[lang]}
                        </h3>
                        <p className="text-xs opacity-80">
                          {match.career.tagline[lang]}
                        </p>
                      </div>

                      <div className="space-y-2 pt-2 border-t border-zinc-800/50 text-xs font-mono">
                        <div>
                          <strong>Cost:</strong> {match.career.totalCost[lang]}
                        </div>
                        <div>
                          <strong>Salary:</strong>{' '}
                          {match.career.salaryRange[lang]}
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            navigateHash(`#/career/${match.career.id}`)
                          }
                          className={`w-full mt-2 py-2 font-bold border cursor-pointer ${
                            isDark
                              ? 'bg-white text-black border-white'
                              : 'bg-black text-white border-black'
                          }`}
                        >
                          {lang === 'en'
                            ? 'INSPECT BLUEPRINT →'
                            : 'ब्लूप्रिंट खोलें →'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {quizResult.isMixedConflict && (
                  <button
                    type="button"
                    onClick={() => navigateHash('#/')}
                    className={`px-4 py-2 text-xs font-mono font-bold border cursor-pointer ${
                      isDark
                        ? 'bg-white text-black border-white'
                        : 'bg-black text-white border-black'
                    }`}
                  >
                    {lang === 'en'
                      ? 'BROWSE ALL CAREER BLUEPRINTS (#/) →'
                      : 'सभी करियर ब्लूप्रिंट देखें (#/) →'}
                  </button>
                )}
              </div>
            )}
          </section>
        )}

        {/* -------------------------------------------------------------------
            VIEW 3: THE CHILD CAREER PAGE (#/career/:id)
           ------------------------------------------------------------------- */}
        {parsedRoute.view === 'career' && activeCareer && (
          <div
            data-testid="child-career-page"
            className="space-y-6"
          >
            {/* Top Back & Action Strip */}
            <div className="flex flex-wrap items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => navigateHash('#/')}
                className={`px-3 py-1.5 text-xs font-mono border cursor-pointer ${
                  isDark
                    ? 'bg-zinc-900 text-zinc-200 border-zinc-700 hover:border-white'
                    : 'bg-white text-zinc-900 border-zinc-400 hover:border-black'
                }`}
              >
                {lang === 'en'
                  ? '← BACK TO ALL BLUEPRINTS (#/)'
                  : '← सभी ब्लूप्रिंट पर वापस जाएं (#/)'}
              </button>

              {/* Career Quick Switcher */}
              <div className="flex flex-wrap items-center gap-1.5">
                {data.children.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => navigateHash(`#/career/${c.id}`)}
                    className={`px-2.5 py-1 text-xs font-mono border cursor-pointer ${
                      c.id === activeCareer.id
                        ? isDark
                          ? 'bg-white text-black border-white font-bold'
                          : 'bg-black text-white border-black font-bold'
                        : isDark
                          ? 'bg-zinc-900 text-zinc-400 border-zinc-800'
                          : 'bg-white text-zinc-700 border-zinc-300'
                    }`}
                  >
                    {c.code}
                  </button>
                ))}
              </div>
            </div>

            {/* 1. HERO: Icon, Title, Tagline, Salary Range, Total Cost, Difficulty + Parent PDF & WhatsApp & Learning Modal */}
            <section
              data-testid="career-hero-section"
              className={`border p-6 sm:p-8 space-y-6 ${
                isDark
                  ? 'bg-[#09090B] border-zinc-800'
                  : 'bg-white border-zinc-300'
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                <div className="space-y-2 max-w-3xl">
                  <div className="flex items-center gap-2 font-mono text-xs opacity-75">
                    <span className="text-lg">{activeCareer.icon}</span>
                    <span>BLUEPRINT {activeCareer.code}</span>
                    <span>·</span>
                    <span>VERIFIED {activeCareer.lastVerified}</span>
                  </div>
                  <h1
                    data-testid="career-hero-title"
                    className="text-2xl sm:text-3xl font-bold tracking-tight"
                  >
                    {activeCareer.title[lang]}
                  </h1>
                  <p
                    className={`text-sm sm:text-base ${
                      isDark ? 'text-zinc-400' : 'text-zinc-600'
                    }`}
                  >
                    {activeCareer.tagline[lang]}
                  </p>
                </div>

                {/* Pillar 3 & Pillar 4 Action Buttons: Parent PDF Print, WhatsApp Share, Learning Modal */}
                <div className="flex flex-wrap items-center gap-2 shrink-0 font-mono text-xs">
                  <button
                    type="button"
                    data-testid="open-learning-modal-btn"
                    onClick={() => setLearningModalOpen(true)}
                    className={`px-3.5 py-2 font-bold border cursor-pointer ${
                      isDark
                        ? 'bg-white text-black border-white hover:bg-zinc-200'
                        : 'bg-black text-white border-black hover:bg-zinc-800'
                    }`}
                  >
                    {lang === 'en'
                      ? '📚 Open Learning Vault (8+1 Tabs)'
                      : '📚 लर्निंग वॉल्ट खोलें (8+1 टैब)'}
                  </button>

                  <button
                    type="button"
                    data-testid="parent-pdf-print-btn"
                    onClick={() => handleParentPrintSummary(activeCareer)}
                    className={`px-3.5 py-2 font-bold border cursor-pointer ${
                      isDark
                        ? 'bg-zinc-900 text-white border-zinc-600 hover:border-white'
                        : 'bg-zinc-100 text-black border-zinc-400 hover:border-black'
                    }`}
                  >
                    {lang === 'en'
                      ? '🖨 Parent 1-Page PDF / Print'
                      : '🖨 अभिभावक 1-पेज PDF प्रिंट'}
                  </button>

                  <a
                    href={getWhatsAppShareUrl(activeCareer)}
                    target="_blank"
                    rel="noopener noreferrer"
                    data-testid="whatsapp-share-link"
                    className={`px-3.5 py-2 font-bold border inline-block ${
                      isDark
                        ? 'bg-zinc-900 text-white border-zinc-600 hover:border-white'
                        : 'bg-zinc-100 text-black border-zinc-400 hover:border-black'
                    }`}
                  >
                    {lang === 'en' ? '↗ Share on WhatsApp' : '↗ WhatsApp शेयर'}
                  </a>
                </div>
              </div>

              {/* Hero 3-Metric Strip: Salary Range, Total Cost, Difficulty */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 border-t border-zinc-800/60 font-mono tabular-nums">
                <div
                  className={`p-4 border ${
                    isDark
                      ? 'bg-zinc-950 border-zinc-800'
                      : 'bg-zinc-50 border-zinc-300'
                  }`}
                >
                  <div className="text-[11px] opacity-65">
                    {lang === 'en'
                      ? 'ENTRY SALARY RANGE'
                      : 'शुरुआती सैलरी (Salary Range)'}
                  </div>
                  <div className="text-base sm:text-lg font-bold mt-1">
                    {activeCareer.salaryRange[lang]}
                  </div>
                </div>

                <div
                  className={`p-4 border ${
                    isDark
                      ? 'bg-zinc-950 border-zinc-800'
                      : 'bg-zinc-50 border-zinc-300'
                  }`}
                >
                  <div className="text-[11px] opacity-65">
                    {lang === 'en'
                      ? 'ESTIMATED TOTAL COST'
                      : 'अनुमानित कुल लागत (Total Cost)'}
                  </div>
                  <div className="text-base sm:text-lg font-bold mt-1">
                    {activeCareer.totalCost[lang]}
                  </div>
                </div>

                <div
                  className={`p-4 border ${
                    isDark
                      ? 'bg-zinc-950 border-zinc-800'
                      : 'bg-zinc-50 border-zinc-300'
                  }`}
                >
                  <div className="text-[11px] opacity-65">
                    {lang === 'en'
                      ? 'EXAM DIFFICULTY'
                      : 'परीक्षा कठिनाई (Difficulty)'}
                  </div>
                  <div className="text-base sm:text-lg font-bold mt-1">
                    {activeCareer.difficulty[lang]}
                  </div>
                </div>
              </div>
            </section>

            {/* 2. INTERACTIVE ROADMAP: Vertical Timeline with Expandable Steps & Plan B Linked Cards */}
            <section
              data-testid="interactive-roadmap-section"
              className={`border p-6 sm:p-8 space-y-5 ${
                isDark
                  ? 'bg-[#09090B] border-zinc-800'
                  : 'bg-white border-zinc-300'
              }`}
            >
              <div className="border-b pb-3 border-zinc-800/60">
                <h2 className="text-lg font-mono font-bold uppercase">
                  {lang === 'en'
                    ? 'Interactive Execution Roadmap & Linked Plan B Pivots'
                    : 'चरणबद्ध करियर रोडमैप और लिंक्ड Plan B विकल्प'}
                </h2>
                <p className="text-xs opacity-75 mt-0.5">
                  {lang === 'en'
                    ? 'Click any stage to expand or collapse. Every stage includes a clickable Plan B card.'
                    : 'विस्तार से देखने के लिए किसी भी चरण पर क्लिक करें। हर चरण में Plan B लिंक दिया गया है।'}
                </p>
              </div>

              <div className="space-y-4">
                {activeCareer.roadmap.map((step) => {
                  const isExpanded = expandedStepMap[step.stepNumber] ?? true;
                  return (
                    <div
                      key={step.stepNumber}
                      data-testid={`roadmap-step-${step.stepNumber}`}
                      className={`border ${
                        isDark
                          ? 'bg-zinc-950 border-zinc-800'
                          : 'bg-zinc-50 border-zinc-300'
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() =>
                          setExpandedStepMap((prev) => ({
                            ...prev,
                            [step.stepNumber]: !isExpanded,
                          }))
                        }
                        className="w-full p-4 flex items-center justify-between gap-3 text-left font-mono cursor-pointer"
                      >
                        <div className="flex items-center gap-3">
                          <span
                            className={`px-2 py-0.5 text-xs font-bold border ${
                              isDark
                                ? 'bg-white text-black border-white'
                                : 'bg-black text-white border-black'
                            }`}
                          >
                            STEP {step.stepNumber}
                          </span>
                          <span className="text-sm sm:text-base font-bold">
                            {step.stageTitle[lang]}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-xs opacity-75 shrink-0">
                          <span>{step.duration[lang]}</span>
                          <span>{isExpanded ? '[-]' : '[+]'}</span>
                        </div>
                      </button>

                      {isExpanded && (
                        <div className="px-4 pb-4 pt-2 border-t border-zinc-800/50 grid grid-cols-1 lg:grid-cols-12 gap-4">
                          <div className="lg:col-span-7 space-y-2">
                            <p className="text-xs sm:text-sm leading-relaxed">
                              {step.details[lang]}
                            </p>
                            <div className="text-xs font-mono opacity-75">
                              <strong>Milestone / Exam:</strong>{' '}
                              {step.keyExamOrMilestone}
                            </div>
                          </div>

                          {/* Linked Plan B Card */}
                          <div
                            data-testid={`plan-b-card-${step.stepNumber}`}
                            className={`lg:col-span-5 p-3.5 border font-mono text-xs space-y-2 ${
                              isDark
                                ? 'bg-zinc-900 border-zinc-600'
                                : 'bg-white border-zinc-500'
                            }`}
                          >
                            <div className="uppercase font-bold">
                              ⚡ PLAN B PIVOT · {step.planB.triggerCondition[lang]}
                            </div>
                            <p className="opacity-85 leading-relaxed">
                              {step.planB.rationale[lang]}
                            </p>
                            <button
                              type="button"
                              data-testid={`plan-b-link-${step.stepNumber}`}
                              onClick={() =>
                                navigateHash(
                                  `#/career/${step.planB.targetCareerId}`
                                )
                              }
                              className={`w-full py-1.5 px-2.5 text-left font-bold border cursor-pointer ${
                                isDark
                                  ? 'bg-white text-black border-white hover:bg-zinc-200'
                                  : 'bg-black text-white border-black hover:bg-zinc-800'
                              }`}
                            >
                              → {step.planB.targetCareerName[lang]} (
                              {step.planB.targetCareerId})
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </section>

            {/* 3. REALITY CHECK BOX (Cost vs. Salary + ₹5L Loan @ 9% EMI) & 4. THRIVE VS. RECONSIDER */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Reality Check Box */}
              <section
                data-testid="reality-check-box"
                className={`lg:col-span-5 border p-6 space-y-4 font-mono ${
                  isDark
                    ? 'bg-[#09090B] border-zinc-800'
                    : 'bg-white border-zinc-300'
                }`}
              >
                <div className="border-b pb-3 border-zinc-800/60">
                  <h2 className="text-base font-bold uppercase">
                    {lang === 'en'
                      ? 'Financial Reality Check & ₹5L Loan EMI'
                      : 'वित्तीय रियलिटी चेक और ₹5L लोन EMI'}
                  </h2>
                </div>

                <div className="space-y-2 text-xs tabular-nums">
                  <div className="flex justify-between py-1.5 border-b border-zinc-800/40">
                    <span>
                      {lang === 'en'
                        ? 'Estimated 4-Yr Outlay:'
                        : 'अनुमानित कुल खर्च:'}
                    </span>
                    <span className="font-bold">
                      {activeCareer.totalCost[lang]}
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-zinc-800/40">
                    <span>
                      {lang === 'en'
                        ? 'First-Year In-Hand (Est.):'
                        : 'शुरुआती मासिक इन-हैंड:'}
                    </span>
                    <span className="font-bold">
                      ₹{activeCareer.firstYearMonthlyInr.toLocaleString('en-IN')}{' '}
                      / mo
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-zinc-800/40">
                    <span>
                      {lang === 'en'
                        ? 'Standard Education Loan:'
                        : 'मानक एजुकेशन लोन:'}
                    </span>
                    <span className="font-bold">
                      ₹5,00,000 @ {emiStats.annualRatePercent}% p.a. (5 Yrs)
                    </span>
                  </div>
                  <div
                    data-testid="static-emi-readout"
                    className={`p-3 border mt-2 ${
                      isDark
                        ? 'bg-zinc-900 border-zinc-700'
                        : 'bg-zinc-100 border-zinc-400'
                    }`}
                  >
                    <div className="text-[11px] opacity-75">
                      {lang === 'en'
                        ? 'MONTHLY EMI (₹5L LOAN @ 9% FOR 60 MONTHS)'
                        : 'मासिक EMI (₹5 लाख लोन @ 9% ब्याज, 60 महीने)'}
                    </div>
                    <div className="text-lg font-bold mt-0.5">
                      ₹{emiStats.monthlyEmiInr.toLocaleString('en-IN')} / month
                    </div>
                    <div className="text-[11px] opacity-75 mt-1">
                      {lang === 'en'
                        ? `Total Payable: ₹${emiStats.totalPayableInr.toLocaleString('en-IN')} (Interest: ₹${emiStats.totalInterestInr.toLocaleString('en-IN')})`
                        : `कुल भुगतान: ₹${emiStats.totalPayableInr.toLocaleString('en-IN')} (कुल ब्याज: ₹${emiStats.totalInterestInr.toLocaleString('en-IN')})`}
                    </div>
                  </div>
                </div>
              </section>

              {/* Thrive vs. Reconsider */}
              <section
                data-testid="thrive-vs-reconsider-section"
                className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4"
              >
                <div
                  className={`border p-6 space-y-3 ${
                    isDark
                      ? 'bg-[#09090B] border-zinc-800'
                      : 'bg-white border-zinc-300'
                  }`}
                >
                  <h3 className="text-sm font-mono font-bold uppercase border-b pb-2 border-zinc-800/60">
                    {lang === 'en'
                      ? '✓ YOU WILL THRIVE IF'
                      : '✓ यह करियर आपके लिए है यदि'}
                  </h3>
                  <ul className="space-y-2.5 text-xs leading-relaxed">
                    {activeCareer.thriveIf.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="font-mono font-bold">+</span>
                        <span>{item[lang]}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div
                  className={`border p-6 space-y-3 ${
                    isDark
                      ? 'bg-[#09090B] border-zinc-800'
                      : 'bg-white border-zinc-300'
                  }`}
                >
                  <h3 className="text-sm font-mono font-bold uppercase border-b pb-2 border-zinc-800/60">
                    {lang === 'en'
                      ? '✕ RECONSIDER IF'
                      : '✕ पुनर्विचार करें यदि'}
                  </h3>
                  <ul className="space-y-2.5 text-xs leading-relaxed">
                    {activeCareer.reconsiderIf.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <span className="font-mono font-bold">-</span>
                        <span>{item[lang]}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </section>
            </div>

            {/* 5. COLLEGE & CUTOFF EXPLORER */}
            <section
              data-testid="college-cutoff-explorer"
              className={`border p-6 space-y-4 ${
                isDark
                  ? 'bg-[#09090B] border-zinc-800'
                  : 'bg-white border-zinc-300'
              }`}
            >
              <h2 className="text-base sm:text-lg font-mono font-bold uppercase">
                {lang === 'en'
                  ? 'Top Colleges, Entrance Cutoffs & Estimated Total Fees'
                  : 'शीर्ष कॉलेज, कटऑफ रैंक और अनुमानित कुल फीस'}
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse font-mono text-xs tabular-nums">
                  <thead>
                    <tr
                      className={`border-b ${
                        isDark
                          ? 'border-zinc-800 bg-zinc-900/60'
                          : 'border-zinc-300 bg-zinc-100'
                      }`}
                    >
                      <th className="p-3">
                        {lang === 'en' ? 'INSTITUTION' : 'संस्थान (College)'}
                      </th>
                      <th className="p-3">
                        {lang === 'en' ? 'LOCATION' : 'स्थान'}
                      </th>
                      <th className="p-3">
                        {lang === 'en' ? 'TARGET CUTOFF' : 'कटऑफ रैंक'}
                      </th>
                      <th className="p-3">
                        {lang === 'en' ? 'EST. TOTAL FEES' : 'कुल फीस'}
                      </th>
                      <th className="p-3">
                        {lang === 'en' ? 'AVG PLACEMENT' : 'औसत पैकेज'}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/50">
                    {activeCareer.colleges.map((col, idx) => (
                      <tr key={idx}>
                        <td className="p-3 font-bold">{col.collegeName}</td>
                        <td className="p-3">{col.location}</td>
                        <td className="p-3">{col.entranceCutoff[lang]}</td>
                        <td className="p-3 font-bold">
                          {col.estimatedTotalFees}
                        </td>
                        <td className="p-3">{col.avgPlacement}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>

            {/* Inline Print-Ready Parent 1-Page Summary Sheet (Shown when Parent PDF button clicked) */}
            {printPreviewCareer && (
              <section
                data-testid="parent-print-summary-sheet"
                className={`border-2 p-6 space-y-3 font-mono text-xs ${
                  isDark
                    ? 'bg-zinc-950 border-white text-white'
                    : 'bg-white border-black text-black'
                }`}
              >
                <div className="flex items-center justify-between border-b pb-2 border-zinc-600">
                  <strong>
                    CAREERPATHO 1-PAGE PARENT BRIEFING ({lang.toUpperCase()})
                  </strong>
                  <button
                    type="button"
                    onClick={() => setPrintPreviewCareer(null)}
                    className="underline cursor-pointer"
                  >
                    {lang === 'en' ? 'Close Preview' : 'बंद करें'}
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <div>
                    <strong>Career:</strong> {printPreviewCareer.title[lang]}
                  </div>
                  <div>
                    <strong>Total Cost:</strong>{' '}
                    {printPreviewCareer.totalCost[lang]}
                  </div>
                  <div>
                    <strong>Entry Salary:</strong>{' '}
                    {printPreviewCareer.salaryRange[lang]}
                  </div>
                  <div>
                    <strong>Plan B Safety Net:</strong>{' '}
                    {printPreviewCareer.planBSummary[lang]}
                  </div>
                  <div>
                    <strong>₹5L Loan EMI (9%):</strong> ₹
                    {emiStats.monthlyEmiInr.toLocaleString('en-IN')}/mo
                  </div>
                  <div>
                    <strong>Last Verified:</strong>{' '}
                    {printPreviewCareer.lastVerified}
                  </div>
                </div>
              </section>
            )}
          </div>
        )}
      </main>

      {/* =====================================================================
          PILLAR 4: THE LEARNING MODAL (8 Active Tabs + 9th Disabled AI Mentor Tab)
         ===================================================================== */}
      {learningModalOpen && activeCareer && (
        <div
          data-testid="learning-modal"
          role="dialog"
          aria-modal="true"
          aria-label="Career Learning Resources Modal"
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
        >
          <div
            className={`w-full max-w-3xl border p-6 space-y-5 ${
              isDark
                ? 'bg-[#09090B] border-white text-white'
                : 'bg-white border-black text-black'
            }`}
          >
            <div className="flex items-center justify-between border-b pb-3 border-zinc-700">
              <div>
                <div className="text-xs font-mono opacity-70">
                  {activeCareer.code} · FREE PUBLIC LEARNING VAULT
                </div>
                <h2 className="text-lg font-bold">
                  {activeCareer.title[lang]}
                </h2>
              </div>
              <button
                type="button"
                data-testid="close-learning-modal-btn"
                onClick={() => setLearningModalOpen(false)}
                className={`px-3 py-1 text-xs font-mono border cursor-pointer ${
                  isDark
                    ? 'bg-zinc-900 border-zinc-600'
                    : 'bg-zinc-100 border-zinc-400'
                }`}
              >
                {lang === 'en' ? 'CLOSE [ESC]' : 'बंद करें'}
              </button>
            </div>

            {/* 8 Active Tabs + 9th Disabled Tab ("AI Mentor (Locked until ₹10k Funding)") */}
            <div className="flex flex-wrap gap-1.5">
              {LEARNING_TABS.map((tab) => {
                if (tab.locked) {
                  return (
                    <button
                      key={tab.key}
                      type="button"
                      disabled
                      data-testid="learning-tab-ai-mentor-locked"
                      title={tab.label[lang]}
                      className="px-2.5 py-1.5 text-xs font-mono border border-dashed opacity-50 cursor-not-allowed"
                    >
                      🔒 {tab.label[lang]}
                    </button>
                  );
                }
                const isActive = activeLearningTab === tab.key;
                return (
                  <button
                    key={tab.key}
                    type="button"
                    data-testid={`learning-tab-${tab.key}`}
                    onClick={() =>
                      setActiveLearningTab(tab.key as LearningTabKey)
                    }
                    className={`px-2.5 py-1.5 text-xs font-mono border cursor-pointer ${
                      isActive
                        ? isDark
                          ? 'bg-white text-black border-white font-bold'
                          : 'bg-black text-white border-black font-bold'
                        : isDark
                          ? 'bg-zinc-900 text-zinc-300 border-zinc-800'
                          : 'bg-zinc-100 text-zinc-800 border-zinc-300'
                    }`}
                  >
                    {tab.label[lang]}
                  </button>
                );
              })}
            </div>

            {/* Active Tab Resource List */}
            <div className="space-y-3 min-h-[140px]">
              {(activeCareer.resources[activeLearningTab] || []).map(
                (item, idx) => (
                  <div
                    key={idx}
                    className={`p-4 border flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 ${
                      isDark
                        ? 'bg-zinc-950 border-zinc-800'
                        : 'bg-zinc-50 border-zinc-300'
                    }`}
                  >
                    <div className="space-y-1">
                      <div className="text-xs font-mono opacity-70">
                        [{item.typeTag}] · {item.source}
                      </div>
                      <div className="text-sm font-bold">
                        {item.title[lang]}
                      </div>
                    </div>
                    <a
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`px-3 py-1.5 text-xs font-mono font-bold border shrink-0 ${
                        isDark
                          ? 'bg-white text-black border-white'
                          : 'bg-black text-white border-black'
                      }`}
                    >
                      {lang === 'en' ? 'OPEN SOURCE ↗' : 'पोर्टल खोलें ↗'}
                    </a>
                  </div>
                )
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
