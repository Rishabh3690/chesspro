export type Language = 'en' | 'hi';
export type BlueprintTheme = 'dark' | 'light';

export interface BilingualText {
  en: string;
  hi: string;
}

export interface CareerCategory {
  id: string;
  name: BilingualText;
  code: string;
}

export interface ComingSoonTrack {
  id: string;
  title: BilingualText;
  eta: BilingualText;
}

export interface ParentFaqItem {
  q: BilingualText;
  a: BilingualText;
}

export interface ParentSectionData {
  headline: BilingualText;
  subheadline: BilingualText;
  Checklist: BilingualText[];
  faqs: ParentFaqItem[];
}

export interface RoadmapStep {
  stepNumber: string;
  stageTitle: BilingualText;
  duration: BilingualText;
  details: BilingualText;
  keyExamOrMilestone: string;
  planB: {
    triggerCondition: BilingualText;
    targetCareerId: string;
    targetCareerName: BilingualText;
    rationale: BilingualText;
  };
}

export interface CollegeCutoffItem {
  collegeName: string;
  location: string;
  entranceCutoff: BilingualText;
  estimatedTotalFees: string;
  avgPlacement: string;
}

export interface LearningResourceItem {
  title: BilingualText;
  source: string;
  typeTag: string;
  url: string;
}

export type LearningTabKey =
  | 'pyqs'
  | 'govtPortals'
  | 'youtube'
  | 'nptel'
  | 'books'
  | 'scholarships'
  | 'internships'
  | 'mockTests';

export interface CareerChild {
  id: string;
  categoryId: string;
  code: string;
  icon: string;
  title: BilingualText;
  tagline: BilingualText;
  salaryRange: BilingualText;
  firstYearMonthlyInr: number;
  totalCost: BilingualText;
  totalCostLakhs: number;
  difficulty: BilingualText;
  primaryExams: string;
  planBSummary: BilingualText;
  lastVerified: string;
  roadmap: RoadmapStep[];
  thriveIf: BilingualText[];
  reconsiderIf: BilingualText[];
  colleges: CollegeCutoffItem[];
  resources: Record<LearningTabKey, LearningResourceItem[]>;
}

export interface CareerPathOStorageShape {
  categories: CareerCategory[];
  comingSoon: ComingSoonTrack[];
  parents: ParentSectionData;
  children: CareerChild[];
}

export const CAREERPATHO_STORAGE_KEY = 'careerpatho-data';

export const DEFAULT_CAREERPATHO_DATA: CareerPathOStorageShape = {
  categories: [
    {
      id: 'all',
      code: 'ALL-00',
      name: { en: 'All Blueprints', hi: 'सभी ब्लूप्रिंट (All)' },
    },
    {
      id: 'tech',
      code: 'ENG-01',
      name: {
        en: 'Engineering & Computing',
        hi: 'इंजीनियरिंग और कंप्यूटिंग (B.Tech / BCA)',
      },
    },
    {
      id: 'med',
      code: 'MED-02',
      name: {
        en: 'Medical & Healthcare',
        hi: 'मेडिकल और हेल्थकेयर (MBBS / B.Sc)',
      },
    },
    {
      id: 'fin',
      code: 'FIN-03',
      name: {
        en: 'Finance & Commerce',
        hi: 'फाइनेंस और कॉमर्स (CA / CFA)',
      },
    },
    {
      id: 'gov',
      code: 'GOV-04',
      name: {
        en: 'Civil Services & Policy',
        hi: 'सिविल सेवा और नीति (UPSC / SSC)',
      },
    },
    {
      id: 'des',
      code: 'DES-05',
      name: {
        en: 'Product Design & Architecture',
        hi: 'प्रोडक्ट डिज़ाइन (B.Des / UCEED)',
      },
    },
  ],
  comingSoon: [
    {
      id: 'cs-aviation',
      title: {
        en: 'Commercial Pilot (DGCA CPL Pathway)',
        hi: 'कमर्शियल पायलट (DGCA CPL Pathway)',
      },
      eta: { en: 'Q2 Audit Pending', hi: 'Q2 ऑडिट प्रतीक्षित' },
    },
    {
      id: 'cs-law',
      title: {
        en: 'Corporate Law (CLAT -> NLUs Blueprint)',
        hi: 'कॉर्पोरेट लॉ (CLAT -> NLUs Blueprint)',
      },
      eta: { en: 'Q2 Audit Pending', hi: 'Q2 ऑडिट प्रतीक्षित' },
    },
    {
      id: 'cs-defence',
      title: {
        en: 'Armed Forces Officer (NDA / CDS)',
        hi: 'सशस्त्र बल अधिकारी (NDA / CDS)',
      },
      eta: { en: 'Q3 Audit Pending', hi: 'Q3 ऑडिट प्रतीक्षित' },
    },
  ],
  parents: {
    headline: {
      en: 'Parent Financial & Risk Verification Briefing',
      hi: 'अभिभावकों के लिए वित्तीय और Plan B सुरक्षा ब्रीफिंग',
    },
    subheadline: {
      en: 'Every career blueprint includes realistic coaching + tuition outlays, ₹5L education loan EMI math, and zero-shame Plan B pivots.',
      hi: 'हर करियर ब्लूप्रिंट में वास्तविक फीस, ₹5L एजुकेशन लोन EMI गणना और बिना किसी झिझक के Plan B विकल्प शामिल हैं।',
    },
    Checklist: [
      {
        en: 'Never mortgage primary family residence for undergraduate coaching.',
        hi: 'UG कोचिंग (JEE / NEET) के लिए कभी भी परिवार का मुख्य घर गिरवी न रखें।',
      },
      {
        en: 'Lock a deterministic Plan B entrance exam alongside the primary target.',
        hi: 'मुख्य परीक्षा के साथ हमेशा एक मजबूत Plan B प्रवेश परीक्षा का फॉर्म भरें।',
      },
      {
        en: 'Verify AICTE / NMC / UGC statutory approval before paying seat deposits.',
        hi: 'फीस जमा करने से पहले AICTE / NMC / UGC की आधिकारिक मान्यता अवश्य जांचें।',
      },
    ],
    faqs: [
      {
        q: {
          en: 'What if my child misses the JEE or NEET cutoff after 1 drop year?',
          hi: 'यदि 1 ड्रॉप वर्ष के बाद भी JEE या NEET कटऑफ क्लियर न हो तो क्या करें?',
        },
        a: {
          en: 'Activate the linked Plan B card immediately (e.g., BCA + NIMCET or B.Sc Biotech). Avoid multi-year coaching traps.',
          hi: 'तुरंत लिंक्ड Plan B कार्ड (जैसे BCA + NIMCET या B.Sc Biotech) चुनें। कई वर्षों के कोचिंग जाल से बचें।',
        },
      },
      {
        q: {
          en: 'How is the ₹5 Lakh Education Loan EMI calculated?',
          hi: '₹5 लाख एजुकेशन लोन की EMI कैसे गणना की जाती है?',
        },
        a: {
          en: 'Calculated at 9.0% p.a. standard public-sector bank rate over a 60-month (5-year) repayment period post-moratorium: ₹10,379/month.',
          hi: 'सार्वजनिक बैंक की 9.0% वार्षिक ब्याज दर पर 60 महीने (5 वर्ष) की अवधि के लिए: ₹10,379 प्रति माह।',
        },
      },
    ],
  },
  children: [
    {
      id: 'btech-cse',
      categoryId: 'tech',
      code: 'BP-101',
      icon: '⌘',
      title: {
        en: 'Software Systems Engineer (B.Tech CSE)',
        hi: 'सॉफ्टवेयर सिस्टम्स इंजीनियर (B.Tech CSE)',
      },
      tagline: {
        en: 'Four-year engineering degree focused on algorithms, distributed systems, and production software.',
        hi: 'एल्गोरिदम, डिस्ट्रीब्यूटेड सिस्टम्स और सॉफ्टवेयर इंजीनियरिंग पर आधारित 4-वर्षीय B.Tech डिग्री।',
      },
      salaryRange: {
        en: '₹6.5L – ₹24.0L / yr (Entry CTC)',
        hi: '₹6.5L – ₹24.0L / वर्ष (शुरुआती CTC)',
      },
      firstYearMonthlyInr: 68000,
      totalCost: {
        en: '₹4.5L – ₹16.0L (4-Yr Total)',
        hi: '₹4.5L – ₹16.0L (4-वर्ष कुल लागत)',
      },
      totalCostLakhs: 10.0,
      difficulty: {
        en: 'HIGH (JEE Main / Advanced)',
        hi: 'उच्च / HIGH (JEE Main / Advanced)',
      },
      primaryExams: 'JEE Main, JEE Advanced, BITSAT, MHT-CET, KCET',
      planBSummary: {
        en: 'If JEE fails -> BCA + MCA (NIMCET) or B.Sc Computer Science',
        hi: 'यदि JEE सफल न हो -> BCA + MCA (NIMCET) या B.Sc Computer Science',
      },
      lastVerified: '2026-10-15',
      roadmap: [
        {
          stepNumber: '01',
          stageTitle: {
            en: 'Class 11–12 PCM + Competitive Core',
            hi: 'कक्षा 11–12 PCM + JEE फाउंडेशन',
          },
          duration: { en: '24 Months', hi: '24 महीने' },
          details: {
            en: 'Master Calculus, Mechanics, Electrochemistry, and NCERT fundamentals alongside mock tests.',
            hi: 'NCERT बुनियादी सिद्धांतों के साथ कैलकुलस, मैकेनिक्स और JEE Main मॉक टेस्ट का अभ्यास करें।',
          },
          keyExamOrMilestone: 'JEE Main / State CET',
          planB: {
            triggerCondition: {
              en: 'If JEE Main percentile < 85%',
              hi: 'यदि JEE Main परसेंटाइल 85% से कम रहे',
            },
            targetCareerId: 'bca-mca',
            targetCareerName: {
              en: 'BCA + MCA Full-Stack Track',
              hi: 'BCA + MCA फुल-स्टैक ट्रैक',
            },
            rationale: {
              en: 'Zero coaching debt; enter software roles via CUET BCA and NIT MCA (NIMCET).',
              hi: 'बिना महंगे कोचिंग कर्ज के CUET BCA और NIT MCA (NIMCET) के माध्यम से सॉफ्टवेयर सेक्टर में प्रवेश।',
            },
          },
        },
        {
          stepNumber: '02',
          stageTitle: {
            en: 'Years 1–2: Data Structures, OS & Open Source',
            hi: 'वर्ष 1–2: DSA, Operating Systems और GitHub प्रोजेक्ट्स',
          },
          duration: { en: '24 Months', hi: '24 महीने' },
          details: {
            en: 'Build real full-stack systems, contribute to open source (GSoC), and solve 300+ algorithmic problems.',
            hi: 'रियल फुल-स्टैक प्रोजेक्ट्स बनाएं, GSoC में योगदान दें और 300+ DSA प्रश्न हल करें।',
          },
          keyExamOrMilestone: 'GSoC / SIH / Sem Exams',
          planB: {
            triggerCondition: {
              en: 'If core coding feels overwhelming',
              hi: 'यदि कोर कोडिंग कठिन लगे',
            },
            targetCareerId: 'uiux-des',
            targetCareerName: {
              en: 'Product Design & UX Architecture (B.Des / UI-UX)',
              hi: 'प्रोडक्ट डिज़ाइन और UI/UX आर्किटेक्चर',
            },
            rationale: {
              en: 'Pivot to product management or UI/UX engineering inside tech firms.',
              hi: 'टेक कंपनियों के भीतर Product Management या UI/UX डिज़ाइन में करियर बनाएं।',
            },
          },
        },
        {
          stepNumber: '03',
          stageTitle: {
            en: 'Years 3–4: Summer Internships & Campus/Off-Campus SDE',
            hi: 'वर्ष 3–4: समर इंटर्नशिप और कैंपस/ऑफ-कैंपस SDE प्लेसमेंट',
          },
          duration: { en: '24 Months', hi: '24 महीने' },
          details: {
            en: 'Convert 6-month industrial internship into a Pre-Placement Offer (PPO) or appear for GATE CS.',
            hi: '6 महीने की इंटर्नशिप को PPO में बदलें या उच्च अध्ययन के लिए GATE CS दें।',
          },
          keyExamOrMilestone: 'PPO / GATE CS / Off-Campus',
          planB: {
            triggerCondition: {
              en: 'If Tier-3 campus placements stall',
              hi: 'यदि कॉलेज कैंपस प्लेसमेंट कम हो',
            },
            targetCareerId: 'bca-mca',
            targetCareerName: {
              en: 'Off-Campus Portfolio & GATE PSU Track',
              hi: 'ऑफ-कैंपस पोर्टफोलियो और GATE PSU ट्रैक',
            },
            rationale: {
              en: 'Target direct GitHub proof-of-work startups or PSU scientific officer exams.',
              hi: 'स्टार्टअप्स में सीधे प्रोजेक्ट पोर्टफोलियो या GATE PSU परीक्षा के जरिए नौकरी पाएं।',
            },
          },
        },
      ],
      thriveIf: [
        {
          en: 'You enjoy debugging complex logic for hours without losing patience.',
          hi: 'आप बिना धैर्य खोए घंटों तक जटिल कोड और लॉजिक को डीबग करना पसंद करते हैं।',
        },
        {
          en: 'You prefer building tangible digital tools over rote memorization.',
          hi: 'आप रटने के बजाय वास्तविक डिजिटल टूल्स और ऐप्स बनाना पसंद करते हैं।',
        },
        {
          en: 'You are comfortable learning new frameworks every 18–24 months.',
          hi: 'आप हर 18–24 महीने में नई टेक्नोलॉजी सीखने के लिए तैयार रहते हैं।',
        },
      ],
      reconsiderIf: [
        {
          en: 'You dislike sitting at a terminal screen for 6+ hours daily.',
          hi: 'यदि आपको रोज़ाना 6+ घंटे कंप्यूटर स्क्रीन के सामने बैठना पसंद नहीं है।',
        },
        {
          en: 'You are only choosing B.Tech because of peer or neighbourhood pressure.',
          hi: 'यदि आप केवल पड़ोसियों या रिश्तेदारों के दबाव में B.Tech चुन रहे हैं।',
        },
      ],
      colleges: [
        {
          collegeName: 'IIT Bombay / IIT Delhi / IIT Madras',
          location: 'Mumbai / New Delhi / Chennai',
          entranceCutoff: {
            en: 'JEE Advanced Top 500 AIR',
            hi: 'JEE Advanced टॉप 500 AIR',
          },
          estimatedTotalFees: '₹8.5L – ₹10.0L',
          avgPlacement: '₹22.0L – ₹28.0L',
        },
        {
          collegeName: 'NIT Trichy / NIT Surathkal / NIT Warangal',
          location: 'Tamil Nadu / Karnataka / Telangana',
          entranceCutoff: {
            en: 'JEE Main 99.4+ Percentile',
            hi: 'JEE Main 99.4+ परसेंटाइल',
          },
          estimatedTotalFees: '₹5.5L – ₹6.8L',
          avgPlacement: '₹15.5L – ₹19.0L',
        },
        {
          collegeName: 'COEP Pune / VJTI Mumbai / DTU Delhi',
          location: 'Pune / Mumbai / Delhi',
          entranceCutoff: {
            en: 'MHT-CET 99.5% / JEE Main 98.8%',
            hi: 'MHT-CET 99.5% / JEE Main 98.8%',
          },
          estimatedTotalFees: '₹3.8L – ₹6.5L',
          avgPlacement: '₹12.0L – ₹16.0L',
        },
      ],
      resources: {
        pyqs: [
          {
            title: {
              en: 'NTA JEE Main Official Shift-Wise Archives (2019–2026)',
              hi: 'NTA JEE Main आधिकारिक पुराने प्रश्नपत्र (PYQs 2019–2026)',
            },
            source: 'nta.ac.in',
            typeTag: 'PDF Archive',
            url: 'https://jeemain.nta.ac.in',
          },
        ],
        govtPortals: [
          {
            title: {
              en: 'JoSAA Official Seat Allocation & Opening/Closing Ranks',
              hi: 'JoSAA आधिकारिक सीट आवंटन और कटऑफ पोर्टल',
            },
            source: 'josaa.nic.in',
            typeTag: 'Govt Portal',
            url: 'https://josaa.nic.in',
          },
        ],
        youtube: [
          {
            title: {
              en: 'MIT OpenCourseWare 6.006 Introduction to Algorithms',
              hi: 'MIT OpenCourseWare 6.006 एल्गोरिदम लेक्चर सीरीज़',
            },
            source: 'YouTube Educational',
            typeTag: 'Free Video',
            url: 'https://www.youtube.com',
          },
        ],
        nptel: [
          {
            title: {
              en: 'NPTEL IIT Madras — Programming, Data Structures & Algorithms',
              hi: 'NPTEL IIT Madras — प्रोग्रामिंग और डेटा स्ट्रक्चर्स (DSA)',
            },
            source: 'swayam.gov.in',
            typeTag: 'Swayam Course',
            url: 'https://swayam.gov.in',
          },
        ],
        books: [
          {
            title: {
              en: 'NCERT Class 11 & 12 Mathematics + Concepts of Physics (H.C. Verma)',
              hi: 'NCERT कक्षा 11 और 12 गणित + H.C. Verma फिजिक्स',
            },
            source: 'NCERT / Open Library',
            typeTag: 'Core Text',
            url: 'https://ncert.nic.in',
          },
        ],
        scholarships: [
          {
            title: {
              en: 'AICTE Pragati & Saksham Scholarship + National Scholarship Portal',
              hi: 'AICTE प्रगति और सक्षम छात्रवृत्ति (NSP पोर्टल)',
            },
            source: 'scholarships.gov.in',
            typeTag: '₹50,000 / yr',
            url: 'https://scholarships.gov.in',
          },
        ],
        internships: [
          {
            title: {
              en: 'Google Summer of Code (GSoC) & AICTE Internship Enterprise Portal',
              hi: 'Google Summer of Code (GSoC) और AICTE इंटर्नशिप पोर्टल',
            },
            source: 'internship.aicte-india.org',
            typeTag: 'Stipend Track',
            url: 'https://internship.aicte-india.org',
          },
        ],
        mockTests: [
          {
            title: {
              en: 'National Test Abhyas Official CBT Mock Simulator',
              hi: 'नेशनल टेस्ट अभ्यास आधिकारिक CBT मॉक टेस्ट',
            },
            source: 'nta.ac.in/abhyas',
            typeTag: 'Free CBT',
            url: 'https://www.nta.ac.in',
          },
        ],
      },
    },
    {
      id: 'bca-mca',
      categoryId: 'tech',
      code: 'BP-102',
      icon: '⌗',
      title: {
        en: 'Applied Software Developer (BCA + MCA Track)',
        hi: 'एप्लाइड सॉफ्टवेयर डेवलपर (BCA + MCA ट्रैक)',
      },
      tagline: {
        en: 'High-ROI, low-tuition computer applications route into software engineering and NIT MCA.',
        hi: 'कम फीस और उच्च ROI के साथ सॉफ्टवेयर इंजीनियरिंग और NIT MCA में प्रवेश का स्मार्ट रास्ता।',
      },
      salaryRange: {
        en: '₹4.5L – ₹14.5L / yr (Post-MCA / Full-Stack)',
        hi: '₹4.5L – ₹14.5L / वर्ष (MCA / फुल-स्टैक के बाद)',
      },
      firstYearMonthlyInr: 48000,
      totalCost: {
        en: '₹1.8L – ₹5.2L (Complete Track)',
        hi: '₹1.8L – ₹5.2L (कुल डिग्री लागत)',
      },
      totalCostLakhs: 3.2,
      difficulty: {
        en: 'MODERATE (CUET UG + NIMCET)',
        hi: 'मध्यम / MODERATE (CUET UG + NIMCET)',
      },
      primaryExams: 'CUET UG, NIMCET (for NIT MCA), MAH-MCA-CET',
      planBSummary: {
        en: 'Direct Full-Stack Web/App Developer after BCA + GitHub Portfolio',
        hi: 'BCA + GitHub पोर्टफोलियो के तुरंत बाद डायरेक्ट फुल-स्टैक डेवलपर जॉब',
      },
      lastVerified: '2026-10-15',
      roadmap: [
        {
          stepNumber: '01',
          stageTitle: {
            en: 'BCA Admission via CUET / State University',
            hi: 'CUET या राज्य विश्वविद्यालय से BCA में प्रवेश',
          },
          duration: { en: '36 Months', hi: '36 महीने' },
          details: {
            en: 'Focus on C++, Java, Web Development, SQL databases, and discrete mathematics.',
            hi: 'C++, Java, Web Development, SQL डेटाबेस और गणित पर मजबूत पकड़ बनाएं।',
          },
          keyExamOrMilestone: 'CUET UG / University Entrance',
          planB: {
            triggerCondition: {
              en: 'If you want immediate income after 3 years',
              hi: 'यदि 3 साल बाद तुरंत नौकरी शुरू करनी हो',
            },
            targetCareerId: 'uiux-des',
            targetCareerName: {
              en: 'Frontend & Product UI Engineer',
              hi: 'फ्रंटएंड और प्रोडक्ट UI इंजीनियर',
            },
            rationale: {
              en: 'Join product startups right after BCA while preparing for remote roles.',
              hi: 'BCA के तुरंत बाद स्टार्टअप्स में फ्रंटएंड इंजीनियर के रूप में काम शुरू करें।',
            },
          },
        },
        {
          stepNumber: '02',
          stageTitle: {
            en: 'NIMCET Preparation for NIT MCA',
            hi: 'NIT से MCA के लिए NIMCET की तैयारी',
          },
          duration: { en: '24 Months', hi: '24 महीने' },
          details: {
            en: 'Crack NIMCET to enter NIT Trichy, Surathkal, or Warangal with B.Tech-equivalent placements.',
            hi: 'NIMCET पास करके NIT Trichy या Surathkal में प्रवेश लें जहाँ B.Tech के बराबर प्लेसमेंट मिलता है।',
          },
          keyExamOrMilestone: 'NIMCET / CUET PG',
          planB: {
            triggerCondition: {
              en: 'If NIMCET rank misses NIT cutoff',
              hi: 'यदि NIMCET में NIT कटऑफ न मिले',
            },
            targetCareerId: 'btech-cse',
            targetCareerName: {
              en: 'Direct Off-Campus SDE via Open Source',
              hi: 'ओपन-सोर्स पोर्टफोलियो से डायरेक्ट SDE जॉब',
            },
            rationale: {
              en: 'Use 2 years of startup work experience which outweighs an MCA degree.',
              hi: 'स्टार्टअप में 2 साल का वास्तविक कोडिंग अनुभव किसी भी डिग्री से अधिक मूल्यवान होता है।',
            },
          },
        },
      ],
      thriveIf: [
        {
          en: 'You missed JEE cutoffs but love coding and building web/mobile apps.',
          hi: 'आपका JEE क्लियर नहीं हुआ लेकिन आपको कोडिंग और ऐप्स बनाना बहुत पसंद है।',
        },
        {
          en: 'You want to keep undergraduate tuition under ₹3 Lakhs.',
          hi: 'आप अपनी स्नातक की पढ़ाई ₹3 लाख से कम बजट में पूरी करना चाहते हैं।',
        },
      ],
      reconsiderIf: [
        {
          en: 'You expect campus placements without building self-driven projects.',
          hi: 'यदि आप स्वयं प्रोजेक्ट्स बनाए बिना केवल कॉलेज प्लेसमेंट के भरोसे रहना चाहते हैं।',
        },
      ],
      colleges: [
        {
          collegeName: 'NIT Trichy / NIT Surathkal (MCA via NIMCET)',
          location: 'Tiruchirappalli / Mangalore',
          entranceCutoff: {
            en: 'NIMCET Top 250 AIR',
            hi: 'NIMCET टॉप 250 AIR',
          },
          estimatedTotalFees: '₹2.4L – ₹3.2L',
          avgPlacement: '₹12.0L – ₹16.5L',
        },
        {
          collegeName: 'Delhi University / BHU / JNU (MCA via CUET PG)',
          location: 'New Delhi / Varanasi',
          entranceCutoff: {
            en: 'CUET PG 98+ Percentile',
            hi: 'CUET PG 98+ परसेंटाइल',
          },
          estimatedTotalFees: '₹0.6L – ₹1.5L',
          avgPlacement: '₹8.5L – ₹13.0L',
        },
      ],
      resources: {
        pyqs: [
          {
            title: {
              en: 'NIMCET 10-Year Solved Mathematics & Reasoning Papers',
              hi: 'NIMCET पिछले 10 वर्षों के हल किए गए प्रश्नपत्र (PYQs)',
            },
            source: 'nimcet.in',
            typeTag: 'PYQ PDF',
            url: 'https://www.nimcet.in',
          },
        ],
        govtPortals: [
          {
            title: {
              en: 'CUET UG & PG Official Samarth Portal',
              hi: 'CUET UG और PG आधिकारिक समर्थ पोर्टल',
            },
            source: 'cuet.samarth.ac.in',
            typeTag: 'Official',
            url: 'https://cuet.samarth.ac.in',
          },
        ],
        youtube: [
          {
            title: {
              en: 'CS50x Harvard & Full-Stack Open Architecture Series',
              hi: 'CS50x हार्वर्ड और फुल-स्टैक ओपन लेक्चर सीरीज़',
            },
            source: 'YouTube',
            typeTag: 'Video Course',
            url: 'https://www.youtube.com',
          },
        ],
        nptel: [
          {
            title: {
              en: 'NPTEL Database Management System (IIT Kharagpur)',
              hi: 'NPTEL डेटाबेस मैनेजमेंट सिस्टम (IIT Kharagpur)',
            },
            source: 'swayam.gov.in',
            typeTag: 'Certification',
            url: 'https://swayam.gov.in',
          },
        ],
        books: [
          {
            title: {
              en: 'Eloquent JavaScript & Operating System Concepts (Galvin)',
              hi: 'Eloquent JavaScript और ऑपरेटिंग सिस्टम कॉन्सेप्ट्स',
            },
            source: 'Open Textbook',
            typeTag: 'Free Book',
            url: 'https://eloquentjavascript.net',
          },
        ],
        scholarships: [
          {
            title: {
              en: 'Central Sector Scheme of Scholarships for College Students',
              hi: 'कॉलेज छात्रों के लिए केंद्रीय क्षेत्र छात्रवृत्ति योजना',
            },
            source: 'scholarships.gov.in',
            typeTag: 'Govt Grant',
            url: 'https://scholarships.gov.in',
          },
        ],
        internships: [
          {
            title: {
              en: 'Digital India Internship Scheme (NIC / MeitY)',
              hi: 'डिजिटल इंडिया इंटर्नशिप योजना (NIC / MeitY)',
            },
            source: 'meity.gov.in',
            typeTag: '₹10k/mo Stipend',
            url: 'https://www.meity.gov.in',
          },
        ],
        mockTests: [
          {
            title: {
              en: 'NIMCET Full-Length Timed Mock Test Matrix',
              hi: 'NIMCET फुल-लेंथ मॉक टेस्ट सीरीज़',
            },
            source: 'NTA Abhyas',
            typeTag: 'Mock CBT',
            url: 'https://www.nta.ac.in',
          },
        ],
      },
    },
    {
      id: 'mbbs-clinician',
      categoryId: 'med',
      code: 'BP-201',
      icon: '✚',
      title: {
        en: 'Clinical Physician & Surgeon (MBBS -> MD/MS)',
        hi: 'क्लिनिकल चिकित्सक और सर्जन (MBBS -> MD/MS)',
      },
      tagline: {
        en: '5.5-year rigorous medical degree + compulsory rotating internship under NMC norms.',
        hi: 'NMC मानकों के तहत 5.5-वर्षीय मेडिकल डिग्री (MBBS) और अनिवार्य रोटेटिंग इंटर्नशिप।',
      },
      salaryRange: {
        en: '₹7.2L – ₹18.0L / yr (Junior Resident / MO)',
        hi: '₹7.2L – ₹18.0L / वर्ष (जूनियर रेजिडेंट / मेडिकल ऑफिसर)',
      },
      firstYearMonthlyInr: 72000,
      totalCost: {
        en: '₹0.8L (Govt) – ₹65.0L (Private)',
        hi: '₹0.8L (सरकारी) – ₹65.0L (प्राइवेट कॉलेज)',
      },
      totalCostLakhs: 6.5,
      difficulty: {
        en: 'EXTREME (NEET UG + NExT / NEET PG)',
        hi: 'अत्यंत कठिन / EXTREME (NEET UG + NEET PG)',
      },
      primaryExams: 'NEET UG, NExT / NEET PG, INI-CET',
      planBSummary: {
        en: 'If NEET Govt Cutoff misses -> B.Sc Biotechnology / IISER BS-MS / Pharm.D',
        hi: 'यदि सरकारी NEET सीट न मिले -> B.Sc बायोटेक्नोलॉजी / IISER BS-MS / B.Pharm',
      },
      lastVerified: '2026-10-15',
      roadmap: [
        {
          stepNumber: '01',
          stageTitle: {
            en: 'Class 11–12 PCB + Strict NCERT Line-by-Line Mastery',
            hi: 'कक्षा 11–12 PCB + NCERT बायोलॉजी और केमिस्ट्री पर पूर्ण कमांड',
          },
          duration: { en: '24 Months', hi: '24 महीने' },
          details: {
            en: 'Target 640+ / 720 in NEET UG to secure a Government Medical College seat.',
            hi: 'सरकारी मेडिकल कॉलेज (GMC) की सीट सुनिश्चित करने के लिए NEET UG में 640+ अंक का लक्ष्य रखें।',
          },
          keyExamOrMilestone: 'NEET UG',
          planB: {
            triggerCondition: {
              en: 'If NEET score misses Govt seat (<610) & Private fees exceed budget',
              hi: 'यदि सरकारी सीट न मिले और ₹60L प्राइवेट फीस बजट से बाहर हो',
            },
            targetCareerId: 'ca-chartered',
            targetCareerName: {
              en: 'B.Pharm / Clinical Research / Healthcare Analytics',
              hi: 'B.Pharm / क्लिनिकल रिसर्च और हेल्थकेयर मैनेजमेंट',
            },
            rationale: {
              en: 'Never take a ₹50L+ loan for Private MBBS; pivot to NIPER Pharma or IISER Research.',
              hi: 'प्राइवेट MBBS के लिए ₹50 लाख का कर्ज न लें; NIPER फार्मा या क्लिनिकल रिसर्च चुनें।',
            },
          },
        },
        {
          stepNumber: '02',
          stageTitle: {
            en: '4.5 Years MBBS + 1 Year Compulsory Rotating Internship',
            hi: '4.5 वर्ष MBBS + 1 वर्ष अनिवार्य हॉस्पिटल इंटर्नशिप',
          },
          duration: { en: '66 Months', hi: '66 महीने' },
          details: {
            en: 'Pre-clinical, Para-clinical, and Clinical postings across Medicine, Surgery, OBG, and Pediatrics.',
            hi: 'एनाटॉमी, फिजियोलॉजी से लेकर मेडिसिन, सर्जरी और पीडियाट्रिक्स में गहन क्लिनिकल ट्रेनिंग।',
          },
          keyExamOrMilestone: 'NExT / Final MBBS Univ Exams',
          planB: {
            triggerCondition: {
              en: 'If you prefer non-surgical public administration after MBBS',
              hi: 'यदि MBBS के बाद प्रशासनिक सेवा में जाना चाहें',
            },
            targetCareerId: 'upsc-civil',
            targetCareerName: {
              en: 'UPSC CMS / IAS Health Administration',
              hi: 'UPSC CMS / सिविल सेवा (IAS) स्वास्थ्य प्रशासन',
            },
            rationale: {
              en: 'Medical graduates have high success rates in UPSC Combined Medical Services & IAS.',
              hi: 'MBBS स्नातकों के लिए UPSC CMS और IAS एक प्रतिष्ठित और स्थिर विकल्प है।',
            },
          },
        },
      ],
      thriveIf: [
        {
          en: 'You have high emotional resilience for emergency hospital shifts.',
          hi: 'आपमें अस्पताल की इमरजेंसी ड्यूटी और लंबी शिफ्ट के लिए मानसिक धैर्य है।',
        },
        {
          en: 'You are committed to a 8–10 year learning curve (MBBS + MD/MS).',
          hi: 'आप 8–10 साल की लंबी पढ़ाई (MBBS + MD/MS) के लिए पूरी तरह समर्पित हैं।',
        },
      ],
      reconsiderIf: [
        {
          en: 'You want high corporate pay by age 22 with 5-day workweeks.',
          hi: 'यदि आप 22 साल की उम्र में कॉर्पोरेट पैकेज और वीकेंड छुट्टी चाहते हैं।',
        },
      ],
      colleges: [
        {
          collegeName: 'AIIMS New Delhi / JIPMER Puducherry',
          location: 'New Delhi / Puducherry',
          entranceCutoff: {
            en: 'NEET UG Top 60 – 300 AIR',
            hi: 'NEET UG टॉप 60 – 300 AIR',
          },
          estimatedTotalFees: '₹0.15L – ₹0.45L',
          avgPlacement: '₹12.0L – ₹16.0L (JR Stipend)',
        },
        {
          collegeName: 'KEM Mumbai / MAMC Delhi / KGMU Lucknow',
          location: 'Mumbai / Delhi / Lucknow',
          entranceCutoff: {
            en: 'NEET UG 665+ Marks',
            hi: 'NEET UG 665+ अंक',
          },
          estimatedTotalFees: '₹0.80L – ₹4.50L',
          avgPlacement: '₹9.6L – ₹14.0L',
        },
      ],
      resources: {
        pyqs: [
          {
            title: {
              en: 'NEET UG 15-Year Official Question Papers (Biology, Physics, Chem)',
              hi: 'NEET UG पिछले 15 वर्षों के आधिकारिक प्रश्नपत्र (PYQs)',
            },
            source: 'neet.nta.nic.in',
            typeTag: 'Official PYQ',
            url: 'https://neet.nta.nic.in',
          },
        ],
        govtPortals: [
          {
            title: {
              en: 'Medical Counselling Committee (MCC) & NMC College Directory',
              hi: 'मेडिकल काउंसलिंग कमेटी (MCC) और NMC आधिकारिक पोर्टल',
            },
            source: 'mcc.nic.in',
            typeTag: 'Counselling',
            url: 'https://mcc.nic.in',
          },
        ],
        youtube: [
          {
            title: {
              en: 'NCERT Official Audio-Visual Biology Line-by-Line Dissection',
              hi: 'NCERT आधिकारिक बायोलॉजी लाइन-बाय-लाइन वीडियो लेक्चर',
            },
            source: 'CEC / SwayamPrabha',
            typeTag: 'Video Lecture',
            url: 'https://www.youtube.com',
          },
        ],
        nptel: [
          {
            title: {
              en: 'NPTEL Human Physiology & Biochemistry Foundation',
              hi: 'NPTEL ह्यूमन फिजियोलॉजी और बायोकेमिस्ट्री कोर्स',
            },
            source: 'swayam.gov.in',
            typeTag: 'Course',
            url: 'https://swayam.gov.in',
          },
        ],
        books: [
          {
            title: {
              en: 'NCERT Biology Class 11 & 12 (Mandatory 95% Weightage)',
              hi: 'NCERT बायोलॉजी कक्षा 11 और 12 (95% प्रश्न यहीं से)',
            },
            source: 'ncert.nic.in',
            typeTag: 'Free PDF',
            url: 'https://ncert.nic.in',
          },
        ],
        scholarships: [
          {
            title: {
              en: 'ONGC & State Directorate Medical Merit Scholarship',
              hi: 'ONGC और राज्य मेडिकल मेरिट छात्रवृत्ति योजना',
            },
            source: 'scholarships.gov.in',
            typeTag: '₹48,000 / yr',
            url: 'https://scholarships.gov.in',
          },
        ],
        internships: [
          {
            title: {
              en: 'ICMR Short Term Studentship (STS) Research Program',
              hi: 'ICMR शॉर्ट टर्म स्टूडेंटशिप (STS) मेडिकल रिसर्च प्रोग्राम',
            },
            source: 'icmr.nic.in',
            typeTag: 'ICMR Grant',
            url: 'https://www.icmr.gov.in',
          },
        ],
        mockTests: [
          {
            title: {
              en: 'NTA Abhyas Full-Syllabus 200-Minute OMR Practice Set',
              hi: 'NTA अभ्यास 200-मिनट OMR प्रैक्टिस मॉक सेट',
            },
            source: 'nta.ac.in',
            typeTag: 'OMR / CBT',
            url: 'https://www.nta.ac.in',
          },
        ],
      },
    },
    {
      id: 'ca-chartered',
      categoryId: 'fin',
      code: 'BP-301',
      icon: '∑',
      title: {
        en: 'Chartered Accountant & Corporate Finance (ICAI CA)',
        hi: 'चार्टर्ड अकाउंटेंट और कॉर्पोरेट फाइनेंस (ICAI CA)',
      },
      tagline: {
        en: 'Statutory financial audit, taxation, and corporate strategy credential governed by ICAI.',
        hi: 'ICAI द्वारा संचालित वैधानिक ऑडिट, टैक्सेशन और कॉर्पोरेट फाइनेंस का सर्वोच्च प्रोफेशनल कोर्स।',
      },
      salaryRange: {
        en: '₹9.0L – ₹22.0L / yr (Newly Qualified CA)',
        hi: '₹9.0L – ₹22.0L / वर्ष (नव-चयनित CA पैकेज)',
      },
      firstYearMonthlyInr: 82000,
      totalCost: {
        en: '₹0.85L – ₹2.2L (ICAI Registration + Articleship)',
        hi: '₹0.85L – ₹2.2L (ICAI पंजीकरण कुल लागत)',
      },
      totalCostLakhs: 1.5,
      difficulty: {
        en: 'HIGH (CA Foundation -> Inter -> Final)',
        hi: 'उच्च / HIGH (CA Foundation -> Inter -> Final)',
      },
      primaryExams: 'ICAI CA Foundation, CA Intermediate, CA Final',
      planBSummary: {
        en: 'If CA Final stalls -> B.Com (Hons) + MBA Finance (CAT) / ACCA / CFA',
        hi: 'यदि CA Final में देरी हो -> B.Com (Hons) + MBA Finance (CAT) या CFA',
      },
      lastVerified: '2026-10-15',
      roadmap: [
        {
          stepNumber: '01',
          stageTitle: {
            en: 'CA Foundation + Parallel B.Com (IGNOU / DU)',
            hi: 'CA Foundation + समानांतर B.Com डिग्री',
          },
          duration: { en: '8–12 Months', hi: '8–12 महीने' },
          details: {
            en: 'Clear 4 papers in Accounting, Mercantile Law, Quantitative Aptitude, and Economics.',
            hi: 'अकाउंटिंग, लॉ, क्वांटिटेटिव एप्टीट्यूड और इकोनॉमिक्स के 4 पेपर पास करें।',
          },
          keyExamOrMilestone: 'ICAI CA Foundation',
          planB: {
            triggerCondition: {
              en: 'If CA Intermediate takes > 3 attempts',
              hi: 'यदि CA Intermediate में 3 से अधिक प्रयास लगें',
            },
            targetCareerId: 'upsc-civil',
            targetCareerName: {
              en: 'MBA Finance (CAT) / RBI Grade B / SSC CGL Auditor',
              hi: 'MBA Finance (CAT) / RBI Grade B अधिकारी',
            },
            rationale: {
              en: 'Leverage your B.Com degree and accounting base to crack CAT or RBI Grade B.',
              hi: 'अपनी B.Com डिग्री और अकाउंटिंग ज्ञान का उपयोग करके CAT या RBI Grade B पास करें।',
            },
          },
        },
        {
          stepNumber: '02',
          stageTitle: {
            en: 'CA Intermediate + 2-Year Practical Articleship',
            hi: 'CA Intermediate + 2-वर्षीय प्रैक्टिकल आर्टिकलशिप',
          },
          duration: { en: '30 Months', hi: '30 महीने' },
          details: {
            en: 'Earn stipend while auditing real companies under a practicing Chartered Accountant.',
            hi: 'प्रैक्टिसिंग CA के अधीन वास्तविक कंपनियों का ऑडिट करते हुए स्टाइपेंड प्राप्त करें।',
          },
          keyExamOrMilestone: 'CA Inter Group I & II + Articleship',
          planB: {
            triggerCondition: {
              en: 'If CA Final Group 2 is pending',
              hi: 'यदि CA Final में समय लग रहा हो',
            },
            targetCareerId: 'bca-mca',
            targetCareerName: {
              en: 'FinTech Product Analyst & ERP Consultant',
              hi: 'FinTech एनालिस्ट और SAP/ERP कंसल्टेंट',
            },
            rationale: {
              en: 'CA Inter + Articleship experience commands ₹7L+ in Big-4 Global Delivery rooms.',
              hi: 'CA Inter और आर्टिकलशिप अनुभव से Big-4 कंपनियों में ₹7L+ की जॉब तुरंत मिलती है।',
            },
          },
        },
      ],
      thriveIf: [
        {
          en: 'You love balance sheets, tax statutes, and corporate valuation.',
          hi: 'आपको बैलेंस शीट, टैक्स कानून और कॉर्पोरेट वैल्यूएशन का विश्लेषण पसंद है।',
        },
        {
          en: 'You want elite financial credentials without spending ₹15 Lakhs on college fees.',
          hi: 'आप ₹15 लाख कॉलेज फीस खर्च किए बिना शीर्ष वित्तीय करियर चाहते हैं।',
        },
      ],
      reconsiderIf: [
        {
          en: 'You dislike self-study discipline and statutory compliance reading.',
          hi: 'यदि आपको सेल्फ-स्टडी और कानूनी/टैक्स प्रावधान पढ़ना उबाऊ लगता है।',
        },
      ],
      colleges: [
        {
          collegeName: 'ICAI Statutory Board (All-India Distance + Chapters)',
          location: 'Pan-India',
          entranceCutoff: {
            en: '50% Aggregate in Foundation & Inter',
            hi: 'CA Foundation और Inter में न्यूनतम 50% अंक',
          },
          estimatedTotalFees: '₹0.85L (Official ICAI Fees)',
          avgPlacement: '₹11.5L (ICAI Campus Placement)',
        },
        {
          collegeName: 'SRCC / St. Xavier’s / Narsee Monjee (Parallel B.Com)',
          location: 'Delhi / Kolkata / Mumbai',
          entranceCutoff: {
            en: 'CUET UG 99.2+ Percentile',
            hi: 'CUET UG 99.2+ परसेंटाइल',
          },
          estimatedTotalFees: '₹0.90L – ₹2.40L',
          avgPlacement: '₹10.5L – ₹16.0L',
        },
      ],
      resources: {
        pyqs: [
          {
            title: {
              en: 'ICAI BoS Knowledge Portal — RTPs, MTPs & Past Papers',
              hi: 'ICAI BoS पोर्टल — आधिकारिक RTP, MTP और पिछले पेपर',
            },
            source: 'icai.org',
            typeTag: 'Official ICAI',
            url: 'https://www.icai.org',
          },
        ],
        govtPortals: [
          {
            title: {
              en: 'Ministry of Corporate Affairs (MCA) & Income Tax India Portal',
              hi: 'कॉर्पोरेट कार्य मंत्रालय (MCA) और इनकम टैक्स पोर्टल',
            },
            source: 'mca.gov.in',
            typeTag: 'Statutory',
            url: 'https://www.mca.gov.in',
          },
        ],
        youtube: [
          {
            title: {
              en: 'ICAI CA Tube Official Live Revision Lectures',
              hi: 'ICAI CA Tube आधिकारिक लाइव रिवीजन लेक्चर',
            },
            source: 'ICAI Official YouTube',
            typeTag: 'Free Video',
            url: 'https://www.youtube.com',
          },
        ],
        nptel: [
          {
            title: {
              en: 'NPTEL Financial Accounting & Corporate Finance (IIT Roorkee)',
              hi: 'NPTEL फाइनेंशियल अकाउंटिंग और कॉर्पोरेट फाइनेंस',
            },
            source: 'swayam.gov.in',
            typeTag: 'Swayam',
            url: 'https://swayam.gov.in',
          },
        ],
        books: [
          {
            title: {
              en: 'ICAI BoS Study Material Modules (Included in Registration)',
              hi: 'ICAI BoS अध्ययन सामग्री मॉड्यूल (पंजीकरण में निःशुल्क)',
            },
            source: 'boslive.icai.org',
            typeTag: 'Free Modules',
            url: 'https://www.icai.org',
          },
        ],
        scholarships: [
          {
            title: {
              en: 'ICAI Merit & Need-Based Student Scholarship Scheme',
              hi: 'ICAI मेरिट और आवश्यकता-आधारित छात्रवृत्ति योजना',
            },
            source: 'icai.org',
            typeTag: '₹2,500 / mo',
            url: 'https://www.icai.org',
          },
        ],
        internships: [
          {
            title: {
              en: 'ICAI Industrial Training (Months 13–24 in RBI / SEBI / FMCG)',
              hi: 'ICAI इंडस्ट्रियल ट्रेनिंग (RBI / SEBI / कॉर्पोरेट बैंकों में)',
            },
            source: 'ICAI Portal',
            typeTag: '₹25k–₹50k/mo',
            url: 'https://www.icai.org',
          },
        ],
        mockTests: [
          {
            title: {
              en: 'ICAI Mock Test Series I & II (Regional Chapter & Virtual)',
              hi: 'ICAI आधिकारिक मॉक टेस्ट सीरीज़ I और II',
            },
            source: 'boslive.icai.org',
            typeTag: 'Official Mock',
            url: 'https://www.icai.org',
          },
        ],
      },
    },
    {
      id: 'upsc-civil',
      categoryId: 'gov',
      code: 'BP-401',
      icon: '⚖',
      title: {
        en: 'Civil Services & Public Policy (UPSC CSE / State PCS)',
        hi: 'सिविल सेवा और लोक नीति (UPSC CSE / State PCS)',
      },
      tagline: {
        en: 'Constitutional governance, district administration, and policy architecture via UPSC.',
        hi: 'UPSC और राज्य PCS के माध्यम से जिला प्रशासन, विदेश नीति और संवैधानिक शासन।',
      },
      salaryRange: {
        en: '₹8.4L – ₹15.0L / yr (7th CPC Pay Level 10 + Perks)',
        hi: '₹8.4L – ₹15.0L / वर्ष (पे लेवल 10 + सरकारी सुविधाएं)',
      },
      firstYearMonthlyInr: 75000,
      totalCost: {
        en: '₹0.5L – ₹2.5L (Grad Degree + Self-Study/Test Series)',
        hi: '₹0.5L – ₹2.5L (स्नातक डिग्री + टेस्ट सीरीज़)',
      },
      totalCostLakhs: 1.5,
      difficulty: {
        en: 'EXTREME (<0.2% Selection Ratio)',
        hi: 'अत्यंत कठिन / EXTREME (<0.2% चयन अनुपात)',
      },
      primaryExams: 'UPSC CSE, State PCS, RBI Grade B,NABARD, SSC CGL',
      planBSummary: {
        en: 'Mandatory Plan B after 2 attempts -> RBI Grade B / State PCS / Public Policy Masters',
        hi: '2 प्रयासों के बाद अनिवार्य Plan B -> RBI Grade B / State PCS / पब्लिक पॉलिसी',
      },
      lastVerified: '2026-10-15',
      roadmap: [
        {
          stepNumber: '01',
          stageTitle: {
            en: 'Undergraduate Degree with Employable Skill + NCERT Base',
            hi: 'रोजगारपरक स्नातक डिग्री (B.Tech/BA/B.Com) + NCERT आधार',
          },
          duration: { en: '36 Months', hi: '36 महीने' },
          details: {
            en: 'Complete graduation while mastering Polity (Laxmikanth), Economy, History, and Optional subject.',
            hi: 'स्नातक के साथ पॉलिटी, इकोनॉमी, इतिहास और अपने वैकल्पिक विषय (Optional) को तैयार करें।',
          },
          keyExamOrMilestone: 'Graduation + NCERT Completion',
          planB: {
            triggerCondition: {
              en: 'Before starting full-time UPSC preparation',
              hi: 'पूर्णकालिक UPSC तैयारी शुरू करने से पहले',
            },
            targetCareerId: 'ca-chartered',
            targetCareerName: {
              en: 'RBI Grade B / Regulatory Body Officer',
              hi: 'RBI Grade B / नियामक निकाय अधिकारी',
            },
            rationale: {
              en: 'Overlapping Economy & Finance syllabus provides a high-paying central banking career.',
              hi: 'इकोनॉमी और फाइनेंस के समान सिलेबस से RBI में उच्च वेतन वाला करियर मिलता है।',
            },
          },
        },
        {
          stepNumber: '02',
          stageTitle: {
            en: 'Prelims (CSAT + GS) -> Mains (9 Papers) -> Interview',
            hi: 'प्रिलिम्स (GS + CSAT) -> मेंस (9 पेपर) -> साक्षात्कार',
          },
          duration: { en: '12–24 Months', hi: '12–24 महीने' },
          details: {
            en: 'Strict 2-attempt cap before working alongside preparation.',
            hi: 'अधिकतम 2 पूर्णकालिक प्रयास करें; उसके बाद नौकरी के साथ तैयारी जारी रखें।',
          },
          keyExamOrMilestone: 'UPSC CSE Prelims & Mains',
          planB: {
            triggerCondition: {
              en: 'If Prelims/Mains stalls after 2 attempts',
              hi: 'यदि 2 प्रयासों के बाद चयन न हो',
            },
            targetCareerId: 'bca-mca',
            targetCareerName: {
              en: 'Public Policy Fellow (LAMP / TISS) & Corporate ESG',
              hi: 'पब्लिक पॉलिसी फेलोशिप (LAMP / TISS) और कॉर्पोरेट कंसल्टिंग',
            },
            rationale: {
              en: 'Convert deep analytical writing and policy mastery into Think-Tank & ESG advisory roles.',
              hi: 'अपनी लेखन और नीति विश्लेषण क्षमता का उपयोग थिंक-टैंक और कॉर्पोरेट पॉलिसी में करें।',
            },
          },
        },
      ],
      thriveIf: [
        {
          en: 'You care deeply about grassroots public infrastructure, law, and governance.',
          hi: 'आप जमीनी स्तर के प्रशासन, कानून और सामाजिक विकास में गहरी रुचि रखते हैं।',
        },
        {
          en: 'You Already hold a strong Plan B degree before taking your first UPSC attempt.',
          hi: 'आपके पास पहला UPSC प्रयास देने से पहले एक मजबूत Plan B कौशल मौजूद है।',
        },
      ],
      reconsiderIf: [
        {
          en: 'You are drawn only by social media "royal entry" reels without reading 8 hours daily.',
          hi: 'यदि आप केवल सोशल मीडिया रील्स से प्रभावित हैं और रोज़ 8 घंटे पढ़ने को तैयार नहीं हैं।',
        },
      ],
      colleges: [
        {
          collegeName: 'LBSNAA Mussoorie (Post-Selection Foundation Training)',
          location: 'Uttarakhand',
          entranceCutoff: {
            en: 'UPSC CSE Top 180 AIR (for IAS)',
            hi: 'UPSC CSE टॉप 180 AIR (IAS के लिए)',
          },
          estimatedTotalFees: '₹0 (Stipend Paid by Govt of India)',
          avgPlacement: '7th CPC Level 10 Gazette Officer',
        },
        {
          collegeName: 'DU (St. Stephen’s / Hindu / LSR) / JNU / BHU (UG Base)',
          location: 'New Delhi / Varanasi',
          entranceCutoff: {
            en: 'CUET UG 99+ Percentile',
            hi: 'CUET UG 99+ परसेंटाइल',
          },
          estimatedTotalFees: '₹0.45L – ₹1.20L',
          avgPlacement: '₹7.5L – ₹12.0L',
        },
      ],
      resources: {
        pyqs: [
          {
            title: {
              en: 'UPSC Official Previous Year Question Papers (GS I–IV & CSAT)',
              hi: 'UPSC आधिकारिक पिछले वर्षों के प्रश्नपत्र (GS और CSAT)',
            },
            source: 'upsc.gov.in',
            typeTag: 'Official PDF',
            url: 'https://upsc.gov.in',
          },
        ],
        govtPortals: [
          {
            title: {
              en: 'PIB (Press Information Bureau) & PRS Legislative Research',
              hi: 'PIB (प्रेस सूचना ब्यूरो) और PRS लेजिस्लेटिव रिसर्च',
            },
            source: 'prsindia.org',
            typeTag: 'Policy Data',
            url: 'https://prsindia.org',
          },
        ],
        youtube: [
          {
            title: {
              en: 'Sansad TV — Perspective & Policy Debates',
              hi: 'संसद टीवी (Sansad TV) — नीति और संविधान चर्चा',
            },
            source: 'Sansad TV',
            typeTag: 'Broadcast',
            url: 'https://www.youtube.com',
          },
        ],
        nptel: [
          {
            title: {
              en: 'Swayam Constitutional Studies & Indian Economy Modules',
              hi: 'स्वयं (Swayam) भारतीय संविधान और अर्थव्यवस्था मॉड्यूल',
            },
            source: 'swayam.gov.in',
            typeTag: 'Govt Course',
            url: 'https://swayam.gov.in',
          },
        ],
        books: [
          {
            title: {
              en: 'NCERT Class 6–12 History, Geography, Polity & IGNOU Notes',
              hi: 'NCERT कक्षा 6–12 इतिहास, भूगोल, पॉलिटी और IGNOU नोट्स',
            },
            source: 'egyankosh.ac.in',
            typeTag: 'Free eBooks',
            url: 'https://egyankosh.ac.in',
          },
        ],
        scholarships: [
          {
            title: {
              en: 'State Free Civil Services Coaching & Stipend Schemes (SWD)',
              hi: 'राज्य सरकार निःशुल्क सिविल सेवा कोचिंग और छात्रवृत्ति योजना',
            },
            source: 'State Portal',
            typeTag: 'Free Coaching',
            url: 'https://scholarships.gov.in',
          },
        ],
        internships: [
          {
            title: {
              en: 'NITI Aayog Undergraduate & Research Internship Portal',
              hi: 'नीति आयोग (NITI Aayog) रिसर्च इंटर्नशिप प्रोग्राम',
            },
            source: 'niti.gov.in',
            typeTag: 'Policy Track',
            url: 'https://www.niti.gov.in',
          },
        ],
        mockTests: [
          {
            title: {
              en: 'UPSC Official CDS / CAPF / CSE Objective Question Bank',
              hi: 'UPSC आधिकारिक प्रैक्टिस प्रश्न बैंक (GS + CSAT)',
            },
            source: 'upsc.gov.in',
            typeTag: 'Official Bank',
            url: 'https://upsc.gov.in',
          },
        ],
      },
    },
    {
      id: 'uiux-des',
      categoryId: 'des',
      code: 'BP-501',
      icon: '◫',
      title: {
        en: 'Product Designer & Design Technologist (B.Des / UCEED)',
        hi: 'प्रोडक्ट डिज़ाइनर और UI/UX आर्किटेक्ट (B.Des / UCEED)',
      },
      tagline: {
        en: 'Human-computer interaction, industrial design, and SaaS interface engineering.',
        hi: 'ह्यूमन-कंप्यूटर इंटरैक्शन, इंडस्ट्रियल डिज़ाइन और SaaS इंटरफेस आर्किटेक्चर।',
      },
      salaryRange: {
        en: '₹6.0L – ₹20.0L / yr (Product / UX Designer)',
        hi: '₹6.0L – ₹20.0L / वर्ष (प्रोडक्ट / UI-UX डिज़ाइनर)',
      },
      firstYearMonthlyInr: 62000,
      totalCost: {
        en: '₹4.0L – ₹12.0L (IIT / NID B.Des)',
        hi: '₹4.0L – ₹12.0L (IIT / NID B.Des कुल फीस)',
      },
      totalCostLakhs: 7.5,
      difficulty: {
        en: 'MODERATE-HIGH (UCEED / NID DAT)',
        hi: 'मध्यम-उच्च / MODERATE-HIGH (UCEED / NID DAT)',
      },
      primaryExams: 'UCEED (IITs), NID DAT, NIFT Entrance',
      planBSummary: {
        en: 'If UCEED misses -> Self-Taught Figma + Frontend React Portfolio + Any UG Degree',
        hi: 'यदि UCEED न निकले -> Figma + Frontend पोर्टफोलियो के साथ डायरेक्ट UX करियर',
      },
      lastVerified: '2026-10-15',
      roadmap: [
        {
          stepNumber: '01',
          stageTitle: {
            en: 'UCEED & NID DAT Spatial & Visual Aptitude',
            hi: 'UCEED और NID DAT विजुअल एप्टीट्यूड तैयारी',
          },
          duration: { en: '12 Months', hi: '12 महीने' },
          details: {
            en: 'Open to Science, Commerce, and Arts students; tests observation, sketching, and spatial logic.',
            hi: 'साइंस, कॉमर्स और आर्ट्स सभी छात्रों के लिए खुला; अवलोकन और डिज़ाइन लॉजिक की परीक्षा।',
          },
          keyExamOrMilestone: 'UCEED / NID DAT',
          planB: {
            triggerCondition: {
              en: 'If IIT / NID B.Des seats are full',
              hi: 'यदि IIT या NID में सीट न मिले',
            },
            targetCareerId: 'bca-mca',
            targetCareerName: {
              en: 'BCA / BA + Case-Study Portfolio Track',
              hi: 'BCA / BA + रियल UX केस-स्टडी पोर्टफोलियो',
            },
            rationale: {
              en: 'Tech startups hire UX designers based 90% on live Figma case studies, not college tags.',
              hi: 'स्टार्टअप्स में 90% भर्ती आपके Figma पोर्टफोलियो के आधार पर होती है, कॉलेज टैग पर नहीं।',
            },
          },
        },
        {
          stepNumber: '02',
          stageTitle: {
            en: 'Design Systems, Prototyping & User Research',
            hi: 'डिज़ाइन सिस्टम्स, प्रोटोटाइपिंग और यूजर रिसर्च',
          },
          duration: { en: '36 Months', hi: '36 महीने' },
          details: {
            en: 'Ship 4 end-to-end usability case studies solving real Indian workflows (UPI, ONDC, IRCTC).',
            hi: 'UPI, ONDC या IRCTC जैसे वास्तविक भारतीय ऐप्स पर 4 विस्तृत केस स्टडी तैयार करें।',
          },
          keyExamOrMilestone: '4 Production Case Studies',
          planB: {
            triggerCondition: {
              en: 'If you want higher engineering leverage',
              hi: 'यदि आप डिज़ाइन के साथ कोडिंग भी जोड़ना चाहें',
            },
            targetCareerId: 'btech-cse',
            targetCareerName: {
              en: 'Design Engineer (UI + Frontend Code)',
              hi: 'डिज़ाइन इंजीनियर (UI + Frontend Code)',
            },
            rationale: {
              en: 'Designers who can write clean HTML/CSS/JS command a 40% salary premium.',
              hi: 'जो डिज़ाइनर HTML/CSS/JS कोड भी लिख सकते हैं, उन्हें 40% अधिक पैकेज मिलता है।',
            },
          },
        },
      ],
      thriveIf: [
        {
          en: 'You notice bad app layouts, typography, and confusing buttons everywhere.',
          hi: 'आप हर ऐप के लेआउट, फॉन्ट और यूजर एक्सपीरियंस की बारीकियों को तुरंत नोटिस करते हैं।',
        },
        {
          en: 'You enjoy combining psychology, visual craft, and technology.',
          hi: 'आप मनोविज्ञान, विजुअल डिज़ाइन और टेक्नोलॉजी का संगम पसंद करते हैं।',
        },
      ],
      reconsiderIf: [
        {
          en: 'You take design critique and user testing feedback personally.',
          hi: 'यदि आप अपने डिज़ाइन पर मिलने वाले फीडबैक से जल्दी निराश हो जाते हैं।',
        },
      ],
      colleges: [
        {
          collegeName: 'IIT Bombay (IDC) / IIT Guwahati / IIT Delhi (B.Des)',
          location: 'Mumbai / Guwahati / Delhi',
          entranceCutoff: {
            en: 'UCEED Top 150 AIR',
            hi: 'UCEED टॉप 150 AIR',
          },
          estimatedTotalFees: '₹8.0L – ₹9.5L',
          avgPlacement: '₹16.0L – ₹22.0L',
        },
        {
          collegeName: 'National Institute of Design (NID Ahmedabad)',
          location: 'Ahmedabad, Gujarat',
          entranceCutoff: {
            en: 'NID DAT Prelims + Studio Test',
            hi: 'NID DAT प्रिलिम्स + स्टूडियो टेस्ट',
          },
          estimatedTotalFees: '₹11.5L – ₹13.0L',
          avgPlacement: '₹14.0L – ₹19.0L',
        },
      ],
      resources: {
        pyqs: [
          {
            title: {
              en: 'UCEED & CEED Official Question Papers + Answer Keys (IIT Bombay)',
              hi: 'UCEED और CEED आधिकारिक पुराने प्रश्नपत्र (IIT Bombay)',
            },
            source: 'uceed.iitb.ac.in',
            typeTag: 'Official PYQ',
            url: 'https://www.uceed.iitb.ac.in',
          },
        ],
        govtPortals: [
          {
            title: {
              en: 'Design Innovation Centre (DIC) Ministry of Education',
              hi: 'डिज़ाइन इनोवेशन सेंटर (DIC) शिक्षा मंत्रालय पोर्टल',
            },
            source: 'education.gov.in',
            typeTag: 'Govt Initiative',
            url: 'https://www.education.gov.in',
          },
        ],
        youtube: [
          {
            title: {
              en: 'Figma Official Design Systems & Auto-Layout Masterclass',
              hi: 'Figma आधिकारिक डिज़ाइन सिस्टम्स और ऑटो-लेआउट कोर्स',
            },
            source: 'Figma YouTube',
            typeTag: 'Free Video',
            url: 'https://www.youtube.com',
          },
        ],
        nptel: [
          {
            title: {
              en: 'NPTEL Human-Computer Interaction (IIT Guwahati)',
              hi: 'NPTEL ह्यूमन-कंप्यूटर इंटरैक्शन (IIT Guwahati)',
            },
            source: 'swayam.gov.in',
            typeTag: 'Swayam',
            url: 'https://swayam.gov.in',
          },
        ],
        books: [
          {
            title: {
              en: 'The Design of Everyday Things (Don Norman) & Refactoring UI',
              hi: 'The Design of Everyday Things (Don Norman) सारांश नोट्स',
            },
            source: 'Open Design Library',
            typeTag: 'Core Reading',
            url: 'https://www.nngroup.com',
          },
        ],
        scholarships: [
          {
            title: {
              en: 'IIT MCM (Merit-cum-Means) Tuition Waiver for B.Des',
              hi: 'IIT मेरिट-कम-मीन्स (MCM) B.Des फीस माफी योजना',
            },
            source: 'iitb.ac.in',
            typeTag: 'Fee Waiver',
            url: 'https://www.uceed.iitb.ac.in',
          },
        ],
        internships: [
          {
            title: {
              en: 'IDC IIT Bombay Summer Design Fellowship & Startup Internships',
              hi: 'IDC IIT Bombay समर डिज़ाइन इंटर्नशिप प्रोग्राम',
            },
            source: 'idc.iitb.ac.in',
            typeTag: 'Paid Internship',
            url: 'https://www.idc.iitb.ac.in',
          },
        ],
        mockTests: [
          {
            title: {
              en: 'UCEED Part-A NAT / MSQ / MCQ Interactive Simulator',
              hi: 'UCEED पार्ट-A (NAT / MSQ / MCQ) प्रैक्टिस टेस्ट',
            },
            source: 'uceed.iitb.ac.in',
            typeTag: 'Mock Portal',
            url: 'https://www.uceed.iitb.ac.in',
          },
        ],
      },
    },
  ],
};

export interface QuizOption {
  label: BilingualText;
  weights: Record<string, number>;
}

export interface QuizQuestion {
  id: number;
  prompt: BilingualText;
  options: QuizOption[];
}

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    prompt: {
      en: '01. When solving a complex problem, which environment excites you most?',
      hi: '01. किसी जटिल समस्या को हल करते समय आपको कौन-सा काम सबसे अधिक आकर्षित करता है?',
    },
    options: [
      {
        label: {
          en: 'Writing code & automating systems on a computer',
          hi: 'कंप्यूटर पर कोड लिखना और ऑटोमेटेड सिस्टम बनाना',
        },
        weights: { 'btech-cse': 4, 'bca-mca': 3, 'uiux-des': 1 },
      },
      {
        label: {
          en: 'Diagnosing human biology & clinical patient care',
          hi: 'मानव जीव विज्ञान और मरीजों का क्लिनिकल उपचार (MBBS)',
        },
        weights: { 'mbbs-clinician': 5 },
      },
      {
        label: {
          en: 'Auditing financial ledgers, tax laws & capital markets',
          hi: 'वित्तीय बैलेंस शीट, टैक्स कानून और कॉर्पोरेट ऑडिट (CA)',
        },
        weights: { 'ca-chartered': 5 },
      },
      {
        label: {
          en: 'Drafting public policy & district administration',
          hi: 'लोक नीति बनाना और जिला प्रशासन चलाना (UPSC)',
        },
        weights: { 'upsc-civil': 5 },
      },
    ],
  },
  {
    id: 2,
    prompt: {
      en: '02. What is your family’s comfortable total undergraduate education budget (without distress loans)?',
      hi: '02. बिना किसी भारी कर्ज के आपके परिवार का कुल स्नातक शिक्षा बजट कितना है?',
    },
    options: [
      {
        label: {
          en: 'Under ₹2.5 Lakhs total (Strict self-study / Govt route)',
          hi: '₹2.5 लाख से कम (सरकारी कॉलेज / सेल्फ-स्टडी ट्रैक)',
        },
        weights: { 'ca-chartered': 4, 'upsc-civil': 3, 'bca-mca': 3 },
      },
      {
        label: {
          en: '₹3 Lakhs – ₹6 Lakhs total (Moderate ROI focus)',
          hi: '₹3 लाख – ₹6 लाख कुल (उच्च ROI फोकस)',
        },
        weights: { 'bca-mca': 4, 'mbbs-clinician': 2, 'btech-cse': 2 },
      },
      {
        label: {
          en: '₹6 Lakhs – ₹15 Lakhs total (Standard IIT / NIT / B.Des fees)',
          hi: '₹6 लाख – ₹15 लाख कुल (IIT / NIT / B.Des मानक फीस)',
        },
        weights: { 'btech-cse': 4, 'uiux-des': 4 },
      },
      {
        label: {
          en: 'Merit Scholarship / Govt Seat Only',
          hi: 'केवल मेरिट छात्रवृत्ति या सरकारी सीट',
        },
        weights: { 'mbbs-clinician': 3, 'btech-cse': 2, 'upsc-civil': 2 },
      },
    ],
  },
  {
    id: 3,
    prompt: {
      en: '03. How soon do you need your first full-time professional paycheck?',
      hi: '03. आपको अपनी पहली पूर्णकालिक सैलरी कब तक शुरू करने की आवश्यकता है?',
    },
    options: [
      {
        label: {
          en: 'Within 3 to 4 years right after graduation (Age 21–22)',
          hi: '3 से 4 साल में स्नातक होते ही (21–22 वर्ष की आयु में)',
        },
        weights: { 'btech-cse': 4, 'bca-mca': 4, 'uiux-des': 4 },
      },
      {
        label: {
          en: 'Earn a stipend during training, full paycheck in 4.5 years',
          hi: 'ट्रेनिंग के दौरान स्टाइपेंड और 4.5 साल में पूर्ण पैकेज (CA)',
        },
        weights: { 'ca-chartered': 5 },
      },
      {
        label: {
          en: 'I can invest 6 to 8 years for deep clinical or administrative mastery',
          hi: 'मैं गहन विशेषज्ञता के लिए 6 से 8 साल देने को तैयार हूँ (MBBS / UPSC)',
        },
        weights: { 'mbbs-clinician': 4, 'upsc-civil': 4 },
      },
    ],
  },
  {
    id: 4,
    prompt: {
      en: '04. Which Class 11–12 subject combination feels most natural to you?',
      hi: '04. कक्षा 11–12 में कौन-सा विषय समूह आपको सबसे सहज लगता है?',
    },
    options: [
      {
        label: {
          en: 'Physics, Chemistry & Mathematics (PCM + Coding)',
          hi: 'फिजिक्स, केमिस्ट्री और गणित (PCM + Coding)',
        },
        weights: { 'btech-cse': 5, 'bca-mca': 3, 'uiux-des': 2 },
      },
      {
        label: {
          en: 'Physics, Chemistry & Biology (PCB + Life Sciences)',
          hi: 'फिजिक्स, केमिस्ट्री और बायोलॉजी (PCB)',
        },
        weights: { 'mbbs-clinician': 5 },
      },
      {
        label: {
          en: 'Accountancy, Economics, Business Studies & Applied Math',
          hi: 'अकाउंटेंसी, इकोनॉमिक्स और बिजनेस स्टडीज (Commerce)',
        },
        weights: { 'ca-chartered': 5, 'bca-mca': 2 },
      },
      {
        label: {
          en: 'Political Science, History, Design & Visual Communication',
          hi: 'पॉलिटिकल साइंस, इतिहास और विजुअल डिज़ाइन (Arts / Design)',
        },
        weights: { 'upsc-civil': 4, 'uiux-des': 4 },
      },
    ],
  },
  {
    id: 5,
    prompt: {
      en: '05. How do you handle high-stakes competitive entrance exams?',
      hi: '05. आप उच्च-प्रतिस्पर्धा वाली प्रवेश परीक्षाओं के प्रति कैसा दृष्टिकोण रखते हैं?',
    },
    options: [
      {
        label: {
          en: 'Ready for JEE Main / Advanced algorithmic & numerical pressure',
          hi: 'JEE Main / Advanced के न्यूमेरिकल प्रश्नों के लिए तैयार',
        },
        weights: { 'btech-cse': 4 },
      },
      {
        label: {
          en: 'Prefer practical skill portfolios + moderate entrance exams (CUET / UCEED)',
          hi: 'प्रैक्टिकल पोर्टफोलियो और मध्यम प्रवेश परीक्षा (CUET / UCEED) पसंद है',
        },
        weights: { 'bca-mca': 4, 'uiux-des': 4 },
      },
      {
        label: {
          en: 'High accuracy in NCERT Biology & Chemistry (NEET UG)',
          hi: 'NCERT बायोलॉजी और केमिस्ट्री में उच्च सटीकता (NEET UG)',
        },
        weights: { 'mbbs-clinician': 4 },
      },
      {
        label: {
          en: 'Long-form analytical writing & multi-stage filtering (ICAI / UPSC)',
          hi: 'विश्लेषणात्मक लेखन और चरणबद्ध परीक्षाएं (ICAI / UPSC)',
        },
        weights: { 'ca-chartered': 3, 'upsc-civil': 4 },
      },
    ],
  },
  {
    id: 6,
    prompt: {
      en: '06. What kind of daily work output gives you the deepest satisfaction?',
      hi: '06. किस प्रकार का दैनिक कार्य आपको सबसे अधिक संतुष्टि देता है?',
    },
    options: [
      {
        label: {
          en: 'Shipping clean code & scalable web/cloud architecture',
          hi: 'क्लीन कोड और स्केलेबल सॉफ्टवेयर आर्किटेक्चर बनाना',
        },
        weights: { 'btech-cse': 4, 'bca-mca': 4 },
      },
      {
        label: {
          en: 'Crafting intuitive interfaces & design systems in Figma',
          hi: 'Figma में बेहतरीन UI/UX और प्रोडक्ट डिज़ाइन तैयार करना',
        },
        weights: { 'uiux-des': 5 },
      },
      {
        label: {
          en: 'Treating patients in OPDs, wards & operating theatres',
          hi: 'OPD और ऑपरेशन थिएटर में मरीजों का इलाज करना',
        },
        weights: { 'mbbs-clinician': 5 },
      },
      {
        label: {
          en: 'Signing statutory audit reports or leading public projects',
          hi: 'ऑडिट रिपोर्ट साइन करना या सरकारी योजनाओं का नेतृत्व करना',
        },
        weights: { 'ca-chartered': 3, 'upsc-civil': 3 },
      },
    ],
  },
  {
    id: 7,
    prompt: {
      en: '07. If your primary exam misses by 5 marks, what is your ideal Plan B style?',
      hi: '07. यदि मुख्य परीक्षा कुछ अंकों से रह जाए, तो आपका आदर्श Plan B कैसा होना चाहिए?',
    },
    options: [
      {
        label: {
          en: 'Enter the exact same tech industry via BCA + NIMCET or Open Source',
          hi: 'BCA + NIMCET या ओपन-सोर्स के जरिए उसी टेक इंडस्ट्री में प्रवेश',
        },
        weights: { 'bca-mca': 5, 'btech-cse': 3 },
      },
      {
        label: {
          en: 'Pivot to UI/UX Product Design using visual & frontend skills',
          hi: 'विजुअल और फ्रंटएंड कौशल से UI/UX प्रोडक्ट डिज़ाइन में जाना',
        },
        weights: { 'uiux-des': 4 },
      },
      {
        label: {
          en: 'Target RBI Grade B, MBA Finance, or Corporate Tax Advisory',
          hi: 'RBI Grade B, MBA Finance या कॉर्पोरेट टैक्स कंसल्टिंग चुनना',
        },
        weights: { 'ca-chartered': 4, 'upsc-civil': 3 },
      },
      {
        label: {
          en: 'Pivot to Clinical Research, Biotech, or Public Health Policy',
          hi: 'क्लिनिकल रिसर्च, बायोटेक या पब्लिक हेल्थ पॉलिसी चुनना',
        },
        weights: { 'mbbs-clinician': 3, 'upsc-civil': 2 },
      },
    ],
  },
  {
    id: 8,
    prompt: {
      en: '08. Where would you prefer to work 5 years from now?',
      hi: '08. आज से 5 साल बाद आप किस कार्यस्थल में काम करना पसंद करेंगे?',
    },
    options: [
      {
        label: {
          en: 'High-growth engineering startup or global R&D center (Bengaluru/Hyderabad/Remote)',
          hi: 'टेक स्टार्टअप या ग्लोबल R&D सेंटर (बेंगलुरु / हैदराबाद / रिमोट)',
        },
        weights: { 'btech-cse': 3, 'bca-mca': 3, 'uiux-des': 3 },
      },
      {
        label: {
          en: 'Tertiary teaching hospital or specialized medical institute',
          hi: 'बड़ा शिक्षण अस्पताल (AIIMS/GMC) या सुपर-स्पेशियलिटी क्लिनिक',
        },
        weights: { 'mbbs-clinician': 5 },
      },
      {
        label: {
          en: 'Big-4 Financial Advisory, Investment Bank, or Independent Practice',
          hi: 'Big-4 फाइनेंशियल फर्म, इन्वेस्टमेंट बैंक या स्वतंत्र CA प्रैक्टिस',
        },
        weights: { 'ca-chartered': 5 },
      },
      {
        label: {
          en: 'District Collectorate, Secretariat, or Constitutional Body',
          hi: 'जिला कलेक्ट्रेट, मंत्रालय सचिवालय या संवैधानिक संस्थान',
        },
        weights: { 'upsc-civil': 5 },
      },
    ],
  },
  {
    id: 9,
    prompt: {
      en: '09. How do you prefer to learn new skills?',
      hi: '09. आप नए कौशल सीखना किस प्रकार पसंद करते हैं?',
    },
    options: [
      {
        label: {
          en: 'Documentation, GitHub repos & building live prototypes',
          hi: 'डॉक्यूमेंटेशन, GitHub रिपॉजिटरी और लाइव प्रोटोटाइप बनाकर',
        },
        weights: { 'btech-cse': 3, 'bca-mca': 4, 'uiux-des': 3 },
      },
      {
        label: {
          en: 'Laboratory dissection, clinical case rounds & textbooks',
          hi: 'लैब प्रैक्टिकल, क्लिनिकल केस राउंड और मानक पाठ्यपुस्तकों से',
        },
        weights: { 'mbbs-clinician': 4 },
      },
      {
        label: {
          en: 'Solving structured audit cases, tax codes & numerical sets',
          hi: 'ऑडिट केस स्टडी, टैक्स कोड और न्यूमेरिकल सेट हल करके',
        },
        weights: { 'ca-chartered': 4 },
      },
      {
        label: {
          en: 'Reading newspapers, committee reports & constitutional debates',
          hi: 'अखबार के संपादकीय, समिति रिपोर्ट और संवैधानिक बहस पढ़कर',
        },
        weights: { 'upsc-civil': 4 },
      },
    ],
  },
  {
    id: 10,
    prompt: {
      en: '10. Which long-term trade-off are you most willing to accept?',
      hi: '10. आप भविष्य के लिए कौन-सी व्यावहारिक चुनौती स्वीकार करने को तैयार हैं?',
    },
    options: [
      {
        label: {
          en: 'Continuous upskilling as software & AI tools evolve rapidly',
          hi: 'सॉफ्टवेयर और टेक्नोलॉजी बदलने के साथ निरंतर नया सीखना',
        },
        weights: { 'btech-cse': 3, 'bca-mca': 3, 'uiux-des': 3 },
      },
      {
        label: {
          en: 'Night duties and intense postgraduate entrance exams (NEET PG)',
          hi: 'नाइट ड्यूटी और पोस्टग्रेजुएट परीक्षा (NEET PG) की कड़ी मेहनत',
        },
        weights: { 'mbbs-clinician': 4 },
      },
      {
        label: {
          en: 'Strict ICAI passing percentages & March/September audit deadlines',
          hi: 'ICAI का कड़ा पास प्रतिशत और ऑडिट सीजन की समय-सीमा',
        },
        weights: { 'ca-chartered': 4 },
      },
      {
        label: {
          en: 'Frequent transfers and public accountability in government service',
          hi: 'सरकारी सेवा में नियमित तबादले और सार्वजनिक जवाबदेही',
        },
        weights: { 'upsc-civil': 4 },
      },
    ],
  },
];

export interface QuizEvaluationResult {
  isMixedConflict: boolean;
  messageEn: string;
  messageHi: string;
  topMatches: {
    career: CareerChild;
    score: number;
    matchPercentage: number;
  }[];
}

/**
 * Pure deterministic weighted scoring algorithm for the 10-question CareerPathO quiz.
 * Returns Top 3 Career Matches, and triggers the conflict fallback ("Your vibes are mixed, browse all")
 * when answers are spread evenly across conflicting domains.
 */
export function evaluateDeterministicQuiz(
  selectedOptionIndices: number[],
  children: CareerChild[]
): QuizEvaluationResult {
  const scoreMap: Record<string, number> = {};
  for (const child of children) {
    scoreMap[child.id] = 0;
  }

  selectedOptionIndices.forEach((optIdx, qIdx) => {
    const question = QUIZ_QUESTIONS[qIdx];
    if (!question) return;
    const option = question.options[optIdx];
    if (!option) return;
    for (const [careerId, weight] of Object.entries(option.weights)) {
      if (typeof scoreMap[careerId] === 'number') {
        scoreMap[careerId] += weight;
      }
    }
  });

  const sorted = children
    .map((career) => {
      const rawScore = scoreMap[career.id] || 0;
      const matchPercentage = Math.min(98, Math.max(42, 45 + rawScore * 2));
      return { career, score: rawScore, matchPercentage };
    })
    .sort((a, b) => b.score - a.score);

  const top1 = sorted[0]?.score ?? 0;
  const top3 = sorted[2]?.score ?? 0;
  const top4 = sorted[3]?.score ?? 0;

  // Conflict condition: if the spread between #1 and #4 is <= 3 points or top1 <= 11, answers conflict across domains
  const isMixedConflict = top1 <= 11 || top1 - top4 <= 3 || top1 - top3 <= 1;

  return {
    isMixedConflict,
    messageEn: isMixedConflict
      ? 'Your vibes are mixed, browse all'
      : 'Deterministic Architectural Match Verified — Top 3 Career Blueprints',
    messageHi: isMixedConflict
      ? 'आपकी रुचियां मिश्रित हैं (Your vibes are mixed, browse all) — सभी करियर ब्लूप्रिंट देखें'
      : 'निर्धारित स्कोरिंग विश्लेषण पूर्ण — आपके शीर्ष 3 करियर मैच',
    topMatches: sorted.slice(0, 3),
  };
}

export interface EmiCalculationResult {
  principalInr: number;
  annualRatePercent: number;
  tenureMonths: number;
  monthlyEmiInr: number;
  totalPayableInr: number;
  totalInterestInr: number;
}

/**
 * Calculates the static EMI for the Reality Check Box (default ₹5,00,000 loan at 9% p.a. for 60 months).
 */
export function calculateLoanEmi(
  principalInr = 500000,
  annualRatePercent = 9,
  tenureYears = 5
): EmiCalculationResult {
  const tenureMonths = tenureYears * 12;
  const r = annualRatePercent / 12 / 100;
  const factor = Math.pow(1 + r, tenureMonths);
  const emi = Math.round((principalInr * r * factor) / (factor - 1));
  const totalPayableInr = emi * tenureMonths;
  const totalInterestInr = totalPayableInr - principalInr;

  return {
    principalInr,
    annualRatePercent,
    tenureMonths,
    monthlyEmiInr: emi,
    totalPayableInr,
    totalInterestInr,
  };
}

/**
 * Loads `localStorage['careerpatho-data']` or seeds it with `DEFAULT_CAREERPATHO_DATA`.
 */
export function loadCareerPathOData(): CareerPathOStorageShape {
  if (typeof window === 'undefined' || !window.localStorage) {
    return DEFAULT_CAREERPATHO_DATA;
  }
  try {
    const raw = window.localStorage.getItem(CAREERPATHO_STORAGE_KEY);
    if (!raw) {
      window.localStorage.setItem(
        CAREERPATHO_STORAGE_KEY,
        JSON.stringify(DEFAULT_CAREERPATHO_DATA)
      );
      return DEFAULT_CAREERPATHO_DATA;
    }
    const parsed = JSON.parse(raw) as CareerPathOStorageShape;
    if (
      parsed &&
      Array.isArray(parsed.categories) &&
      Array.isArray(parsed.comingSoon) &&
      parsed.parents &&
      Array.isArray(parsed.children) &&
      parsed.children.length > 0
    ) {
      return parsed;
    }
  } catch {
    // Re-seed if corrupted
  }
  try {
    window.localStorage.setItem(
      CAREERPATHO_STORAGE_KEY,
      JSON.stringify(DEFAULT_CAREERPATHO_DATA)
    );
  } catch {
    // ignore quota error
  }
  return DEFAULT_CAREERPATHO_DATA;
}
