import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { Color, Move, Piece, squareToCoords } from '../game/chessEngine';

interface SmartBoard3DProps {
  board: (Piece | null)[][];
  lastMove: Move | null;
  insideView: boolean;
  autoDemo: boolean;
  sensorOverlay: boolean;
  cameraPreset: 'default' | 'top' | 'cutaway';
  onSquareClick: (sq: string) => void;
  selectedSquare: string | null;
  legalTargetSquares: string[];
  activeFlowStage: number;
}

const FILES = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
const RANKS = ['8', '7', '6', '5', '4', '3', '2', '1'];

export const SmartBoard3D: React.FC<SmartBoard3DProps> = ({
  board,
  lastMove,
  insideView,
  autoDemo,
  sensorOverlay,
  cameraPreset,
  onSquareClick,
  selectedSquare,
  legalTargetSquares,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);

  // Store latest props in refs so React HUD updates never tear down the WebGL context
  const propsRef = useRef({
    board,
    lastMove,
    insideView,
    autoDemo,
    sensorOverlay,
    cameraPreset,
    onSquareClick,
    selectedSquare,
    legalTargetSquares,
  });

  useEffect(() => {
    propsRef.current = {
      board,
      lastMove,
      insideView,
      autoDemo,
      sensorOverlay,
      cameraPreset,
      onSquareClick,
      selectedSquare,
      legalTargetSquares,
    };
  }, [
    board,
    lastMove,
    insideView,
    autoDemo,
    sensorOverlay,
    cameraPreset,
    onSquareClick,
    selectedSquare,
    legalTargetSquares,
  ]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Detect software WebGL (SwiftShader / llvmpipe)
    const isSoftwareGl = (() => {
      const probeCanvas = document.createElement('canvas');
      const gl = probeCanvas.getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const width = container.clientWidth || 640;
    const height = container.clientHeight || 420;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x07111e);
    scene.fog = new THREE.FogExp2(0x07111e, 0.028);

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 120);
    camera.position.set(0, 9.5, 11.5);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.setSize(width, height);
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // 2. Studio Environment Map (RoomEnvironment)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 3. Warm/Cool 3-Point Studio Lighting Rig
    const hemiLight = new THREE.HemisphereLight(0x88e5ff, 0x0a1929, 0.75);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff4d6, 1.9);
    keyLight.position.set(7, 14, 8);
    if (!isSoftwareGl) {
      keyLight.castShadow = true;
      keyLight.shadow.mapSize.set(1024, 1024);
      keyLight.shadow.camera.near = 1;
      keyLight.shadow.camera.far = 35;
      const d = 6.5;
      keyLight.shadow.camera.left = -d;
      keyLight.shadow.camera.right = d;
      keyLight.shadow.camera.top = d;
      keyLight.shadow.camera.bottom = -d;
      keyLight.shadow.bias = -0.0005;
    }
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x00e5ff, 0.9);
    rimLight.position.set(-8, 6, -7);
    scene.add(rimLight);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = !isSoftwareGl;
    controls.dampingFactor = 0.08;
    controls.maxPolarAngle = Math.PI * 0.48;
    controls.minDistance = 5.5;
    controls.maxDistance = 22;
    controls.target.set(0, 0, 0);

    // Contact shadow disc beneath smart board chassis
    const shadowDisc = new THREE.Mesh(
      new THREE.CircleGeometry(6.8, 32),
      new THREE.MeshBasicMaterial({
        color: 0x000000,
        transparent: true,
        opacity: 0.45,
        depthWrite: false,
      })
    );
    shadowDisc.rotation.x = -Math.PI / 2;
    shadowDisc.position.y = -1.45;
    scene.add(shadowDisc);

    // =========================================================================
    // SMART CHESS BOARD 4-LAYER COMPOSITE HIERARCHY (Explodable via Inside View)
    // =========================================================================
    const rootGroup = new THREE.Group();
    scene.add(rootGroup);

    // Layer 0: Base Chassis & ESP32 / Stockfish Neural Coprocessor
    const baseLayer = new THREE.Group();
    rootGroup.add(baseLayer);

    const chassisMat = new THREE.MeshStandardMaterial({
      color: 0x0d1f33,
      roughness: 0.4,
      metalness: 0.65,
    });
    const goldTrimMat = new THREE.MeshStandardMaterial({
      color: 0xffd700,
      roughness: 0.22,
      metalness: 0.88,
    });
    const cyanEmissiveMat = new THREE.MeshStandardMaterial({
      color: 0x00e5ff,
      emissive: 0x00e5ff,
      emissiveIntensity: 0.85,
      roughness: 0.2,
    });

    const baseTray = new THREE.Mesh(new THREE.BoxGeometry(9.2, 0.35, 9.2), chassisMat);
    baseTray.position.y = -1.2;
    baseLayer.add(baseTray);

    const goldRim = new THREE.Mesh(new THREE.BoxGeometry(9.35, 0.12, 9.35), goldTrimMat);
    goldRim.position.y = -1.1;
    baseLayer.add(goldRim);

    // Neural Coprocessor Module inside base
    const mcuChip = new THREE.Mesh(
      new THREE.BoxGeometry(2.2, 0.18, 2.2),
      new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.3, metalness: 0.5 })
    );
    mcuChip.position.set(0, -0.95, 0);
    baseLayer.add(mcuChip);

    const mcuCoreGlow = new THREE.Mesh(
      new THREE.CylinderGeometry(0.55, 0.55, 0.22, 24),
      cyanEmissiveMat
    );
    mcuCoreGlow.position.set(0, -0.92, 0);
    baseLayer.add(mcuCoreGlow);

    // Layer 1: CoreXY Dual-Rail Electromagnet Gantry
    const gantryLayer = new THREE.Group();
    rootGroup.add(gantryLayer);

    const railMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      roughness: 0.2,
      metalness: 0.85,
    });
    const railGeo = new THREE.CylinderGeometry(0.07, 0.07, 8.2, 12);
    const leftRail = new THREE.Mesh(railGeo, railMat);
    leftRail.rotation.x = Math.PI / 2;
    leftRail.position.set(-3.9, -0.65, 0);
    const rightRail = new THREE.Mesh(railGeo, railMat);
    rightRail.rotation.x = Math.PI / 2;
    rightRail.position.set(3.9, -0.65, 0);
    gantryLayer.add(leftRail, rightRail);

    const xBridgeGroup = new THREE.Group();
    xBridgeGroup.position.set(0, -0.65, 0);
    gantryLayer.add(xBridgeGroup);

    const xBridgeBar = new THREE.Mesh(
      new THREE.BoxGeometry(7.8, 0.12, 0.24),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.35, metalness: 0.7 })
    );
    xBridgeGroup.add(xBridgeBar);

    // Electromagnet Carriage Head (3-part composite)
    const carriageGroup = new THREE.Group();
    xBridgeGroup.add(carriageGroup);

    const carriageBody = new THREE.Mesh(
      new THREE.BoxGeometry(0.75, 0.24, 0.75),
      goldTrimMat
    );
    const coilSpool = new THREE.Mesh(
      new THREE.CylinderGeometry(0.32, 0.32, 0.34, 20),
      new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.3, metalness: 0.8 })
    );
    coilSpool.position.y = 0.14;
    const magnetHalo = new THREE.Mesh(
      new THREE.RingGeometry(0.22, 0.42, 24),
      new THREE.MeshBasicMaterial({
        color: 0x00e5ff,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.9,
      })
    );
    magnetHalo.rotation.x = -Math.PI / 2;
    magnetHalo.position.y = 0.32;
    carriageGroup.add(carriageBody, coilSpool, magnetHalo);

    // Layer 2: Hall-Effect 64-Sensor PCB Matrix (InstancedMesh)
    const pcbLayer = new THREE.Group();
    rootGroup.add(pcbLayer);

    const pcbBoard = new THREE.Mesh(
      new THREE.BoxGeometry(8.4, 0.08, 8.4),
      new THREE.MeshStandardMaterial({
        color: 0x06392f,
        roughness: 0.45,
        metalness: 0.25,
        transparent: true,
        opacity: 0.92,
      })
    );
    pcbBoard.position.y = -0.32;
    pcbLayer.add(pcbBoard);

    const sensorPinGeo = new THREE.BoxGeometry(0.26, 0.06, 0.26);
    const sensorPinMat = new THREE.MeshStandardMaterial({
      color: 0x00e5ff,
      emissive: 0x00e5ff,
      emissiveIntensity: 0.45,
      roughness: 0.25,
      metalness: 0.8,
    });
    const sensorInstanced = new THREE.InstancedMesh(sensorPinGeo, sensorPinMat, 64);
    const dummyMat4 = new THREE.Matrix4();
    let idx = 0;
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        dummyMat4.makeTranslation((c - 3.5) * 1.0, -0.25, (r - 3.5) * 1.0);
        sensorInstanced.setMatrixAt(idx++, dummyMat4);
      }
    }
    sensorInstanced.instanceMatrix.needsUpdate = true;
    sensorInstanced.computeBoundingSphere();
    pcbLayer.add(sensorInstanced);

    // Layer 3: Top Smart Chessboard Surface & Interactive 64 Squares
    const topBoardLayer = new THREE.Group();
    rootGroup.add(topBoardLayer);

    const outerFrame = new THREE.Mesh(
      new THREE.BoxGeometry(9.0, 0.22, 9.0),
      new THREE.MeshStandardMaterial({
        color: 0x162b44,
        roughness: 0.35,
        metalness: 0.5,
        transparent: true,
        opacity: 1,
      })
    );
    outerFrame.position.y = -0.08;
    topBoardLayer.add(outerFrame);

    const lightSquareMat = new THREE.MeshStandardMaterial({
      color: 0xdbe4ee,
      roughness: 0.25,
      metalness: 0.1,
      transparent: true,
      opacity: 1,
    });
    const darkSquareMat = new THREE.MeshStandardMaterial({
      color: 0x1e3a5f,
      roughness: 0.32,
      metalness: 0.2,
      transparent: true,
      opacity: 1,
    });

    const squareMeshes: THREE.Mesh[] = [];
    const squareMap = new Map<string, THREE.Mesh>();
    const squareGeo = new THREE.BoxGeometry(0.96, 0.08, 0.96);

    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const isLight = (r + c) % 2 === 0;
        const sqName = `${FILES[c]}${RANKS[r]}`;
        const mat = (isLight ? lightSquareMat : darkSquareMat).clone();
        const sqMesh = new THREE.Mesh(squareGeo, mat);
        sqMesh.position.set((c - 3.5) * 1.0, 0.04, (r - 3.5) * 1.0);
        sqMesh.receiveShadow = !isSoftwareGl;
        sqMesh.userData = { square: sqName, isLight };
        topBoardLayer.add(sqMesh);
        squareMeshes.push(sqMesh);
        squareMap.set(sqName, sqMesh);
      }
    }

    // 3D Composite Chess Pieces Layer
    const piecesGroup = new THREE.Group();
    topBoardLayer.add(piecesGroup);

    const whitePieceMat = new THREE.MeshStandardMaterial({
      color: 0xf8fafc,
      roughness: 0.2,
      metalness: 0.15,
    });
    const blackPieceMat = new THREE.MeshStandardMaterial({
      color: 0x0f172a,
      roughness: 0.22,
      metalness: 0.55,
    });

    const buildPieceMesh = (type: Piece['type'], color: Color): THREE.Group => {
      const g = new THREE.Group();
      const mainMat = color === 'w' ? whitePieceMat : blackPieceMat;
      const accentMat = color === 'w' ? goldTrimMat : cyanEmissiveMat;

      // Part 1: Pedestal Base
      const base = new THREE.Mesh(
        new THREE.CylinderGeometry(0.34, 0.38, 0.12, 18),
        mainMat
      );
      base.position.y = 0.06;
      g.add(base);

      // Part 2: Accent Collar Ring
      const ring = new THREE.Mesh(
        new THREE.CylinderGeometry(0.3, 0.32, 0.05, 18),
        accentMat
      );
      ring.position.y = 0.14;
      g.add(ring);

      // Part 3: Upper Silhouette by Piece Type
      const heights: Record<Piece['type'], number> = {
        p: 0.42,
        r: 0.54,
        n: 0.6,
        b: 0.66,
        q: 0.78,
        k: 0.88,
      };
      const h = heights[type];
      const stem = new THREE.Mesh(
        new THREE.CylinderGeometry(0.16, 0.26, h, 16),
        mainMat
      );
      stem.position.y = 0.16 + h / 2;
      g.add(stem);

      // Part 4: Finial / Crown
      if (type === 'k' || type === 'q') {
        const crown = new THREE.Mesh(
          new THREE.ConeGeometry(0.24, 0.22, 8),
          accentMat
        );
        crown.position.y = 0.16 + h + 0.08;
        g.add(crown);
      } else if (type === 'n') {
        const head = new THREE.Mesh(
          new THREE.BoxGeometry(0.26, 0.28, 0.38),
          mainMat
        );
        head.position.set(0, 0.16 + h + 0.04, 0.05);
        head.rotation.x = -0.25;
        g.add(head);
      } else {
        const orb = new THREE.Mesh(
          new THREE.SphereGeometry(0.18, 16, 12),
          type === 'b' ? accentMat : mainMat
        );
        orb.position.y = 0.16 + h + 0.05;
        g.add(orb);
      }

      return g;
    };

    const syncPieces = () => {
      while (piecesGroup.children.length > 0) {
        piecesGroup.remove(piecesGroup.children[0]);
      }
      const { board: curBoard, selectedSquare: selSq, legalTargetSquares: targets, lastMove: lm } =
        propsRef.current;

      for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
          const sqName = `${FILES[c]}${RANKS[r]}`;
          const sqMesh = squareMap.get(sqName);
          if (sqMesh) {
            const mat = sqMesh.material as THREE.MeshStandardMaterial;
            const isLight = sqMesh.userData.isLight;
            if (sqName === selSq) {
              mat.color.setHex(0x00e5ff);
              mat.emissive.setHex(0x004455);
            } else if (targets.includes(sqName)) {
              mat.color.setHex(0x10b981);
              mat.emissive.setHex(0x053322);
            } else if (lm && (lm.from === sqName || lm.to === sqName)) {
              mat.color.setHex(0xffd700);
              mat.emissive.setHex(0x332800);
            } else {
              mat.color.setHex(isLight ? 0xdbe4ee : 0x1e3a5f);
              mat.emissive.setHex(0x000000);
            }
          }

          const piece = curBoard[r][c];
          if (piece) {
            const meshGroup = buildPieceMesh(piece.type, piece.color);
            meshGroup.position.set((c - 3.5) * 1.0, 0.08, (r - 3.5) * 1.0);
            piecesGroup.add(meshGroup);
          }
        }
      }
    };

    syncPieces();

    // Raycasting on board squares
    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();
    let pointerDownPos = { x: 0, y: 0 };

    const onPointerDown = (e: PointerEvent) => {
      pointerDownPos = { x: e.clientX, y: e.clientY };
    };

    const onPointerUp = (e: PointerEvent) => {
      const dx = Math.abs(e.clientX - pointerDownPos.x);
      const dy = Math.abs(e.clientY - pointerDownPos.y);
      if (dx > 6 || dy > 6) return; // Ignore camera orbit drags

      const rect = renderer.domElement.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointer.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(squareMeshes, false);
      if (hits.length > 0) {
        const sq = hits[0].object.userData.square;
        if (sq) propsRef.current.onSquareClick(sq);
      }
    };

    renderer.domElement.addEventListener('pointerdown', onPointerDown);
    renderer.domElement.addEventListener('pointerup', onPointerUp);

    // ResizeObserver for perfect mobile & desktop responsiveness
    const resizeObserver = new ResizeObserver(() => {
      if (!container) return;
      const w = container.clientWidth || 320;
      const h = container.clientHeight || 320;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    });
    resizeObserver.observe(container);

    // Pre-allocated animation variables (Zero GC in render loop)
    let frameId = 0;
    let lastTime = performance.now();
    let explodedCurrent = 0;
    let gantryTargetX = 0;
    let gantryTargetZ = 0;
    let lastBoardJson = '';

    function afterDraw(cb: () => void) {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
      gl.flush();
      const poll = () => {
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    function tick() {
      const now = performance.now();
      const dt = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;

      const cur = propsRef.current;
      const boardKey = JSON.stringify({
        b: cur.board,
        s: cur.selectedSquare,
        t: cur.legalTargetSquares,
        l: cur.lastMove,
      });
      if (boardKey !== lastBoardJson) {
        lastBoardJson = boardKey;
        syncPieces();
      }

      // Smoothly damp Exploded "Inside View" separation
      const targetExplode = cur.insideView || cur.sensorOverlay ? 1.0 : 0.0;
      explodedCurrent = THREE.MathUtils.damp(explodedCurrent, targetExplode, 5.5, dt);

      topBoardLayer.position.y = explodedCurrent * 1.45;
      pcbLayer.position.y = explodedCurrent * 0.45;
      gantryLayer.position.y = -explodedCurrent * 0.25;
      baseLayer.position.y = -explodedCurrent * 0.75;

      // Make top board semi-translucent in Inside View so sensors & gantry shine through
      const boardOpacity = THREE.MathUtils.lerp(1.0, 0.42, explodedCurrent);
      outerFrame.material.opacity = boardOpacity;
      for (const sqMesh of squareMeshes) {
        (sqMesh.material as THREE.MeshStandardMaterial).opacity = boardOpacity;
      }

      // Move Electromagnet Gantry toward last move square or orbit smoothly in Auto Demo
      if (cur.lastMove) {
        const [tr, tc] = squareToCoords(cur.lastMove.to);
        gantryTargetX = (tc - 3.5) * 1.0;
        gantryTargetZ = (tr - 3.5) * 1.0;
      } else {
        gantryTargetX = Math.sin(now * 0.0012) * 2.5;
        gantryTargetZ = Math.cos(now * 0.0009) * 2.5;
      }

      xBridgeGroup.position.z = THREE.MathUtils.damp(
        xBridgeGroup.position.z,
        gantryTargetZ,
        6.0,
        dt
      );
      carriageGroup.position.x = THREE.MathUtils.damp(
        carriageGroup.position.x,
        gantryTargetX,
        6.0,
        dt
      );

      if (!isSoftwareGl) {
        controls.update();
      }

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }
    tick();

    return () => {
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      resizeObserver.disconnect();
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);
      renderer.domElement.removeEventListener('pointerup', onPointerUp);
      controls.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={mountRef}
      data-testid="smart-board-3d-canvas"
      className="w-full h-full min-h-[300px] sm:min-h-[420px] rounded-xl overflow-hidden bg-[#07111E]"
    />
  );
};
