import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  rotation: number;
  vRot: number;
  life: number;
  maxLife: number;
  shape: 'rect' | 'star' | 'ring';
}

interface CheckmateSpectacleProps {
  active: boolean;
  isPuzzleRush: boolean;
  winner: 'player' | 'ai' | null;
  movesCount: number;
  puzzlesSolved: number;
  winningMoveSan: string;
  onPlayAgain: () => void;
  onNextPuzzle?: () => void;
  onDismissBanner?: () => void;
  onClaimCertificate?: () => void;
}

const POOL_SIZE = 110;
const COLORS = ['#FFD700', '#00E5FF', '#10B981', '#F8FAFC', '#FF3B5C'];

export const CheckmateSpectacle: React.FC<CheckmateSpectacleProps> = ({
  active,
  isPuzzleRush,
  winner,
  movesCount,
  puzzlesSolved,
  winningMoveSan,
  onPlayAgain,
  onNextPuzzle,
  onDismissBanner,
  onClaimCertificate,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!active) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    // Pre-allocated pooled particle buffer (Zero GC during animation loop)
    const pool: Particle[] = Array.from({ length: POOL_SIZE }, (_, i) => {
      const angle = (Math.PI * 2 * i) / POOL_SIZE + (Math.random() - 0.5) * 0.3;
      const speed = 180 + Math.random() * 520;
      return {
        x: canvas.width * 0.5,
        y: canvas.height * 0.42,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 180,
        size: 6 + Math.random() * 8,
        color: COLORS[i % COLORS.length],
        rotation: Math.random() * Math.PI * 2,
        vRot: (Math.random() - 0.5) * 8,
        life: 0,
        maxLife: 1.8 + Math.random() * 1.4,
        shape: i % 5 === 0 ? 'star' : i % 7 === 0 ? 'ring' : 'rect',
      };
    });

    let lastTime = performance.now();
    let rafId = 0;

    const tick = (now: number) => {
      const rawDt = (now - lastTime) / 1000;
      const dt = Math.min(rawDt, 0.05);
      lastTime = now;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      let anyAlive = false;
      for (let i = 0; i < POOL_SIZE; i++) {
        const p = pool[i];
        p.life += dt;
        if (p.life < p.maxLife) {
          anyAlive = true;
          p.x += p.vx * dt;
          p.y += p.vy * dt;
          p.vy += 420 * dt; // gravity
          p.vx *= 0.99;
          p.rotation += p.vRot * dt;

          const alpha = Math.max(0, 1 - p.life / p.maxLife);
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);
          ctx.globalAlpha = alpha;
          ctx.fillStyle = p.color;
          ctx.strokeStyle = p.color;

          if (p.shape === 'rect') {
            ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size * 0.6);
          } else if (p.shape === 'ring') {
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.arc(0, 0, p.size * 0.7, 0, Math.PI * 2);
            ctx.stroke();
          } else {
            ctx.beginPath();
            for (let s = 0; s < 5; s++) {
              const a = (s * Math.PI * 2) / 5 - Math.PI / 2;
              const r = p.size;
              if (s === 0) ctx.moveTo(Math.cos(a) * r, Math.sin(a) * r);
              else ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
            }
            ctx.closePath();
            ctx.fill();
          }
          ctx.restore();
        }
      }

      if (anyAlive) {
        rafId = requestAnimationFrame(tick);
      }
    };

    rafId = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('resize', resize);
    };
  }, [active]);

  if (!active) return null;

  const eloEstimate = Math.min(2850, 1850 + puzzlesSolved * 120 + Math.max(0, 30 - movesCount) * 18);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none"
      role="dialog"
      aria-modal="true"
      aria-label="Checkmate Celebration"
    >
      {/* 60fps Pooled Confetti & Supernova Canvas */}
      <canvas
        ref={canvasRef}
        className="fixed inset-0 pointer-events-none z-0"
      />

      {/* Focused Outcome Modal Card */}
      <div className="relative z-10 pointer-events-auto max-w-md w-full rounded-2xl bg-[#07111E] border-2 border-[#FFD700] p-6 sm:p-8 text-center shadow-[0_0_60px_rgba(255,215,0,0.35)]">
        {/* Expanding Shockwave Halo */}
        <div className="w-20 h-20 mx-auto mb-4 relative flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-[#FFD700] animate-shockwave" />
          <svg viewBox="0 0 80 80" className="w-20 h-20">
            <polygon
              points="40,4 50,26 74,28 56,44 61,68 40,56 19,68 24,44 6,28 30,26"
              fill="#FFD700"
              stroke="#00E5FF"
              strokeWidth="2.5"
            />
            <path
              d="M26,48 L54,48 L50,32 L40,40 L30,32 Z"
              fill="#0A1929"
            />
          </svg>
        </div>

        <div className="text-xs font-mono uppercase tracking-widest text-[#00E5FF] mb-1">
          {isPuzzleRush
            ? 'PUZZLE RUSH · TACTICAL STRIKE'
            : winner === 'player'
              ? 'SUPERNOVA CHECKMATE FINALE'
              : 'STOCKFISH ENGINE VICTORY'}
        </div>

        <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-[#FFD700] tracking-tight mb-2">
          {isPuzzleRush || winner === 'player' ? '5-Star Jeeto!' : 'Checkmate!'}
        </h2>

        <p className="text-sm text-slate-300 mb-6">
          {isPuzzleRush
            ? `Brilliant execution with ${winningMoveSan || 'Mate in 1'}! Loading next tactical challenge...`
            : winner === 'player'
              ? `Incredible! You shattered the AI defense with ${winningMoveSan || 'Checkmate'} in front of the STEM crowd!`
              : 'The AI found a forced checkmate net. Analyze the move log and strike back!'}
        </p>

        {/* Mastery Metrics (tabular-nums) */}
        <div className="grid grid-cols-3 gap-3 mb-6 bg-[#102338] p-3.5 rounded-xl border border-[#00E5FF]/25">
          <div>
            <div className="text-[11px] font-mono uppercase text-slate-400">FINAL MOVE</div>
            <div className="text-lg font-bold font-mono text-[#00E5FF] tabular-nums">
              {winningMoveSan || 'Mate#'}
            </div>
          </div>
          <div>
            <div className="text-[11px] font-mono uppercase text-slate-400">
              {isPuzzleRush ? 'STREAK' : 'MOVES'}
            </div>
            <div className="text-lg font-bold font-mono text-[#FFD700] tabular-nums">
              {isPuzzleRush ? `${puzzlesSolved} ★` : movesCount}
            </div>
          </div>
          <div>
            <div className="text-[11px] font-mono uppercase text-slate-400">PERF ELO</div>
            <div className="text-lg font-bold font-mono text-emerald-400 tabular-nums">
              {winner === 'player' || isPuzzleRush ? eloEstimate : 1420}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-2.5">
          {isPuzzleRush && onNextPuzzle ? (
            <button
              type="button"
              data-start="true"
              onClick={onNextPuzzle}
              className="px-4 py-2.5 rounded-lg bg-[#FFD700] text-[#0A1929] font-bold text-xs sm:text-sm hover:bg-[#ffe033] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Next Puzzle Now
            </button>
          ) : (
            <button
              type="button"
              data-start="true"
              onClick={onPlayAgain}
              className="px-4 py-2.5 rounded-lg bg-[#00E5FF] text-[#0A1929] font-bold text-xs sm:text-sm hover:bg-[#33ecff] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Play Again
            </button>
          )}
          {onClaimCertificate && (
            <button
              type="button"
              onClick={onClaimCertificate}
              className="px-4 py-2.5 rounded-lg bg-[#00a3ff]/20 text-[#00a3ff] font-bold text-xs sm:text-sm hover:bg-[#00a3ff]/30 border border-[#00a3ff] transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              🏆 Claim Certificate
            </button>
          )}
          {onDismissBanner && (
            <button
              type="button"
              onClick={onDismissBanner}
              className="px-3.5 py-2.5 rounded-lg bg-[#132A42] text-slate-200 font-medium text-xs sm:text-sm hover:bg-[#1c3b5c] border border-slate-700 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              Inspect Board
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
