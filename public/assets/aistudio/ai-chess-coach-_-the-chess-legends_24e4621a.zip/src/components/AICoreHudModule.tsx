import React, { useEffect, useState } from 'react';

const AI_CORE_STATES = [
  'Depth: 18...',
  'Nodes: 1.4M...',
  'Eval: +0.45...',
  'Thinking...',
];

interface AICoreHudModuleProps {
  liveDepth?: number;
  liveNodesFormatted?: string;
  liveEvalFormatted?: string;
}

export const AICoreHudModule: React.FC<AICoreHudModuleProps> = () => {
  const [cycleIndex, setCycleIndex] = useState(0);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setCycleIndex((prev) => (prev + 1) % AI_CORE_STATES.length);
    }, 2000);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <div
      data-testid="ai-core-hud"
      className="inline-flex items-center gap-3 px-3.5 py-2 rounded-xl bg-[#07111E]/90 border border-[#00E5FF]/45 shadow-[0_0_24px_rgba(0,229,255,0.22)]"
    >
      {/* Pure CSS Futuristic AI Core Orb */}
      <div
        className="relative w-6 h-6 rounded-full flex items-center justify-center shrink-0"
        style={{
          background:
            'radial-gradient(circle at 35% 35%, #FFFFFF 0%, #00E5FF 45%, #0A1929 100%)',
          boxShadow: '0 0 14px #00E5FF, inset 0 0 6px #FFD700',
        }}
        aria-hidden="true"
      >
        <div className="w-2.5 h-2.5 rounded-full bg-[#FFD700]/90" />
      </div>

      {/* Cycling Telemetry Readout */}
      <div className="flex flex-col text-left">
        <span className="text-[9px] font-mono uppercase tracking-widest text-[#FFD700] leading-none">
          AI CORE MODULE
        </span>
        <span
          data-testid="ai-core-cycling-text"
          className="text-xs sm:text-sm font-mono font-bold text-[#00E5FF] tabular-nums whitespace-nowrap mt-0.5"
        >
          {AI_CORE_STATES[cycleIndex]}
        </span>
      </div>
    </div>
  );
};
