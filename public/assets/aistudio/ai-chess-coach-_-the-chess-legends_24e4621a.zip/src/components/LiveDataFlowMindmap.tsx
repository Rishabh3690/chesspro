import React from 'react';

export interface FlowStep {
  id: number;
  title: string;
  sub: string;
  metric: string;
}

export const DATA_FLOW_STEPS: FlowStep[] = [
  {
    id: 0,
    title: '1. Hall-Effect Sensor Matrix',
    sub: '64x Bipolar Magnetic Sensors',
    metric: 'SCAN: 200Hz',
  },
  {
    id: 1,
    title: '2. ESP32 I2C Multiplexer',
    sub: '8x8 Bitboard Delta Packet',
    metric: 'LATENCY: 1.8ms',
  },
  {
    id: 2,
    title: '3. Stockfish 16 Neural Core',
    sub: 'Alpha-Beta + NNUE Evaluation',
    metric: 'DEPTH: 18 PLY',
  },
  {
    id: 3,
    title: '4. CoreXY Stepper Gantry',
    sub: 'Dual-Belt Electromagnet Coil',
    metric: 'TORQUE: 42N·cm',
  },
  {
    id: 4,
    title: '5. Hinglish Voice & LED Ring',
    sub: 'Web Speech + Square Telemetry',
    metric: 'AUDIO: ACTIVE',
  },
];

interface LiveDataFlowMindmapProps {
  activeStage: number;
  mobileOpen: boolean;
  onToggleMobile: () => void;
  onSelectStage: (stage: number) => void;
}

export const LiveDataFlowMindmap: React.FC<LiveDataFlowMindmapProps> = ({
  activeStage,
  mobileOpen,
  onToggleMobile,
  onSelectStage,
}) => {
  const renderMindmapContent = () => (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between border-b border-[#00E5FF]/20 pb-2 mb-1">
        <div>
          <h3 className="text-xs font-display font-bold uppercase tracking-wider text-[#00E5FF]">
            Live Data Flow Mindmap
          </h3>
          <p className="text-[11px] text-slate-400">
            Smart Board Hardware-to-AI Pipeline
          </p>
        </div>
        {mobileOpen && (
          <button
            type="button"
            onClick={onToggleMobile}
            aria-label="Close Live Data Flow Overlay"
            className="md:hidden px-2.5 py-1 rounded bg-[#132A42] text-slate-200 hover:text-white text-xs font-mono cursor-pointer"
          >
            Close
          </button>
        )}
      </div>

      <div className="flex flex-col gap-1.5">
        {DATA_FLOW_STEPS.map((step, idx) => {
          const isCurrent = activeStage === idx;
          return (
            <React.Fragment key={step.id}>
              <button
                type="button"
                onClick={() => onSelectStage(idx)}
                className={`w-full text-left p-2.5 rounded-lg border transition-colors cursor-pointer ${
                  isCurrent
                    ? 'bg-[#132A42] border-[#00E5FF] shadow-[0_0_15px_rgba(0,229,255,0.2)]'
                    : 'bg-[#091523]/90 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span
                    className={`text-xs font-semibold ${
                      isCurrent ? 'text-[#FFD700]' : 'text-slate-200'
                    }`}
                  >
                    {step.title}
                  </span>
                  <span className="text-[10px] font-mono text-[#00E5FF] tabular-nums shrink-0">
                    {step.metric}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  {step.sub}
                </div>
              </button>

              {idx < DATA_FLOW_STEPS.length - 1 && (
                <div className="flex justify-center">
                  <svg
                    viewBox="0 0 16 14"
                    className="w-3.5 h-3 text-[#00E5FF]/60"
                    aria-hidden="true"
                  >
                    <path
                      d="M8,0 L8,10 M4,7 L8,12 L12,7"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.8"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Left Panel: Hidden by default on screens < 768px (hidden md:block) */}
      <aside
        data-testid="desktop-data-flow-mindmap"
        className="hidden md:block w-full rounded-xl bg-[#0D1E31]/95 border border-[#00E5FF]/25 p-3.5 shadow-lg"
      >
        {renderMindmapContent()}
      </aside>

      {/* Mobile Floating Bottom-Left Toggle Button (< 768px only) */}
      <button
        type="button"
        data-testid="mobile-show-flow-btn"
        onClick={onToggleMobile}
        className="md:hidden fixed bottom-4 left-4 z-40 px-3.5 py-2.5 rounded-xl bg-[#0D2137] text-[#00E5FF] border border-[#00E5FF] font-display font-bold text-xs shadow-[0_8px_24px_rgba(0,0,0,0.75)] flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer"
      >
        <span>⚡ Show Flow</span>
      </button>

      {/* Mobile Overlay Drawer when "⚡ Show Flow" is clicked */}
      {mobileOpen && (
        <div
          data-testid="mobile-data-flow-overlay"
          className="md:hidden fixed inset-0 z-50 bg-black/80 flex items-end sm:items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Live Data Flow Mindmap"
        >
          <div className="w-full max-w-sm rounded-2xl bg-[#0D1E31] border border-[#00E5FF]/50 p-4 shadow-2xl">
            {renderMindmapContent()}
          </div>
        </div>
      )}
    </>
  );
};
