import React, { useMemo } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ReferenceLine,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import {
  EvalTimelinePoint,
  Move,
  buildEvalTimelineData,
} from '../game/chessEngine';

interface EvalTimelineChartProps {
  history: Move[];
}

function getBarColor(point: EvalTimelinePoint): string {
  if (point.quality === 'Blunder') return '#FF3B5C';
  if (point.quality === 'Mistake') return '#F59E0B';
  if (point.quality === 'Excellent') return '#10B981';
  return point.clampedEval >= 0 ? '#00E5FF' : '#FFD700';
}

export const EvalTimelineChart: React.FC<EvalTimelineChartProps> = ({
  history,
}) => {
  const timelineData = useMemo<EvalTimelinePoint[]>(() => {
    const built = buildEvalTimelineData(history);
    if (built.length > 0) return built;
    return [
      {
        ply: 0,
        moveNumber: 0,
        moveLabel: 'Start',
        san: 'Start',
        color: 'w',
        evalScore: 0,
        clampedEval: 0,
        evalDelta: 0,
        quality: 'Good',
      },
    ];
  }, [history]);

  const latestPoint = timelineData[timelineData.length - 1];
  const latestEval = latestPoint ? latestPoint.evalScore : 0;
  const momentumLabel =
    latestEval > 0.25
      ? `White Lead (+${latestEval.toFixed(2)})`
      : latestEval < -0.25
        ? `AI Lead (${latestEval.toFixed(2)})`
        : 'Balanced (0.00)';

  return (
    <div
      data-testid="eval-timeline-chart"
      className="pt-2.5 border-t border-slate-800/90 flex flex-col gap-1.5"
    >
      <div className="flex items-center justify-between gap-2">
        <span className="text-[10px] font-mono uppercase tracking-wider text-[#00E5FF]">
          Momentum &amp; Eval Timeline
        </span>
        <span
          data-testid="momentum-shift-status"
          className={`text-[10px] font-mono font-bold tabular-nums ${
            latestEval > 0.25
              ? 'text-emerald-300'
              : latestEval < -0.25
                ? 'text-[#FF3B5C]'
                : 'text-slate-300'
          }`}
        >
          {momentumLabel}
        </span>
      </div>

      <div className="w-full h-28 bg-[#050C15] rounded-lg border border-slate-800/80 px-1.5 py-1">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={timelineData}
            margin={{ top: 6, right: 6, left: -24, bottom: 2 }}
          >
            <XAxis
              dataKey="san"
              tick={{ fill: '#94A3B8', fontSize: 9, fontFamily: 'monospace' }}
              axisLine={{ stroke: '#1E293B' }}
              tickLine={false}
              interval="preserveStartEnd"
            />
            <YAxis
              domain={['auto', 'auto']}
              tick={{ fill: '#64748B', fontSize: 9, fontFamily: 'monospace' }}
              axisLine={false}
              tickLine={false}
              tickCount={3}
            />
            <ReferenceLine
              y={0}
              stroke="#00E5FF"
              strokeOpacity={0.45}
              strokeDasharray="3 3"
            />
            <Tooltip
              cursor={{ fill: 'rgba(0, 229, 255, 0.08)' }}
              content={({ active, payload }) => {
                if (!active || !payload || !payload.length) return null;
                const pt = payload[0].payload as EvalTimelinePoint;
                const evalFormatted =
                  pt.evalScore >= 0
                    ? `+${pt.evalScore.toFixed(2)}`
                    : pt.evalScore.toFixed(2);
                const deltaFormatted =
                  pt.evalDelta >= 0
                    ? `+${pt.evalDelta.toFixed(2)}`
                    : pt.evalDelta.toFixed(2);
                return (
                  <div className="rounded-lg bg-[#0A1929] border border-[#00E5FF]/50 px-2.5 py-1.5 shadow-xl text-[11px] font-mono text-slate-100 space-y-0.5">
                    <div className="font-bold text-[#FFD700]">
                      {pt.moveLabel} ({pt.quality})
                    </div>
                    <div>
                      Score:{' '}
                      <span className="text-[#00E5FF] font-bold">
                        {evalFormatted}
                      </span>{' '}
                      | Δ: <span>{deltaFormatted}</span>
                    </div>
                  </div>
                );
              }}
            />
            <Bar
              dataKey="clampedEval"
              radius={[3, 3, 3, 3]}
              maxBarSize={22}
              isAnimationActive={false}
            >
              {timelineData.map((entry) => (
                <Cell
                  key={`eval-bar-${entry.ply}-${entry.san}`}
                  fill={getBarColor(entry)}
                />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Compact color key */}
      <div className="flex items-center justify-between text-[9px] font-mono text-slate-400 px-0.5">
        <span>+ White Advantage</span>
        <span className="flex items-center gap-2">
          <span className="text-emerald-400">■ Excellent</span>
          <span className="text-amber-400">■ Mistake</span>
          <span className="text-[#FF3B5C]">■ Blunder</span>
        </span>
        <span>- AI Advantage</span>
      </div>
    </div>
  );
};
