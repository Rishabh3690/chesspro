import React from 'react';
import { AvatarMood, PersonalityId } from '../game/personalities';

interface AIAvatarSvgProps {
  personality: PersonalityId;
  mood: AvatarMood;
  isThinking: boolean;
  isSpeaking: boolean;
}

export const AIAvatarSvg: React.FC<AIAvatarSvgProps> = ({
  personality,
  mood,
  isThinking,
  isSpeaking,
}) => {
  // Cyan (#00E5FF) for Normal, Red (#FF3B5C) for Evil/Roast, Green (#10B981) for Happy
  const moodColor =
    mood === 'evil' ? '#FF3B5C' : mood === 'happy' ? '#10B981' : '#00E5FF';

  const isRobotRoasting = personality === 'robot' && mood === 'evil';

  const moodLabel =
    personality === 'cat'
      ? 'LAZY STRETCH · CASUAL'
      : isRobotRoasting
        ? 'ROAST LED BLINK · SAVAGE'
        : personality === 'dragon'
          ? 'REGAL AURA · DOMINANT'
          : mood === 'evil'
            ? 'ROAST MODE · AGGRESSIVE'
            : mood === 'happy'
              ? 'IMPRESSED · PRAISE'
              : isThinking
                ? 'CALCULATING LINES'
                : 'NEURAL SENTRY';

  // Personality-specific wrapper animation class
  const personalityAnimClass =
    personality === 'cat'
      ? 'animate-cat-stretch'
      : personality === 'dragon'
        ? 'animate-dragon-regal-glow'
        : 'animate-float-slow';

  return (
    <div className="relative flex flex-col items-center">
      <div
        data-testid={`ai-avatar-container-${personality}`}
        className={`relative w-28 h-28 sm:w-32 sm:h-32 rounded-2xl bg-[#07111E] border flex items-center justify-center transition-colors duration-200 ${personalityAnimClass}`}
        style={{
          borderColor: personality === 'dragon' ? '#FFD700' : moodColor,
          boxShadow:
            personality === 'dragon'
              ? '0 0 28px -2px rgba(255, 215, 0, 0.5), inset 0 0 20px rgba(255, 59, 92, 0.25)'
              : `0 0 26px -4px ${moodColor}55, inset 0 0 18px ${moodColor}22`,
        }}
      >
        <svg
          viewBox="0 0 120 120"
          className="w-24 h-24 sm:w-28 sm:h-28"
          role="img"
          aria-label={`${personality} AI Avatar in ${mood} state`}
        >
          {/* Outer HUD hexagonal frame */}
          <polygon
            points="60,6 108,30 108,90 60,114 12,90 12,30"
            fill="#0A1929"
            stroke={personality === 'dragon' ? '#FFD700' : moodColor}
            strokeWidth="2.5"
            opacity="0.92"
          />

          {/* Personality-specific Ears / Horns / Antenna */}
          {personality === 'cat' && (
            <g stroke={moodColor} strokeWidth="2.5" fill="#102338">
              <polygon points="22,38 16,12 42,26" />
              <polygon points="98,38 104,12 78,26" />
              <polygon points="25,34 21,18 37,27" fill={moodColor} opacity="0.35" stroke="none" />
              <polygon points="95,34 99,18 83,27" fill={moodColor} opacity="0.35" stroke="none" />
            </g>
          )}

          {personality === 'robot' && (
            <g stroke={moodColor} strokeWidth="2.5" fill="#102338">
              <line x1="60" y1="6" x2="60" y2="20" strokeWidth="3" />
              <circle
                cx="60"
                cy="6"
                r="4.5"
                fill={isRobotRoasting ? '#FF3B5C' : '#FFD700'}
                className={isRobotRoasting ? 'animate-robot-roast-eyes' : ''}
              />
              <rect x="8" y="48" width="8" height="24" rx="3" fill={moodColor} />
              <rect x="104" y="48" width="8" height="24" rx="3" fill={moodColor} />
            </g>
          )}

          {personality === 'dragon' && (
            <g stroke="#FFD700" strokeWidth="2.5" fill="#132A42">
              <path d="M 28,32 Q 10,8 22,4 Q 34,14 42,26 Z" fill="#FFD700" opacity="0.9" />
              <path d="M 92,32 Q 110,8 98,4 Q 86,14 78,26 Z" fill="#FFD700" opacity="0.9" />
              <polygon points="60,9 68,24 52,24" fill="#FF3B5C" stroke="#FFD700" strokeWidth="1.5" />
            </g>
          )}

          {/* Visor / Eye Region */}
          <rect
            x="24"
            y="40"
            width="72"
            height="28"
            rx="8"
            fill="#050C14"
            stroke={personality === 'dragon' ? '#FFD700' : moodColor}
            strokeWidth="1.8"
          />

          {/* Eyes based on personality & mood (Sarcastic Robot blinks red lights on roast!) */}
          {isRobotRoasting ? (
            <g
              data-testid="robot-blinking-red-eyes"
              className="animate-robot-roast-eyes"
              fill="#FF3B5C"
              stroke="#FFD700"
              strokeWidth="1.2"
            >
              <circle cx="43" cy="54" r="7.5" />
              <circle cx="77" cy="54" r="7.5" />
              <circle cx="43" cy="54" r="3" fill="#FFFFFF" stroke="none" />
              <circle cx="77" cy="54" r="3" fill="#FFFFFF" stroke="none" />
            </g>
          ) : mood === 'normal' ? (
            <g fill={moodColor} className={isThinking ? 'animate-visor' : ''}>
              <circle cx="43" cy="54" r="6.5" />
              <circle cx="77" cy="54" r="6.5" />
              <circle cx="41" cy="52" r="2" fill="#FFFFFF" />
              <circle cx="75" cy="52" r="2" fill="#FFFFFF" />
            </g>
          ) : mood === 'evil' ? (
            <g fill={moodColor} stroke={moodColor} strokeWidth="2">
              <polygon points="33,48 52,54 35,59" />
              <polygon points="87,48 68,54 85,59" />
            </g>
          ) : (
            <g fill="none" stroke={moodColor} strokeWidth="3.5" strokeLinecap="round">
              <path d="M 34,57 Q 43,46 52,57" />
              <path d="M 68,57 Q 77,46 86,57" />
            </g>
          )}

          {/* Cat Whiskers if Noob Cat */}
          {personality === 'cat' && (
            <g stroke={moodColor} strokeWidth="1.6" strokeLinecap="round" opacity="0.75">
              <line x1="14" y1="68" x2="28" y2="70" />
              <line x1="12" y1="75" x2="28" y2="75" />
              <line x1="106" y1="68" x2="92" y2="70" />
              <line x1="108" y1="75" x2="92" y2="75" />
              <polygon points="60,72 56,67 64,67" fill="#FFD700" stroke="none" />
            </g>
          )}

          {/* Mouth / Vocal Synthesizer */}
          {isSpeaking ? (
            <g fill={moodColor}>
              <rect x="38" y="80" width="5" height="14" rx="2" />
              <rect x="47" y="76" width="5" height="22" rx="2" fill="#FFD700" />
              <rect x="57" y="74" width="6" height="26" rx="2" />
              <rect x="68" y="76" width="5" height="22" rx="2" fill="#FFD700" />
              <rect x="77" y="80" width="5" height="14" rx="2" />
            </g>
          ) : mood === 'happy' ? (
            <path
              d="M 42,82 Q 60,96 78,82"
              fill="none"
              stroke={moodColor}
              strokeWidth="3.2"
              strokeLinecap="round"
            />
          ) : mood === 'evil' ? (
            <path
              d="M 42,89 L 51,83 L 60,89 L 69,83 L 78,89"
              fill="none"
              stroke={moodColor}
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          ) : (
            <g stroke={moodColor} strokeWidth="2.4" strokeLinecap="round">
              <line x1="42" y1="86" x2="78" y2="86" />
              <line x1="48" y1="82" x2="48" y2="90" />
              <line x1="60" y1="81" x2="60" y2="91" />
              <line x1="72" y1="82" x2="72" y2="90" />
            </g>
          )}
        </svg>
      </div>

      {/* Non-hue-only state readout below avatar */}
      <div className="mt-2 text-[11px] font-mono tracking-wider uppercase text-slate-300 flex items-center gap-1.5">
        <span style={{ color: personality === 'dragon' ? '#FFD700' : moodColor }}>
          {moodLabel}
        </span>
      </div>
    </div>
  );
};
