import React from 'react';
import {
  FastestSolverEntry,
  StreakLeaderboardEntry,
} from '../game/chessEngine';

interface PuzzleRushLeaderboardProps {
  topStreaks: StreakLeaderboardEntry[];
  fastestSolvers: FastestSolverEntry[];
  challengerName: string;
  onChallengerNameChange: (name: string) => void;
  onClaimCertificate: () => void;
}

export const PuzzleRushLeaderboard: React.FC<PuzzleRushLeaderboardProps> = ({
  topStreaks,
  fastestSolvers,
  challengerName,
  onChallengerNameChange,
  onClaimCertificate,
}) => {
  return (
    <div
      data-testid="puzzle-rush-leaderboards-panel"
      className="rounded-xl bg-[#09090b]/95 border border-[#00a3ff]/50 p-3 shadow-[0_0_24px_rgba(0,163,255,0.18)] space-y-2.5"
    >
      {/* Top Row: Challenger Name Input + Claim Certificate Button */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-zinc-800">
        <div className="flex items-center gap-2 flex-1 min-w-[180px]">
          <label
            htmlFor="puzzle-challenger-name"
            className="text-[10px] font-mono uppercase tracking-wider text-[#00a3ff] whitespace-nowrap"
          >
            Challenger:
          </label>
          <input
            id="puzzle-challenger-name"
            data-testid="challenger-name-input"
            type="text"
            value={challengerName}
            onChange={(e) => onChallengerNameChange(e.target.value)}
            placeholder="Enter name (e.g. Player)"
            className="w-full max-w-[180px] rounded-lg bg-[#18181b] border border-[#00a3ff]/40 px-2.5 py-1 text-xs font-mono text-white focus:outline-none focus:border-[#00a3ff]"
          />
        </div>

        <button
          type="button"
          data-testid="puzzle-claim-certificate-btn"
          onClick={onClaimCertificate}
          className="px-2.5 py-1 rounded-lg bg-[#00a3ff]/20 hover:bg-[#00a3ff]/30 text-[#00a3ff] border border-[#00a3ff]/50 text-xs font-display font-bold whitespace-nowrap cursor-pointer"
        >
          🏆 Claim Certificate
        </button>
      </div>

      {/* Dual Leaderboard Grid: Top 5 Streaks & Top 3 Fastest Solvers */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {/* 1. Top 5 Streaks (Local Storage) */}
        <div
          data-testid="top-5-streaks-leaderboard"
          className="rounded-lg bg-[#18181b]/90 border border-zinc-800 p-2.5 flex flex-col gap-1.5"
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono uppercase tracking-wider font-bold text-[#FFD700]">
              🔥 Top 5 Streaks (Exhibition)
            </span>
            <span className="text-[9px] font-mono text-zinc-400">
              localStorage
            </span>
          </div>
          <div className="space-y-1">
            {topStreaks.slice(0, 5).map((entry, idx) => (
              <div
                key={entry.id}
                data-testid={`top-streak-row-${idx + 1}`}
                className="flex items-center justify-between text-xs font-mono px-2 py-1 rounded bg-[#09090b] border border-zinc-800/80"
              >
                <div className="flex items-center gap-1.5 min-w-0">
                  <span
                    className={`w-4 text-[10px] font-bold ${
                      idx === 0
                        ? 'text-[#FFD700]'
                        : idx === 1
                          ? 'text-slate-300'
                          : idx === 2
                            ? 'text-amber-500'
                            : 'text-zinc-500'
                    }`}
                  >
                    #{idx + 1}
                  </span>
                  <span className="text-white font-semibold truncate">
                    {entry.playerName}
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-[10px] text-zinc-400">
                    {entry.bestTimeSec.toFixed(1)}s
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-[#FFD700]/15 text-[#FFD700] border border-[#FFD700]/40 text-[10px] font-bold tabular-nums">
                    {entry.streak} ★
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 2. Top 3 Fastest Solvers (Local Storage) */}
        <div
          data-testid="top-3-fastest-leaderboard"
          className="rounded-lg bg-[#18181b]/90 border border-zinc-800 p-2.5 flex flex-col justify-between gap-1.5"
        >
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-mono uppercase tracking-wider font-bold text-[#00a3ff]">
                ⚡ Top 3 Fastest Solvers
              </span>
              <span className="text-[9px] font-mono text-zinc-400">
                Speed Record
              </span>
            </div>
            <div className="space-y-1.5">
              {fastestSolvers.slice(0, 3).map((solver, idx) => (
                <div
                  key={solver.id}
                  data-testid={`fastest-solver-row-${idx + 1}`}
                  className="flex items-center justify-between text-xs font-mono px-2 py-1.5 rounded bg-[#09090b] border border-[#00a3ff]/25"
                >
                  <div className="flex items-center gap-1.5 min-w-0">
                    <span className="text-[10px] font-bold text-[#00a3ff]">
                      #{idx + 1}
                    </span>
                    <div className="min-w-0">
                      <div className="text-white font-semibold truncate">
                        {solver.playerName}
                      </div>
                      <div className="text-[9px] text-zinc-400 truncate">
                        {solver.puzzleTitle}
                      </div>
                    </div>
                  </div>
                  <span className="px-1.5 py-0.5 rounded bg-[#00a3ff]/15 text-[#00a3ff] border border-[#00a3ff]/40 text-[10px] font-bold whitespace-nowrap shrink-0 tabular-nums">
                    {solver.label}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="text-[10px] font-mono text-zinc-400 pt-1 border-t border-zinc-800/80 flex items-center justify-between">
            <span>Solve any Mate-in-1 to rank!</span>
            <span className="text-[#00a3ff]">Auto-saved</span>
          </div>
        </div>
      </div>
    </div>
  );
};
