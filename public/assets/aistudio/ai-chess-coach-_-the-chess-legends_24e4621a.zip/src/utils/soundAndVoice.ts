import {
  AI_PERSONALITIES,
  PersonalityId,
  VocalEmotionCue,
} from '../game/personalities';
import { customSoundManager } from './customSounds';

export type MoveSoundActor = 'player' | 'ai';

class SoundAndVoiceEngine {
  private audioCtx: AudioContext | null = null;
  private clauseTimeouts: number[] = [];
  public isMuted = false;
  public naturalBreathingEnabled = true;

  private getAudioContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      if (Ctx) this.audioCtx = new Ctx();
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().catch(() => {});
    }
    return this.audioCtx;
  }

  private clearPendingClauses(): void {
    if (typeof window === 'undefined') return;
    this.clauseTimeouts.forEach((id) => window.clearTimeout(id));
    this.clauseTimeouts = [];
  }

  /**
   * Ranks browser voices to prefer natural neural / online / Indian English & Hindi voices
   * over flat legacy desktop synthesizers.
   */
  public selectBestHumanVoice(
    voices: SpeechSynthesisVoice[],
    personalityId: PersonalityId
  ): SpeechSynthesisVoice | null {
    if (!voices || voices.length === 0) return null;

    const scoreVoice = (v: SpeechSynthesisVoice): number => {
      const name = v.name.toLowerCase();
      const lang = v.lang.toLowerCase();
      let score = 0;

      // Prefer Hindi & Indian English for natural Hinglish pronunciation
      if (lang.includes('hi-in')) score += 45;
      else if (lang.includes('en-in')) score += 42;
      else if (lang.startsWith('en-gb') || lang.startsWith('en-us')) score += 20;
      else if (lang.startsWith('en')) score += 12;

      // Strongly prefer Natural / Neural / Online / Google voices
      if (name.includes('natural')) score += 35;
      if (name.includes('online')) score += 25;
      if (name.includes('neural')) score += 25;
      if (name.includes('google')) score += 22;
      if (
        name.includes('swara') ||
        name.includes('madhur') ||
        name.includes('neerja') ||
        name.includes('prabhat') ||
        name.includes('rishi') ||
        name.includes('veena')
      ) {
        score += 28;
      }

      // Personality-appropriate vocal timbre preference when multiple voices exist
      if (personalityId === 'cat' && (name.includes('swara') || name.includes('neerja') || name.includes('female') || name.includes('veena'))) {
        score += 10;
      }
      if (personalityId === 'dragon' && (name.includes('madhur') || name.includes('prabhat') || name.includes('rishi') || name.includes('daniel') || name.includes('male'))) {
        score += 10;
      }

      // Penalize known robotic/novelty voices
      if (name.includes('espeak') || name.includes('zarvox') || name.includes('trinoids') || name.includes('whisper')) {
        score -= 50;
      }

      return score;
    };

    const sorted = [...voices].sort((a, b) => scoreVoice(b) - scoreVoice(a));
    return sorted[0] || null;
  }

  /**
   * Splits a conversational line into natural human breath-groups/clauses
   * so the voice pauses, inflects, and breathes like a real person.
   */
  public splitIntoHumanClauses(text: string): string[] {
    const cleaned = text.replace(/\s+/g, ' ').trim();
    if (!cleaned) return [];

    // Split along sentence endings, ellipses, em-dashes, and conversational pauses
    const rawParts = cleaned
      .split(/(?<=[!?…]|\.\.\.|—)\s+|(?<=[.,])\s+(?=[A-Z0-9])/g)
      .map((s) => s.trim())
      .filter(Boolean);

    return rawParts.length > 0 ? rawParts : [cleaned];
  }

  /**
   * Subtle acoustic emotion cue (warm chuckle, sleepy sigh, excited chime)
   * that precedes speech to give immediate human warmth.
   * Uses custom sound from `public/sounds/` if available, otherwise synthesizes locally.
   */
  public playVocalEmotionCue(
    cue: VocalEmotionCue,
    personalityId: PersonalityId
  ): void {
    if (this.isMuted) return;

    const sfxKey =
      cue === 'laugh'
        ? 'laugh'
        : cue === 'yawn' || (cue === 'calm' && personalityId === 'cat')
        ? 'yawn'
        : cue === 'hype'
        ? 'hype'
        : null;

    if (!sfxKey) return;

    customSoundManager.playCustomSfx(sfxKey, () => {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const now = ctx.currentTime;

      if (cue === 'laugh') {
        // Warm two-note human chuckle inflection
        [340, 410].forEach((freq, i) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          const start = now + i * 0.065;
          osc.frequency.setValueAtTime(freq, start);
          osc.frequency.exponentialRampToValueAtTime(freq * 1.15, start + 0.055);
          gain.gain.setValueAtTime(0.06, start);
          gain.gain.exponentialRampToValueAtTime(0.001, start + 0.06);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(start);
          osc.stop(start + 0.065);
        });
      } else if (cue === 'yawn' || (cue === 'calm' && personalityId === 'cat')) {
        // Cozy descending sigh
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(360, now);
        osc.frequency.exponentialRampToValueAtTime(240, now + 0.16);
        gain.gain.setValueAtTime(0.05, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.17);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.18);
      } else if (cue === 'hype') {
        // Warm encouraging fifth interval
        [392.0, 587.33].forEach((freq, i) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          const start = now + i * 0.055;
          osc.frequency.setValueAtTime(freq, start);
          gain.gain.setValueAtTime(0.07, start);
          gain.gain.exponentialRampToValueAtTime(0.001, start + 0.14);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(start);
          osc.stop(start + 0.15);
        });
      }
    });
  }

  public speakHinglish(
    text: string,
    personalityId: PersonalityId,
    onStart?: () => void,
    onEnd?: () => void,
    vocalCue: VocalEmotionCue = 'calm'
  ): void {
    this.clearPendingClauses();

    if (
      this.isMuted ||
      typeof window === 'undefined' ||
      !('speechSynthesis' in window)
    ) {
      onEnd?.();
      return;
    }

    try {
      window.speechSynthesis.cancel();
      this.playVocalEmotionCue(vocalCue, personalityId);

      const persona = AI_PERSONALITIES[personalityId];
      const voices = window.speechSynthesis.getVoices();
      const chosenVoice = this.selectBestHumanVoice(voices, personalityId);
      const clauses = this.naturalBreathingEnabled
        ? this.splitIntoHumanClauses(text)
        : [text];

      if (clauses.length === 0) {
        onEnd?.();
        return;
      }

      let currentIndex = 0;
      onStart?.();

      const speakNextClause = () => {
        if (this.isMuted || currentIndex >= clauses.length) {
          onEnd?.();
          return;
        }

        const clause = clauses[currentIndex];
        currentIndex += 1;

        const utterance = new SpeechSynthesisUtterance(clause);
        if (chosenVoice) {
          utterance.voice = chosenVoice;
        }

        // Dynamic human conversational prosody per clause (avoids flat robotic monotone)
        const isExclamation = clause.endsWith('!');
        const isQuestion = clause.endsWith('?');
        const isReflective = clause.includes('...') || clause.includes('—');

        let clausePitch = persona.voicePitch;
        let clauseRate = persona.voiceRate;

        if (isQuestion) {
          clausePitch += 0.05;
          clauseRate += 0.02;
        } else if (isExclamation) {
          clausePitch += 0.03;
          clauseRate += 0.03;
        } else if (isReflective) {
          clausePitch -= 0.02;
          clauseRate -= 0.04;
        }

        // Subtle micro-variation so consecutive sentences feel organically human
        const organicJitter = ((currentIndex % 3) - 1) * 0.015;
        utterance.pitch = Math.max(0.85, Math.min(1.18, clausePitch + organicJitter));
        utterance.rate = Math.max(0.88, Math.min(1.12, clauseRate));
        utterance.volume = 1.0;

        utterance.onend = () => {
          if (currentIndex < clauses.length) {
            // Natural human breathing pause between clauses (120ms - 190ms)
            const pauseMs = isReflective ? 190 : 125;
            const timerId = window.setTimeout(speakNextClause, pauseMs);
            this.clauseTimeouts.push(timerId);
          } else {
            onEnd?.();
          }
        };

        utterance.onerror = () => {
          onEnd?.();
        };

        window.speechSynthesis.speak(utterance);
      };

      speakNextClause();
    } catch {
      onEnd?.();
    }
  }

  /**
   * Distinct sound effects for Player vs. AI piece moves, Captures, and Check alerts.
   * Plays custom file from `public/sounds/` if available, otherwise uses Web Audio API synth.
   */
  public playMoveSound(
    actorOrCapture: MoveSoundActor | boolean = 'player',
    isCapture = false,
    isCheck = false
  ): void {
    if (this.isMuted) return;

    // Backwards-compatible signature handling
    const actor: MoveSoundActor =
      typeof actorOrCapture === 'boolean' ? 'player' : actorOrCapture;
    const captureFlag =
      typeof actorOrCapture === 'boolean' ? actorOrCapture : isCapture;
    const checkFlag =
      typeof actorOrCapture === 'boolean' ? isCapture : isCheck;

    const customKey = checkFlag
      ? 'check'
      : captureFlag
      ? 'capture'
      : actor === 'ai'
      ? 'aiMove'
      : 'move';

    customSoundManager.playCustomSfx(customKey, () => {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      const now = ctx.currentTime;

      if (checkFlag) {
        // Sharp two-tone tactical Check alert
        [523.25, 783.99].forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'triangle';
          const start = now + idx * 0.065;
          osc.frequency.setValueAtTime(freq, start);
          gain.gain.setValueAtTime(0.18, start);
          gain.gain.exponentialRampToValueAtTime(0.001, start + 0.16);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(start);
          osc.stop(start + 0.17);
        });
        return;
      }

      if (captureFlag) {
        // Heavy wooden tournament capture thud + crisp snap
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(210, now);
        osc.frequency.exponentialRampToValueAtTime(75, now + 0.11);
        gain.gain.setValueAtTime(0.22, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.13);
        return;
      }

      if (actor === 'player') {
        // Warm tactile wooden piece thud + magnetic sensor click for Player move
        const woodOsc = ctx.createOscillator();
        const woodGain = ctx.createGain();
        woodOsc.type = 'sine';
        woodOsc.frequency.setValueAtTime(195, now);
        woodOsc.frequency.exponentialRampToValueAtTime(92, now + 0.075);
        woodGain.gain.setValueAtTime(0.2, now);
        woodGain.gain.exponentialRampToValueAtTime(0.001, now + 0.085);
        woodOsc.connect(woodGain);
        woodGain.connect(ctx.destination);
        woodOsc.start(now);
        woodOsc.stop(now + 0.09);

        const clickOsc = ctx.createOscillator();
        const clickGain = ctx.createGain();
        clickOsc.type = 'triangle';
        clickOsc.frequency.setValueAtTime(1120, now + 0.015);
        clickOsc.frequency.exponentialRampToValueAtTime(480, now + 0.045);
        clickGain.gain.setValueAtTime(0.07, now + 0.015);
        clickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
        clickOsc.connect(clickGain);
        clickGain.connect(ctx.destination);
        clickOsc.start(now + 0.015);
        clickOsc.stop(now + 0.055);
      } else {
        // Distinct Smart Board CoreXY electromagnetic glide + harmonic lock chime for AI move
        const servoOsc = ctx.createOscillator();
        const servoGain = ctx.createGain();
        servoOsc.type = 'triangle';
        servoOsc.frequency.setValueAtTime(330, now);
        servoOsc.frequency.exponentialRampToValueAtTime(495, now + 0.09);
        servoGain.gain.setValueAtTime(0.14, now);
        servoGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
        servoOsc.connect(servoGain);
        servoGain.connect(ctx.destination);
        servoOsc.start(now);
        servoOsc.stop(now + 0.11);
      }
    });
  }

  /**
   * Celebratory multi-voice royal fanfare played automatically on Checkmate.
   */
  public playCheckmateFanfare(): void {
    if (this.isMuted) return;
    customSoundManager.playCustomSfx('victory', () => {
      const ctx = this.getAudioContext();
      if (!ctx) return;

      // Grand C-major trumpet & bell fanfare (C4, E4, G4, C5, E5, G5, C6)
      const notes = [261.63, 329.63, 392.0, 523.25, 659.25, 783.99, 1046.5];
      notes.forEach((freq, idx) => {
        const start = ctx.currentTime + idx * 0.07;
        const duration = idx === notes.length - 1 ? 0.85 : 0.45;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = idx >= 3 ? 'triangle' : 'sine';
        osc.frequency.setValueAtTime(freq, start);
        gain.gain.setValueAtTime(0.16, start);
        gain.gain.exponentialRampToValueAtTime(0.001, start + duration);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(start);
        osc.stop(start + duration + 0.02);
      });
    });
  }
}

export const soundEngine = new SoundAndVoiceEngine();
