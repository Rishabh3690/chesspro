import React from 'react';
import { AI_PERSONALITIES, PersonalityId } from '../game/personalities';
import { AIAvatarSvg } from './AIAvatarSvg';

interface TitleScreenOverlayProps {
  selectedPersonality: PersonalityId;
  onSelectPersonality: (id: PersonalityId) => void;
  onStartFullMatch: () => void;
  onStartPuzzleRush: () => void;
}

export const TitleScreenOverlay: React.FC<TitleScreenOverlayProps> = ({
  selectedPersonality,
  onSelectPersonality,
  onStartFullMatch,
  onStartPuzzleRush,
}) => {
  return (
    <div className="fixed inset-0 z-40 bg-[#0A1929] flex flex-col justify-between p-6 sm:p-10 overflow-y-auto">
      {/* Top quiet exhibition identifier */}
      <div className="flex items-center justify-between max-w-6xl w-full mx-auto">
        <div className="text-xs font-mono tracking-widest uppercase text-[#00E5FF]">
          STEM EXHIBITION SHOWCASE · STOCKFISH NEURAL COACH
        </div>
        <div className="text-xs font-mono text-slate-400 tabular-nums">
          WHITE vs AI BLACK
        </div>
      </div>

      {/* Main Negative-Space Asymmetric Split */}
      <div className="max-w-6xl w-full mx-auto my-auto py-6 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left 7 columns: Custom Inline SVG Title Lockup + Primary Start Handshake */}
        <div className="lg:col-span-7 text-left space-y-6">
          <div className="inline-flex items-center gap-4">
            {/* Custom SVG Grandmaster Crown + Neural Circuit Crest */}
            <svg
              viewBox="0 0 72 72"
              className="w-16 h-16 sm:w-20 sm:h-20 shrink-0"
              aria-hidden="true"
            >
              <polygon
                points="36,4 66,20 66,52 36,68 6,52 6,20"
                fill="#102338"
                stroke="#00E5FF"
                strokeWidth="2.5"
              />
              <path
                d="M16,48 L56,48 L52,24 L41,35 L36,18 L31,35 L20,24 Z"
                fill="#FFD700"
                stroke="#0A1929"
                strokeWidth="2"
                strokeLinejoin="round"
              />
              <circle cx="20" cy="20" r="3" fill="#00E5FF" />
              <circle cx="36" cy="14" r="3.5" fill="#00E5FF" />
              <circle cx="52" cy="20" r="3" fill="#00E5FF" />
            </svg>

            <div>
              <div className="text-xs font-mono uppercase tracking-widest text-[#FFD700]">
                AI CHESS COACH ARENA
              </div>
              <h1
                className="text-4xl sm:text-6xl font-extrabold font-display tracking-tight text-white"
                style={{ textWrap: 'balance' }}
              >
                The Chess Legends
              </h1>
            </div>
          </div>

          <p className="text-base sm:text-lg text-slate-300 max-w-xl leading-relaxed">
            Step up to the exhibition board. Face three distinct Stockfish AI personas—from a sleepy Hinglish cat to a ruthless 2800-ELO Grandmaster Dragon—with live neural telemetry and 30-second Mate-in-1 Puzzle Rush.
          </p>

          {/* Interactive Persona Selector Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-2xl">
            {(['cat', 'robot', 'dragon'] as PersonalityId[]).map((pid) => {
              const p = AI_PERSONALITIES[pid];
              const active = selectedPersonality === pid;
              return (
                <button
                  key={pid}
                  type="button"
                  onClick={() => onSelectPersonality(pid)}
                  className={`text-left p-3.5 rounded-xl border transition-all cursor-pointer ${
                    active
                      ? 'bg-[#132A42] border-[#00E5FF] shadow-[0_0_20px_rgba(0,229,255,0.2)]'
                      : 'bg-[#0D1E31] border-slate-800 hover:border-slate-600'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-display font-bold text-sm text-white">
                      {p.name}
                    </span>
                    <span className="text-[11px] font-mono text-[#FFD700] tabular-nums">
                      Lv.{p.skillLevel}
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 line-clamp-2">
                    {p.tagline}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Primary CTA Handshake (<= 3 menu actions total) */}
          <div className="flex flex-wrap items-center gap-4 pt-2">
            <button
              type="button"
              data-start="true"
              onClick={onStartFullMatch}
              className="px-7 py-3.5 rounded-xl bg-[#00E5FF] hover:bg-[#33ecff] text-[#0A1929] font-display font-extrabold text-base tracking-wide shadow-[0_0_28px_rgba(0,229,255,0.4)] transition-transform active:scale-95 whitespace-nowrap shrink-0 cursor-pointer"
            >
              Start Full Match
            </button>

            <button
              type="button"
              onClick={onStartPuzzleRush}
              className="px-6 py-3.5 rounded-xl bg-[#132A42] hover:bg-[#1B3A5A] text-[#FFD700] border border-[#FFD700]/50 font-display font-bold text-base transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              30s Puzzle Rush
            </button>
          </div>
        </div>

        {/* Right 5 columns: Interactive AI Avatar Showcase Centerpiece */}
        <div className="lg:col-span-5 flex flex-col items-center justify-center p-6 rounded-2xl bg-[#102338]/90 border border-[#00E5FF]/25">
          <AIAvatarSvg
            personality={selectedPersonality}
            mood={selectedPersonality === 'dragon' ? 'evil' : selectedPersonality === 'cat' ? 'happy' : 'normal'}
            isThinking={true}
            isSpeaking={false}
          />
          <div className="mt-4 text-center max-w-sm">
            <div className="text-base font-bold font-display text-white">
              {AI_PERSONALITIES[selectedPersonality].name} · {AI_PERSONALITIES[selectedPersonality].badge}
            </div>
            <p className="mt-2 text-xs font-mono text-[#00E5FF] italic">
              &ldquo;{AI_PERSONALITIES[selectedPersonality].openingGreeting}&rdquo;
            </p>
          </div>
        </div>
      </div>

      {/* Flat borderless bottom control hint line */}
      <div className="max-w-6xl w-full mx-auto text-center sm:text-left text-xs font-mono text-slate-400">
        Click or Drag White Pieces · Enter Start Match · P Pause · R Reset Board · M Toggle Hinglish Voice
      </div>
    </div>
  );
};
