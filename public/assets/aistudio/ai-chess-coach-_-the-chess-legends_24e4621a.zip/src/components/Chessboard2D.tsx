import React from 'react';
import {
  BOARD_COLOR_SCHEMES,
  BoardColorScheme,
  Move,
  Piece,
} from '../game/chessEngine';
import { ChessPieceSvg } from './ChessPieceSvg';

interface Chessboard2DProps {
  board: (Piece | null)[][];
  selectedSquare: string | null;
  legalTargetSquares: string[];
  lastMove: Move | null;
  inCheckKingSquare: string | null;
  isCheckmate: boolean;
  evaluation: number;
  boardTheme?: BoardColorScheme;
  onSquareClick: (sq: string) => void;
  onPieceDrop: (from: string, to: string) => void;
}

const FILES = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
const RANKS = ['8', '7', '6', '5', '4', '3', '2', '1'];

export const Chessboard2D: React.FC<Chessboard2DProps> = ({
  board,
  selectedSquare,
  legalTargetSquares,
  lastMove,
  inCheckKingSquare,
  isCheckmate,
  evaluation,
  boardTheme = 'midnight-blue',
  onSquareClick,
  onPieceDrop,
}) => {
  // Clamp evaluation between -10 and +10 for the visual bar
  const clampedEval = Math.max(-10, Math.min(10, evaluation));
  const whitePercentage = Math.round(((clampedEval + 10) / 20) * 100);
  const scheme =
    BOARD_COLOR_SCHEMES[boardTheme] || BOARD_COLOR_SCHEMES['midnight-blue'];

  return (
    <div className="flex items-stretch gap-2.5 w-full max-w-[540px] mx-auto">
      {/* Vertical Live Evaluation Bar */}
      <div
        className="w-6 sm:w-7 rounded-sm bg-black border border-zinc-700 overflow-hidden flex flex-col justify-end relative shrink-0"
        title={`Position Evaluation: ${evaluation >= 0 ? '+' : ''}${evaluation.toFixed(2)}`}
      >
        <div
          className="w-full bg-white transition-transform duration-200 origin-bottom"
          style={{
            height: '100%',
            transform: `scaleY(${whitePercentage / 100})`,
          }}
        />
        <span className="absolute top-1.5 inset-x-0 text-center text-[8px] font-mono font-bold text-white mix-blend-difference tabular-nums">
          {evaluation >= 0 ? `+${evaluation.toFixed(1)}` : evaluation.toFixed(1)}
        </span>
      </div>

      {/* Main 8x8 Responsive Tournament Board */}
      <div
        data-testid="chessboard-frame"
        data-board-theme={scheme.id}
        className={`relative flex-1 aspect-square rounded-md p-1.5 sm:p-2.5 border-2 shadow-[0_14px_40px_rgba(0,0,0,0.75)] transition-colors duration-200 ${scheme.frameClass}`}
      >
        <div
          data-testid="chessboard-grid"
          data-board-theme={scheme.id}
          className="w-full h-full grid grid-cols-8 grid-rows-8 rounded-sm overflow-hidden border border-black"
        >
          {board.map((row, r) =>
            row.map((piece, c) => {
              const sq = `${FILES[c]}${RANKS[r]}`;
              const isLight = (r + c) % 2 === 0;
              const isSelected = selectedSquare === sq;
              const isLegalTarget = legalTargetSquares.includes(sq);
              const isLastMove =
                lastMove && (lastMove.from === sq || lastMove.to === sq);
              const isKingInDanger = inCheckKingSquare === sq;

              let sqBg = isLight
                ? scheme.lightSquareClass
                : scheme.darkSquareClass;
              if (isSelected) {
                sqBg = scheme.selectedSquareClass;
              } else if (isKingInDanger) {
                sqBg = 'bg-zinc-950 ring-2 ring-white';
              } else if (isLastMove) {
                sqBg = isLight
                  ? scheme.lastMoveLightClass
                  : scheme.lastMoveDarkClass;
              }

              return (
                <button
                  key={sq}
                  type="button"
                  data-square={sq}
                  aria-label={`Square ${sq}${piece ? ` with ${piece.color === 'w' ? 'White' : 'Black'} ${piece.type.toUpperCase()}` : ''}`}
                  onClick={() => onSquareClick(sq)}
                  draggable={!!piece && piece.color === 'w'}
                  onDragStart={(e) => {
                    e.dataTransfer.setData('text/plain', sq);
                    onSquareClick(sq);
                  }}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    const fromSq = e.dataTransfer.getData('text/plain');
                    if (fromSq && fromSq !== sq) {
                      onPieceDrop(fromSq, sq);
                    }
                  }}
                  className={`relative flex items-center justify-center w-full h-full p-0.5 sm:p-1 select-none focus:outline-none focus-visible:ring-2 focus-visible:ring-white cursor-pointer transition-colors duration-150 ${sqBg}`}
                >
                  {/* Coordinate Labels along left rank & bottom file */}
                  {c === 0 && (
                    <span
                      className={`absolute top-0.5 left-1 text-[9px] sm:text-[10px] font-mono font-bold leading-none pointer-events-none ${
                        isLight
                          ? scheme.coordLightTextClass
                          : scheme.coordDarkTextClass
                      }`}
                    >
                      {RANKS[r]}
                    </span>
                  )}
                  {r === 7 && (
                    <span
                      className={`absolute bottom-0.5 right-1 text-[9px] sm:text-[10px] font-mono font-bold leading-none pointer-events-none ${
                        isLight
                          ? scheme.coordLightTextClass
                          : scheme.coordDarkTextClass
                      }`}
                    >
                      {FILES[c]}
                    </span>
                  )}

                  {/* Legal Move Indicator Dot / Capture Corner Ring */}
                  {isLegalTarget && !piece && (
                    <span className="w-3 h-3 sm:w-3.5 sm:h-3.5 rounded-full bg-black/65 ring-2 ring-white pointer-events-none" />
                  )}
                  {isLegalTarget && piece && (
                    <span className="absolute inset-0.5 rounded-sm border-2 border-white pointer-events-none" />
                  )}

                  {/* Checkmate Shockwave Ring on Mated King */}
                  {isCheckmate && isKingInDanger && (
                    <span className="absolute inset-0 rounded-full border-4 border-white animate-shockwave pointer-events-none" />
                  )}

                  {/* Chess Piece SVG */}
                  {piece && (
                    <ChessPieceSvg
                      type={piece.type}
                      color={piece.color}
                      className="w-[86%] h-[86%] transition-transform duration-150"
                    />
                  )}
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
