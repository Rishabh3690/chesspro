import React, { useState } from 'react';
import {
  Color,
  Move,
  Piece,
  coordsToSquare,
  squareToCoords,
} from '../game/chessEngine';
import { ChessPieceSvg } from './ChessPieceSvg';

interface ChessboardArenaProps {
  board: (Piece | null)[][];
  turn: Color;
  inCheck: boolean;
  isCheckmate: boolean;
  kingSquareWhite: string;
  kingSquareBlack: string;
  evaluation: number;
  selectedSquare: string | null;
  legalTargets: Move[];
  lastMove: { from: string; to: string } | null;
  hintMove: { from: string; to: string; san: string } | null;
  onSquareClick: (sq: string) => void;
  onDropMove: (from: string, to: string) => void;
}

const FILES = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
const RANKS = ['8', '7', '6', '5', '4', '3', '2', '1'];

const PIECE_NAMES: Record<string, string> = {
  p: 'Pawn',
  n: 'Knight',
  b: 'Bishop',
  r: 'Rook',
  q: 'Queen',
  k: 'King',
};

export const ChessboardArena: React.FC<ChessboardArenaProps> = ({
  board,
  turn,
  inCheck,
  isCheckmate,
  kingSquareWhite,
  kingSquareBlack,
  evaluation,
  selectedSquare,
  legalTargets,
  lastMove,
  hintMove,
  onSquareClick,
  onDropMove,
}) => {
  const [draggedFrom, setDraggedFrom] = useState<string | null>(null);

  // Compute White advantage bar height percentage (50% = 0.00, clamped -10 to +10)
  const clampedEval = Math.max(-10, Math.min(10, evaluation));
  const whitePercent = Math.round(50 + (clampedEval / 10) * 46);

  const matedKingSquare = isCheckmate
    ? turn === 'w'
      ? kingSquareWhite
      : kingSquareBlack
    : null;
  const [matedRow, matedCol] = matedKingSquare
    ? squareToCoords(matedKingSquare)
    : [-1, -1];

  return (
    <div className="flex items-stretch gap-2.5 sm:gap-3 w-full max-w-[540px] mx-auto select-none">
      {/* Live Vertical Evaluation Bar */}
      <div
        className="w-5 sm:w-6 rounded-xl bg-[#07111E] border border-[#00E5FF]/30 overflow-hidden flex flex-col justify-between relative shrink-0"
        aria-label={`Position Evaluation ${evaluation >= 0 ? `+${evaluation.toFixed(2)}` : evaluation.toFixed(2)}`}
      >
        <div
          className="w-full bg-[#0D1E31] transition-all duration-300"
          style={{ height: `${100 - whitePercent}%` }}
        />
        <div
          className="w-full bg-gradient-to-t from-[#00E5FF] to-[#E2E8F0] transition-all duration-300"
          style={{ height: `${whitePercent}%` }}
        />
        <span className="absolute top-1.5 inset-x-0 text-center text-[9px] font-mono font-bold text-slate-300 tabular-nums">
          B
        </span>
        <span className="absolute bottom-1.5 inset-x-0 text-center text-[9px] font-mono font-bold text-[#0A1929] tabular-nums">
          W
        </span>
      </div>

      {/* Main 8x8 Chessboard Container */}
      <div className="relative flex-1 aspect-square rounded-2xl p-2 sm:p-3 bg-[#102338] border-2 border-[#00E5FF]/35 shadow-[0_14px_40px_rgba(0,0,0,0.65)]">
        <div
          data-testid="chessboard-grid"
          className="w-full h-full grid grid-cols-8 grid-rows-8 rounded-lg overflow-hidden border border-slate-900"
        >
          {board.map((row, r) =>
            row.map((piece, c) => {
              const sq = coordsToSquare(r, c);
              const isLight = (r + c) % 2 === 0;
              const isSelected = selectedSquare === sq;
              const legalMove = legalTargets.find((m) => m.to === sq);
              const isLastMove =
                lastMove?.from === sq || lastMove?.to === sq;
              const isHint =
                hintMove?.from === sq || hintMove?.to === sq;
              const isKingInCheck =
                inCheck &&
                ((turn === 'w' && sq === kingSquareWhite) ||
                  (turn === 'b' && sq === kingSquareBlack));

              // Radial distance from mated king for checkmate ripple wave
              const distFromMate =
                matedRow >= 0
                  ? Math.hypot(r - matedRow, c - matedCol)
                  : 0;

              let bgClass = isLight ? 'bg-[#DCE6F2]' : 'bg-[#2B4C7E]';
              if (isSelected) {
                bgClass = 'bg-[#00E5FF]/75';
              } else if (isKingInCheck) {
                bgClass = 'bg-[#FF3B5C]';
              } else if (isHint) {
                bgClass = 'bg-[#FFD700]/65';
              } else if (isLastMove) {
                bgClass = isLight ? 'bg-[#A5F3FC]' : 'bg-[#0E7490]';
              }

              const pieceDesc = piece
                ? `${piece.color === 'w' ? 'White' : 'Black'} ${PIECE_NAMES[piece.type]}`
                : 'Empty';
              const targetDesc = legalMove ? ' · Legal target' : '';

              return (
                <button
                  key={sq}
                  type="button"
                  data-square={sq}
                  aria-label={`Square ${sq}, ${pieceDesc}${targetDesc}`}
                  onClick={() => onSquareClick(sq)}
                  draggable={!!piece && piece.color === 'w'}
                  onDragStart={() => setDraggedFrom(sq)}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={() => {
                    if (draggedFrom && draggedFrom !== sq) {
                      onDropMove(draggedFrom, sq);
                    }
                    setDraggedFrom(null);
                  }}
                  style={
                    isCheckmate
                      ? {
                          boxShadow:
                            sq === matedKingSquare
                              ? 'inset 0 0 22px #FFD700'
                              : undefined,
                          transitionDelay: `${Math.round(distFromMate * 45)}ms`,
                        }
                      : undefined
                  }
                  className={`relative w-full h-full flex items-center justify-center p-0.5 sm:p-1 transition-colors duration-150 focus-visible:outline-2 focus-visible:outline-[#FFD700] cursor-pointer ${bgClass}`}
                >
                  {/* Rank label on a-file */}
                  {c === 0 && (
                    <span
                      className={`absolute top-0.5 left-1 text-[9px] sm:text-[10px] font-mono font-bold leading-none pointer-events-none ${
                        isLight ? 'text-[#1E3A5F]' : 'text-[#DCE6F2]'
                      }`}
                    >
                      {RANKS[r]}
                    </span>
                  )}

                  {/* File label on 1st rank */}
                  {r === 7 && (
                    <span
                      className={`absolute bottom-0.5 right-1 text-[9px] sm:text-[10px] font-mono font-bold leading-none pointer-events-none ${
                        isLight ? 'text-[#1E3A5F]' : 'text-[#DCE6F2]'
                      }`}
                    >
                      {FILES[c]}
                    </span>
                  )}

                  {/* Legal move indicator dot or capture ring */}
                  {legalMove && !piece && (
                    <span className="w-3 h-3 sm:w-3.5 sm:h-3.5 rounded-full bg-[#0A1929]/55 border border-[#00E5FF] pointer-events-none" />
                  )}
                  {legalMove && piece && (
                    <span className="absolute inset-1 rounded-full border-[3px] border-[#FFD700] pointer-events-none" />
                  )}

                  {/* Chess Piece SVG */}
                  {piece && (
                    <div className="w-[84%] h-[84%] transition-transform duration-150">
                      <ChessPieceSvg type={piece.type} color={piece.color} />
                    </div>
                  )}
                </button>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
