import { customSoundManager } from './customSounds';

export type VoiceModelId = 'jarvis-neural' | 'aryan-hinglish' | 'judge-formal';

export interface VoiceModelOption {
  id: VoiceModelId;
  name: string;
  subtitle: string;
  badge: string;
  pitch: number;
  rate: number;
  preferredLangs: string[];
  preferredKeywords: string[];
}

export const VOICE_MODELS: VoiceModelOption[] = [
  {
    id: 'jarvis-neural',
    name: 'J.A.R.V.I.S. Tactical Core',
    subtitle: 'Natural Analytical Neural Cadence',
    badge: 'NEURAL v4.2',
    pitch: 0.96,
    rate: 1.02,
    preferredLangs: ['en-GB', 'en-IN', 'en-US'],
    preferredKeywords: ['Natural', 'Neural', 'Online', 'Google UK English Male', 'Daniel', 'Arthur', 'Ryan'],
  },
  {
    id: 'aryan-hinglish',
    name: 'GM Aryan (Natural Hinglish)',
    subtitle: 'Warm Conversational Grandmaster Coach',
    badge: 'HUMAN HINGLISH',
    pitch: 1.0,
    rate: 0.98,
    preferredLangs: ['en-IN', 'hi-IN', 'en-GB', 'en-US'],
    preferredKeywords: ['Natural', 'Neural', 'Prabhat', 'Madhur', 'Swara', 'Rishi', 'Google हिन्दी', 'Google English'],
  },
  {
    id: 'judge-formal',
    name: 'FIDE Chief Arbiter',
    subtitle: 'Distinguished Tournament Commentary',
    badge: 'FORMAL',
    pitch: 0.93,
    rate: 0.95,
    preferredLangs: ['en-GB', 'en-US', 'en-IN'],
    preferredKeywords: ['Natural', 'Neural', 'George', 'Oliver', 'Google UK English', 'Microsoft'],
  },
];

/**
 * Selects the highest-quality natural browser voice for the active Voice Model.
 */
export function selectBestBrowserVoice(
  voices: SpeechSynthesisVoice[],
  modelId: VoiceModelId
): SpeechSynthesisVoice | null {
  if (!voices || voices.length === 0) return null;
  const config = VOICE_MODELS.find((m) => m.id === modelId) || VOICE_MODELS[0];

  let bestVoice: SpeechSynthesisVoice | null = null;
  let bestScore = -1;

  for (const v of voices) {
    let score = 0;
    const nameLower = v.name.toLowerCase();
    const langLower = v.lang.toLowerCase();

    // Boost natural/neural/online voices
    if (nameLower.includes('natural') || nameLower.includes('neural') || nameLower.includes('online')) {
      score += 50;
    }
    if (nameLower.includes('google') || nameLower.includes('microsoft') || nameLower.includes('premium')) {
      score += 25;
    }

    for (let i = 0; i < config.preferredLangs.length; i++) {
      if (langLower.startsWith(config.preferredLangs[i].toLowerCase())) {
        score += 35 - i * 8;
        break;
      }
    }

    for (const kw of config.preferredKeywords) {
      if (nameLower.includes(kw.toLowerCase())) {
        score += 30;
      }
    }

    if (score > bestScore) {
      bestScore = score;
      bestVoice = v;
    }
  }

  return bestVoice || voices[0];
}

/**
 * Speaks commentary with natural human clause pacing and prosody modulation.
 */
export function speakNaturalCommentary(
  text: string,
  modelId: VoiceModelId,
  isMuted: boolean
): void {
  if (isMuted || typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return;
  }

  try {
    window.speechSynthesis.cancel();
    const voices = window.speechSynthesis.getVoices();
    const config = VOICE_MODELS.find((m) => m.id === modelId) || VOICE_MODELS[0];
    const selectedVoice = selectBestBrowserVoice(voices, modelId);

    // Split into natural human breath clauses so speech has conversational cadence
    const clauses = text
      .split(/(?<=[.!?—])\s+/)
      .map((s) => s.trim())
      .filter(Boolean);

    clauses.forEach((clause, idx) => {
      const utterance = new SpeechSynthesisUtterance(clause);
      if (selectedVoice) {
        utterance.voice = selectedVoice;
        utterance.lang = selectedVoice.lang;
      } else {
        utterance.lang = config.preferredLangs[0] || 'en-IN';
      }

      // Subtle human micro-variation across clauses
      const pitchShift = idx === 0 ? 0.02 : idx % 2 === 1 ? -0.02 : 0;
      utterance.pitch = Math.max(0.75, Math.min(1.25, config.pitch + pitchShift));
      utterance.rate = Math.max(0.85, Math.min(1.15, config.rate));
      utterance.volume = 0.92;

      window.speechSynthesis.speak(utterance);
    });
  } catch {
    // Ignore speech synthesis errors on restricted headless browsers
  }
}

/**
 * Low-Volume Ambient "Lo-fi Chess" Synthesizer Engine (Web Audio API) + Custom Local Audio Support
 * Starts automatically upon the first user interaction and responds to Mute/Unmute.
 */
export class LofiChessAudioController {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private loopTimer: number | null = null;
  private vinylSource: AudioBufferSourceNode | null = null;
  private isPlaying = false;
  private isMuted = false;
  private stepIndex = 0;

  // Warm jazz/lo-fi 9th chord voicings (in Hz): Dm9 -> G13 -> Cmaj9 -> A7alt
  private readonly chords: number[][] = [
    [146.83, 220.0, 261.63, 329.63, 392.0], // Dm9 (D3, A3, C4, E4, G4)
    [196.0, 246.94, 293.66, 349.23, 440.0], // G13 (G3, B3, D4, F4, A4)
    [130.81, 196.0, 246.94, 293.66, 329.63], // Cmaj9 (C3, G3, B3, D4, E4)
    [110.0, 164.81, 207.65, 261.63, 329.63], // A7alt (A2, E3, G#3, C4, E4)
  ];

  private readonly melodyNotes: number[] = [
    523.25, 493.88, 440.0, 392.0, 329.63, 392.0, 440.0, 587.33,
  ];

  private ensureContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext })
        .webkitAudioContext;
    if (!AudioCtx) return null;

    if (!this.ctx) {
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      // Low-volume ambient Lo-fi level (0.048 gain)
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0.0001 : 0.048, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public startOnFirstInteraction(): boolean {
    if (this.isPlaying) return true;
    this.isPlaying = true;

    customSoundManager.startCustomBgm(() => {
      const ctx = this.ensureContext();
      if (!ctx || !this.masterGain) return;

      this.startSubtleVinylTexture(ctx, this.masterGain);
      this.playLofiBar();

      // 2.4 seconds per lo-fi chord bar (~75 BPM relaxed tempo)
      this.loopTimer = window.setInterval(() => {
        if (!this.isMuted && this.isPlaying) {
          this.playLofiBar();
        }
      }, 2400);
    });

    return true;
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
    customSoundManager.setMuted(muted);
    if (this.ctx && this.masterGain) {
      const now = this.ctx.currentTime;
      this.masterGain.gain.cancelScheduledValues(now);
      this.masterGain.gain.linearRampToValueAtTime(
        muted ? 0.0001 : 0.048,
        now + 0.18
      );
    }
    if (muted && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // Ignore
      }
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }

  private startSubtleVinylTexture(ctx: AudioContext, dest: AudioNode): void {
    try {
      const bufferSize = ctx.sampleRate * 2;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        // Very sparse warm vinyl dust
        output[i] = Math.random() < 0.004 ? (Math.random() * 2 - 1) * 0.15 : (Math.random() * 2 - 1) * 0.012;
      }
      const whiteNoise = ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;
      whiteNoise.loop = true;

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 1100;
      filter.Q.value = 0.7;

      const vinylGain = ctx.createGain();
      vinylGain.gain.value = 0.08;

      whiteNoise.connect(filter);
      filter.connect(vinylGain);
      vinylGain.connect(dest);
      whiteNoise.start();
      this.vinylSource = whiteNoise;
    } catch {
      // Ignore
    }
  }

  private playLofiBar(): void {
    const ctx = this.ensureContext();
    if (!ctx || !this.masterGain || this.isMuted) return;

    try {
      const now = ctx.currentTime;
      const chord = this.chords[this.stepIndex % this.chords.length];

      // Low-pass filter for warm vintage Rhodes electric piano feel
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(860, now);
      filter.connect(this.masterGain);

      // Play arpeggiated warm chord tones
      chord.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const noteGain = ctx.createGain();
        osc.type = idx === 0 ? 'sine' : 'triangle';
        // Slight lo-fi tape wow/detune
        osc.frequency.setValueAtTime(freq, now + idx * 0.035);
        osc.detune.setValueAtTime((Math.random() - 0.5) * 8, now);

        const startAt = now + idx * 0.035;
        noteGain.gain.setValueAtTime(0.001, startAt);
        noteGain.gain.linearRampToValueAtTime(idx === 0 ? 0.26 : 0.16, startAt + 0.08);
        noteGain.gain.exponentialRampToValueAtTime(0.002, startAt + 2.25);

        osc.connect(noteGain);
        noteGain.connect(filter);
        osc.start(startAt);
        osc.stop(startAt + 2.3);
      });

      // Soft lo-fi sub-kick pulse on beat 1 & beat 3
      [0, 1.2].forEach((offset) => {
        const kickOsc = ctx.createOscillator();
        const kickGain = ctx.createGain();
        kickOsc.type = 'sine';
        kickOsc.frequency.setValueAtTime(95, now + offset);
        kickOsc.frequency.exponentialRampToValueAtTime(38, now + offset + 0.14);

        kickGain.gain.setValueAtTime(0.28, now + offset);
        kickGain.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.22);

        kickOsc.connect(kickGain);
        kickGain.connect(this.masterGain!);
        kickOsc.start(now + offset);
        kickOsc.stop(now + offset + 0.24);
      });

      // Gentle bell/Rhodes grace note on beat 2.5
      const graceFreq = this.melodyNotes[this.stepIndex % this.melodyNotes.length];
      const bellOsc = ctx.createOscillator();
      const bellGain = ctx.createGain();
      bellOsc.type = 'sine';
      bellOsc.frequency.setValueAtTime(graceFreq, now + 0.9);
      bellGain.gain.setValueAtTime(0.001, now + 0.9);
      bellGain.gain.linearRampToValueAtTime(0.11, now + 0.96);
      bellGain.gain.exponentialRampToValueAtTime(0.001, now + 1.9);
      bellOsc.connect(bellGain);
      bellGain.connect(filter);
      bellOsc.start(now + 0.9);
      bellOsc.stop(now + 1.95);

      this.stepIndex++;
    } catch {
      // Ignore audio errors
    }
  }

  public playSfx(type: 'move' | 'capture' | 'tick' | 'wrong' | 'victory'): void {
    if (this.isMuted) return;

    customSoundManager.playCustomSfx(type, () => {
      const ctx = this.ensureContext();
      if (!ctx) return;

      try {
        const now = ctx.currentTime;
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);

        if (type === 'tick') {
          osc.type = 'sine';
          osc.frequency.setValueAtTime(880, now);
          osc.frequency.exponentialRampToValueAtTime(440, now + 0.06);
          gain.gain.setValueAtTime(0.09, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);
          osc.start(now);
          osc.stop(now + 0.065);
        } else if (type === 'move') {
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(320, now);
          osc.frequency.exponentialRampToValueAtTime(190, now + 0.06);
          gain.gain.setValueAtTime(0.12, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.065);
          osc.start(now);
          osc.stop(now + 0.07);
        } else if (type === 'capture') {
          osc.type = 'triangle';
          osc.frequency.setValueAtTime(460, now);
          osc.frequency.exponentialRampToValueAtTime(140, now + 0.09);
          gain.gain.setValueAtTime(0.16, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.095);
          osc.start(now);
          osc.stop(now + 0.1);
        } else if (type === 'wrong') {
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(195, now);
          osc.frequency.linearRampToValueAtTime(135, now + 0.22);
          gain.gain.setValueAtTime(0.11, now);
          gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);
          osc.start(now);
          osc.stop(now + 0.24);
        } else if (type === 'victory') {
          [523.25, 659.25, 783.99, 1046.5].forEach((freq, idx) => {
            const vOsc = ctx.createOscillator();
            const vGain = ctx.createGain();
            vOsc.type = 'triangle';
            vOsc.frequency.setValueAtTime(freq, now + idx * 0.07);
            vGain.gain.setValueAtTime(0.14, now + idx * 0.07);
            vGain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.07 + 0.3);
            vOsc.connect(vGain);
            vGain.connect(ctx.destination);
            vOsc.start(now + idx * 0.07);
            vOsc.stop(now + idx * 0.07 + 0.32);
          });
        }
      } catch {
        // Ignore
      }
    });
  }

  public destroy(): void {
    customSoundManager.stopCustomBgm();
    if (this.loopTimer !== null) {
      window.clearInterval(this.loopTimer);
      this.loopTimer = null;
    }
    try {
      this.vinylSource?.stop();
    } catch {
      // Ignore
    }
  }
}
