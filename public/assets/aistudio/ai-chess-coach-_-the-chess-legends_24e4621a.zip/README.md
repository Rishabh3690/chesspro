# AI Chess Coach — Tactical Studio

Full-featured 3D HUD Chess Coach with React Three Fiber (`TesseractPanel`, `NeuralNetworkPanel`, `DataScaffoldPanel`), 250 Mate-in-2 Lichess Puzzles, Local Stockfish Match Mode, and 100% offline/local custom audio support.

## 1. Run Locally in VS Code

1. Open the extracted folder in **VS Code**.
2. Open the integrated terminal (`Ctrl + \`` or `Cmd + \``) and install dependencies:
   ```bash
   npm install --legacy-peer-deps
   ```
3. Start the local development server:
   ```bash
   npm run dev
   ```
4. Open `http://localhost:3000` in your browser. *(No `GEMINI_API_KEY` or `.env` file is required!)*

## 2. How to Add Your Own Custom Sounds (No API Required)

Drop any `.mp3`, `.wav`, or `.ogg` audio files into the `public/sounds/` directory using the following filenames:

- `public/sounds/bgm.mp3` — Background music loop
- `public/sounds/move.mp3` — Player piece move sound
- `public/sounds/ai-move.mp3` — AI piece move sound
- `public/sounds/capture.mp3` — Piece capture sound
- `public/sounds/check.mp3` — Tactical Check alert
- `public/sounds/victory.mp3` — Puzzle solved / Checkmate fanfare
- `public/sounds/wrong.mp3` — Wrong move / Timeout buzzer
- `public/sounds/tick.mp3` — Countdown clock tick (10s–6s)
- `public/sounds/urgent-tick.mp3` — Sub-5s urgent clock tick
- `public/sounds/laugh.mp3`, `yawn.mp3`, `hype.mp3` — Coach vocal emotion cues

Any sound file you place in `public/sounds/` is played automatically by `src/utils/customSounds.ts`. Any sound file you omit automatically falls back to the built-in Web Audio API synthesizer. You can customize file paths or individual volumes in `src/utils/customSounds.ts`.

## 3. Deploy to Vercel

This project includes a pre-configured `vercel.json` and cleaned `package.json`:

- **Option A (GitHub / Git Import):** Push this folder to a GitHub repository and import it on [Vercel](https://vercel.com/new). Vercel will automatically read `vercel.json` (`npm install --legacy-peer-deps` and `npm run build`) and deploy without needing any environment variables.
- **Option B (Vercel CLI from VS Code):**
  ```bash
  npx vercel --prod
  ```
