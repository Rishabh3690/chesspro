'use client';

import React, { useEffect } from 'react';
import * as THREE from 'three';
import App from '../src/App';

// Suppress Three.js Clock deprecation warning just like src/main.tsx
if (typeof (THREE as unknown as { setConsoleFunction?: unknown }).setConsoleFunction === 'function') {
  (
    THREE as unknown as {
      setConsoleFunction: (
        fn: (type: string, message: string, ...params: unknown[]) => void
      ) => void;
    }
  ).setConsoleFunction((type: string, message: string, ...params: unknown[]) => {
    if (
      typeof message === 'string' &&
      (message.includes('Clock') ||
        message.includes('THREE.Clock') ||
        message.includes('THREE.Timer'))
    ) {
      return;
    }
    const fn =
      (console as unknown as Record<string, (...args: unknown[]) => void>)[
        type
      ] || console.warn;
    fn.call(console, message, ...params);
  });
}

export default function Page() {
  useEffect(() => {
    const origWarn = console.warn;
    console.warn = (...args: unknown[]) => {
      for (const arg of args) {
        const str =
          typeof arg === 'string'
            ? arg
            : arg && typeof arg === 'object' && 'message' in arg
            ? String((arg as { message?: unknown }).message)
            : String(arg || '');
        if (
          str.includes('THREE.Clock') ||
          str.includes('Clock: This module has been deprecated') ||
          str.includes('THREE.Timer')
        ) {
          return;
        }
      }
      origWarn.apply(console, args);
    };
    return () => {
      console.warn = origWarn;
    };
  }, []);

  return <App />;
}
