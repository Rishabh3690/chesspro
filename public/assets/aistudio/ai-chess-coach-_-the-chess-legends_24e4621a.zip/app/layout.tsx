import type { Metadata } from 'next';
import { JetBrains_Mono, Outfit, Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css';

const plusJakartaSans = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-sans',
});

const outfit = Outfit({
  subsets: ['latin'],
  weight: ['600', '700', '800'],
  variable: '--font-display',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '600', '700'],
  variable: '--font-mono',
});

export const metadata: Metadata = {
  title: 'AI Chess Coach — The Chess Legends',
  description:
    'STEM exhibition AI Chess Coach featuring Stockfish live telemetry, Hinglish voice personalities, 30-second Mate-in-1 Puzzle Rush, and mobile QR challenge.',
  openGraph: {
    title: 'AI Chess Coach — The Chess Legends',
    description:
      'STEM exhibition AI Chess Coach featuring Stockfish live telemetry, Hinglish voice personalities, 30-second Mate-in-1 Puzzle Rush, and mobile QR challenge.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'AI Chess Coach — The Chess Legends',
    description:
      'STEM exhibition AI Chess Coach featuring Stockfish live telemetry, Hinglish voice personalities, 30-second Mate-in-1 Puzzle Rush, and mobile QR challenge.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${plusJakartaSans.variable} ${outfit.variable} ${jetbrainsMono.variable}`}
    >
      <body
        suppressHydrationWarning
        className="bg-[#0A192F] text-white antialiased overflow-hidden"
        data-state="title"
      >
        {children}
      </body>
    </html>
  );
}
